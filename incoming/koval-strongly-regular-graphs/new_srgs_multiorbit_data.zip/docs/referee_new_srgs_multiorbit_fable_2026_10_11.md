# Referee report: `docs/paper/new_srgs_multiorbit.tex` (commit 91cee87)

Referee: Claude Fable 5.1, verification role. The referee wrote its own code from scratch and did not read
`build_all.py`, `verify_srg.py` or `props.py`. Evidence: `out/referee_multiorbit_fable/` (scripts `ref_lib.py`, `t1`–`t7`, logs,
own graph6 files in `g6/`, nauty canonical forms in `canon/`).

## Verdict

**Accept with minor revision, but the literature section and the framing of the Theorem need a substantial rewrite.**
Every computational claim I checked reproduces exactly. The proof of Theorem 4.2 is correct. All five parameter sets
are still "?" in Brouwer's live table. I found no source that constructs any of them. However, the Hadamard
construction is a **one-step extension of known constructions**, and the paper does not cite the closest of them.
Also, the "symmetric" hypothesis is **not needed** for existence. The same proof works for every Hadamard matrix via
Kharaghani's rank-one Bush-type matrices, and this gives further, non-isomorphic graphs.

## 1. Novelty (top priority)

**Bottom line.** Neither the Theorem nor any graph with parameters (306,55,4,11), (400,171,74,72), (576,253,112,110),
(784,351,158,156) or (1296,595,274,272) appeared in anything I searched. The ingredients are all classical, though,
and the result is "classical object + one more spread deleted". Present it that way.

What I confirmed:

* **Brouwer's live table (fetched 2026-10-11).** It has `? 306 55 4 11` (no comment), `? 400 171 74 72 OA(20,9)?`,
  `? 576 253 112 110 OA(24,11)?`, `? 784 351 158 156 OA(28,13)?` and `? 1296 595 274 272 OA(36,17)?`. The rows right
  next to them are revealing:
  * LS_{n/2}(n), i.e. k = 190, 276, 378, 630, is "+" with "Wallis (AR(2,m)+S(2,2,n)); RSHCD+".
  * LS_{n/2+1}(n), i.e. k = 209, 299, 405, 665, carries "Wallis2 …; Goethals-Seidel(2,n−1)".
  * So Brouwer knows the graph Γ₀ of Remark 4.3 (k = 209, …) and the graph with one parallel class deleted (k = 190, …).
    The second deletion, LS_{n/2−1}, is not recorded. This explains the "?" without any special matrix type being
    needed: nobody seems to have noticed the second, transversal spread.
* **Closest prior work, missing from the paper.** Bonato, Holzmann and Kharaghani, *Hadamard matrices and strongly
  regular graphs with the 3-e.c. adjacency property*, Electron. J. Combin. 8 (2001) #R1.
  * Their Theorem 1 (from Kharaghani 1985, *New class of weighing matrices*, Ars Combin. 19) takes the columns c_i of a
    normalized Hadamard matrix and sets C_i = c_i c_iᵀ. Placing the C_i in a symmetric Latin square with constant
    diagonal gives a symmetric Bush-type Hadamard matrix of order N².
  * Their Lemma 3 deletes the diagonal blocks (M = H − I⊗J), which is exactly one spread deletion, and obtains the
    "twin" srg(4m², 2m²−m, m²−m, m²−m) = LS_{N/2}(N) parameters.
  * The paper's K is the same kind of object: blocks x xᵀ with x = r_a∘r_c, diagonal blocks J.
  * In every such rank-one Bush-type matrix the "same position inside the blocks" sets {(a,b) : a ∈ [N]} form a
    **second** spread of cliques, because diag(x xᵀ) = 1. Deleting it as well is the paper's new step.
* **Other related constructions.** Goethals–Seidel 1970 Thm 2.4 (graph "Goethals-Seidel(2,n−1)" in the table), Wallis
  1971 and Fon-Der-Flaass / Muzychuk (WFDF), and Haemers–Tonchev 1996 (spreads). In particular,
  arXiv:2111.10799 (new versions of WFDF) gets only λ = μ srgs; I checked its stated srg families.
  Muzychuk–Xiang 2006 and Janko–Kharaghani are about Bush-type matrices of order 4m², m odd. None of these deletes two
  spreads or reaches λ = μ+2. No web hit exists for the five tuples.
* **What I could not search.** MathSciNet, the full text of Brouwer–Van Maldeghem (2022) §8–10, and the full text of
  Goethals–Seidel 1970. A remark in BvM about deleting spreads from LS-type graphs is possible. Given Brouwer's own
  table entries, it is unlikely to have been applied to these graphs.

**Required changes for novelty.**

* (N1) Cite Kharaghani 1985 and Bonato–Holzmann–Kharaghani 2001 (Lemma 3, the twin graph), Wallis 1971 /
  Fon-Der-Flaass 2002 / Muzychuk 2007, and Goethals–Seidel Thm 2.4. Say explicitly that Γ(H) is "a known RSHCD⁺/Bush-type
  graph with two compatible spreads of Delsarte cliques deleted". The current Remark 4.3 says only "fits the
  Goethals–Seidel framework".
* (N2) State the elementary general lemma that drives everything. *If an srg with LS_t(n) parameters has a spread of
  n-cliques, deleting the spread's edges gives an srg with LS_{t−1}(n) parameters.* Proof sketch:
  * The spread is a set of Delsarte cliques, so its block matrix E commutes with A.
  * The spread vectors orthogonal to 1 lie in the r = n−t eigenspace, because the quotient eigenvalue is
    n−1−(t−1) = n−t.
  * Then A−E+I has eigenvalues r−n+1 = −(t−1) on that space, and r+1 and s+1 elsewhere.
  * The Theorem is this lemma applied twice to Γ₀ (rows, then columns; they meet in single vertices).
* (N3) Ask Brouwer (and possibly Kharaghani) before calling the construction new. I would phrase the claim as "the graphs
  and parameter sets appear to be new; the construction is a short step from [BHK01, Kh85]".

## 2. The Theorem: independent proof and the hypotheses

**My proof.**

* K_{(a,b),(c,d)} = H_ab H_bc H_cd H_da is symmetric for any H, because the product around a 4-cycle is
  reversal-invariant.
* K² = n²I needs only HHᵀ = HᵀH = nI.
* Symmetry of H is used in two places:
  * K = 1 on rows and columns, via H_ab H_ba = 1. Without it the graph is not "Γ₀ minus two classes".
  * K1 = nE… identities (2)–(4), via H² = nI.
* The rest is the paper's eigenspace argument, which I re-derived:
  * Multiplicities: w₊ = (n−1)(n−2)/2, w₋ = n(n−1)/2.
  * Parameters: k = (n−1)(n−2)/2, λ = μ+2, μ = (n/2−1)(n/2−2).
  * Connectedness for n ≥ 8.
* Correct as written. Invariance under DHD, −H and PHPᵀ holds. Normalization and constant diagonal are not needed.

**Computational tests** (`t1_theorem.log`):

| H | symmetric | literal rule of Construction 4.1 |
|---|---|---|
| Sylvester 8, 16; Pal_II(5); Pal_II(9) | yes | srg (64,21,8,6), (256,105,44,42), (144,55,22,20), (400,171,74,72) |
| D·Pal_II(5)·D (random signs), P·Pal_II(5)·Pᵀ | yes | srg (144,55,22,20) |
| Pal_II(5)·D, P·Pal_II(5) (equivalent but not symmetric) | no | **not srg** |
| Pal_I(11), Pal_I(19), both raw and normalized; Sylvester 8 with two rows swapped | no | **not srg** |

So the literal rule really needs H to be symmetric, or more precisely D-equivalent to a symmetric matrix with
H² = nI. That makes the hypothesis correct but not the natural one.

**Generalization (new, recommended for the paper).** Take any normalized Hadamard H of order N, symmetric or not, and a
symmetric Latin square L with constant diagonal (round-robin; one exists for every even N). Let K have blocks
c_{L(a,c)} c_{L(a,c)}ᵀ, as in Kharaghani 1985. Then the graph "(a,b)~(c,d) iff a≠c, b≠d, K=1" is an srg with
LS_{N/2−1}(N) parameters, and the paper's proof goes through verbatim.

* Checked for N = 12, 20, 24 from the non-symmetric skew Paley I matrices of orders 12, 20 and 24 (`t1_theorem.log`).
* At N = 20 and 24 these graphs have |Aut| = 171 and 253 (`t7_khar.log`). The paper's graphs have 5760 and 760320, so
  the new ones are **non-isomorphic**. That already gives ≥2 graphs on 400 and on 576 vertices.
* Both have 0 cliques of size N, so they are not Latin square graphs either.
* So the existence statement holds for every Hadamard order 4m, not just orders of symmetric Hadamard matrices.

## 3. Exact verification of every graph

* **Own graph6 decoder and exact integer A² check** (`t2_graphs.log`). All 11 published files are strongly regular
  with the stated parameters, and their spectra agree with the stated ones.
* **Own rebuilds.**
  * Pal_II(9), Pal_II(13), Pal_II(17) and Pal_II(5)⊗H₂, built from my own GF(q) code, with GF(9) = GF(3)[t]/(t²−d).
  * The symplectic S−I (S² = 2S+35I asserted).
  * 2E−J for LS₃(6) of Z₆ and of S₃.
  * The 306-vertex Δ, built from Construction 6.1 (`t3_306.log`). The point counts 781/156/300/325 agree.
* **nauty** (`nauty-labelg`; SHA-256 of the canonical graph6 in `canon.log`). Every own rebuild has the same canonical
  form as the corresponding published file. Each hit (`hit306`, `hit576`, `hit1296`) is canonically identical to its
  construction (Δ, Γ(Pal_II(5)⊗H₂) and Γ(S−I) respectively).
* **The four 1296-vertex graphs** (symplectic, Z₆, S₃, Pal_II(17)) have four distinct canonical forms. This confirms
  that they are pairwise non-isomorphic.
* **|Aut| and orbits** (`aut.log`, `orbits.log`) match Table 7.1 and Computation 4.7 exactly:
  * 60000 (300+6); 5760 (360+40); 760320 (576); 8736 (728+56);
  * 2903040 (1260+36); 3456 (864+288+144); 31104 (864+432); 19584 (1224+72).

## 4. "Not a Latin square graph"

* **Lemma 4.8 is correct.**
  * Rows and columns are cocliques, so an n-clique is a transversal {(a, πa)}, and n = 1−k/s.
  * An LS_t(n) graph has t·n such cliques, in t parallel classes.
  * So fewer than (n/2−1)·n n-cliques rules out every OA(n, n/2−1) structure. The argument is exhaustive in the right
    sense: it counts all n-cliques, not just those through one vertex.
* **My own exhaustive count** (row-by-row backtracking over all transversals, `t4_cliques.log`) gives 0, 0, 0, 0, 64, 4
  and 12. This matches Computation 4.9.
* **Extra check.** In the symplectic graph the 64 n-cliques pairwise intersect (`t6_spread.log`). So there is no third
  spread, and in particular no route to LS₁₆(36) by deleting a third spread.
* **Cocliques through (0,0).** n = 20 gives 40, which matches. For n = 24, 28 and 36 my plain backtracking search ran
  into its 25-minute limit and was stopped. Those three counts (116, 56, 72) are therefore **not independently
  verified**. They matter only for the claim about the complements; the main "not a Latin square graph" claim does
  not depend on them. The complement argument ("cocliques cover some non-neighbour twice") is sound in principle: in a
  LS_{n/2+2}(n) graph the Delsarte cliques through a vertex partition its neighbourhood. I verified only the counts.

## 5. The graph on 306 vertices

* Δ is srg(306,55,4,11), and it is the only graph among the listed hits that rests on computation alone. I checked this
  independently from my own implementation of Construction 6.1:
  * exactly 61 six-cliques, clique number 6 (`t5_delta_cliques.log`);
  * induced subgraph on the 300 points is 54-regular.
* **Structural fact (useful for a hand proof).** This is verified, not proved.
  * The perpendicularity graph on the 300 non-square points is the known srg(300,65,10,15), i.e. NO⁻⊥₅(5).
  * The restriction of Δ to those points is NO⁻⊥₅(5) minus the perpendicular pairs with equal P(y) (15 per vertex),
    plus the 4 collinear pairs on m_y.
  * Δ is then obtained by adding the clique ℓ and the matching y ↦ P(y).
  * So Δ is a modification of a known graph inside the 6 classes of the fibration y ↦ P(y) (50 points each), plus a
    Delsarte clique.
  * A hand proof should go through the eigenspaces of NO⁻⊥₅(5) and of this 6-class partition. I did not complete one,
    and I found no literature source for Δ or for srg(306,55,4,11) (no web hit; Brouwer "?").
* **Minor gap in Prop. 6.3 (faithfulness).** "Fixes a spanning set ⇒ scalar" is not enough as stated, since a diagonal
  matrix fixes the basis points. Say instead that the 300 points contain a projective frame (basis plus a point with
  all coordinates non-zero), or argue via the lines m_y. The other facts in Prop. 6.3 are all correct: |SO(5,5)| =
  9,360,000; 156 lines; |L| = 60000; −I ∉ SO(5,5); L = 5^{1+2}:GL(2,5).

## 6. Honesty of the verification section

* **No "no human expert" sentence.** The acknowledgements say correctly that the author is the responsible expert.
* **The status table is accurate.** "No hand proof for Δ" is stated plainly. The three Claude sessions are disclosed
  as one model family.
* **One sentence is now outdated.** "An independent referee review of this draft has not yet taken place" (line 762)
  should be updated to mention this review, which came from a different model family (Fable).
* **One over-claim in Remark 4.3.** "We would not be surprised if it is known in some form" is fair, but the remark
  should name BHK01 Lemma 3 and Kharaghani 1985 (see N1).

## Findings by severity

* **MAJOR (presentation/novelty).**
  * N1: missing closest prior work (Kharaghani 1985; Bonato–Holzmann–Kharaghani 2001 Lemma 3, the twin graph = one
    spread deleted; Wallis/WFDF).
  * N2: state the spread-deletion lemma and present the Theorem as Γ₀ minus two spreads.
  * Neither changes any result.
* **MINOR.**
  * Generalize the Theorem to all Hadamard matrices (Kharaghani blocks). This adds non-isomorphic graphs on 400 and
    576 vertices and removes the restriction to symmetric Hadamard orders. Alternatively, at least remark on it.
  * Fix the faithfulness argument in Prop. 6.3.
  * Update the acknowledgements sentence about referee review.
  * Mention the NO⁻⊥₅(5) description of Δ.
* **No errors found** in any theorem, lemma, proposition, computation, table entry or checksum-level graph identity
  that I checked.
