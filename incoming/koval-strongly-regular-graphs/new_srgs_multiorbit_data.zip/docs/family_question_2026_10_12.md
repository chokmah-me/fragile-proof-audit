# Do the five new SRGs belong to a known family? (2026-10-12)

Question from the author: are srg(306,55,4,11), srg(400,171,74,72), srg(576,253,112,110), srg(784,351,158,156)
and srg(1296,595,274,272) members of a known family, or new?

Evidence lives in `out/family_2026_10_12/` and the code in `scripts/family_2026_10_12/`. The code was written
from scratch for this note. It imports nothing from `scripts/new_srgs_multiorbit/` or from the referee's directory.
Every srg claim below is an exact integer check of A² = kI + λA + μ(J−I−A) (`famlib.srg_params`). Every
isomorphism statement compares nauty canonical forms (`nauty-labelg`, SHA-256 prefix).

## Verdict per graph

| graph | verdict |
|---|---|
| srg(400,171,74,72) | **NEW parameter-set existence** (Brouwer "?", comment "OA(20,9)?"). The graph is new. It is the n=20 member of a **new infinite family**: a Bush-type Hadamard graph with **two** orthogonal spreads deleted. The family is a one-step extension of Kharaghani 1985 and Bonato–Holzmann–Kharaghani 2001, whose published results stop at **one** deleted spread, i.e. at LS_{n/2}(n). |
| srg(576,253,112,110) | Same: NEW parameter set ("OA(24,11)?"), new graph, n=24 member of the same new family. |
| srg(784,351,158,156) | Same: NEW parameter set ("OA(28,13)?"), new graph, n=28 member. |
| srg(1296,595,274,272) | Same: NEW parameter set ("OA(36,17)?"), new graphs (≥4 non-isomorphic from the paper, more below), n=36 member. |
| srg(306,55,4,11) | **NEW parameter-set existence** (Brouwer "?", no comment). The graph is new and **not** a member of any infinite family we can find. It is pseudo-geometric for GQ(5,10), a GQ not known to exist, and it is not geometric (61 lines, a GQ needs 561). The same rule over F_3 gives the classical GQ Q(4,3); over F_7 and F_9 it gives no srg. So the construction is a two-member pattern {q=3: Q(4,3), q=5: Δ}. It mirrors the NO^{−⊥}_5(q) graphs it is built on, which are strongly regular only for q = 3, 5. |

"New family" means new as far as we can determine. Kharaghani 1985 (Ars Combin.) was read only through BHK's
reproduction of its theorem. MathSciNet and the full text of Brouwer–Van Maldeghem (2022) were not searched.

## 1. What Kharaghani 1985 and Bonato–Holzmann–Kharaghani 2001 construct

Source read: BHK, *Hadamard matrices and strongly regular graphs with the 3-e.c. adjacency property*, Electron. J.
Combin. 8 (2001) #R1 (open access; local copy `out/family_2026_10_12/lit/BHK2001_EJC8R1.pdf`). I could not get
Kharaghani, *New classes of weighing matrices*, Ars Combin. 19 (1985) 69–72. BHK reproduce its result as their
Theorem 1 ("for completeness we include the following result of Kharaghani [12]").

* **Definition (BHK §2).** A Hadamard matrix of order 4n² is *Bush-type* if its 2n×2n blocks satisfy H_ii = J and
  H_ij J = J H_ij = 0 for i ≠ j. A symmetric Bush-type matrix is the ±-adjacency matrix of an
  srg(4n², 2n²−n, n²−n, n²−n).
* **Theorem 1 (Kharaghani 1985).** If a Hadamard matrix of order 4n exists, a Bush-type Hadamard matrix of order 16n²
  exists. Construction: take the columns c_i of a normalized Hadamard K of order 4n and put C_i = c_i c_iᵀ. Then
  place the C_i in a symmetric Latin square with constant diagonal 1.
* **Lemma 3.** Let H be Bush-type of order 4n² and M = H − I_{2n}⊗J_{2n}. Then M "contains two
  SRG(4n², 2n²−n, n²−n, n²−n)": the −1 entries of H, and the +1 entries of M. They call M a *twin graph*.
  * The second graph is (J+H)/2 − I with the diagonal blocks removed, i.e. Γ₀ minus **one** spread.
* **Theorem 5.** For 4n a Hadamard order with n odd, n > 1, the twin srg(16n², 8n²−2n, 4n²−2n, 4n²−2n) is 3-e.c.
* **Second spread.** No other construction appears in the paper, and no second spread is deleted. Conjecture 8 is about
  3-e.c. only.

So in the notation N = 2n (block size), with Γ₀ = (J+K)/2 − I for the Kharaghani matrix K:

| object | parameters | type | Brouwer comment (live table) |
|---|---|---|---|
| Γ₀ (Kharaghani / Goethals–Seidel) | (N², (N²+N)/2−1, …) | LS_{N/2+1}(N) | "Wallis2 …; Goethals-Seidel(2,N−1)", "+" |
| BHK twin = Γ₀ − row spread | (N², N(N−1)/2, λ=μ) | LS_{N/2}(N) | "Wallis …; RSHCD+", "+" |
| **Γ₀ − rows − columns (ours)** | (N², (N−1)(N−2)/2, μ+2, μ) | **LS_{N/2−1}(N)** | **"?" with "OA(N, N/2−1)?"** |

**Do BHK or Kharaghani cover our parameter sets?** No. Their results give λ = μ (LS_{N/2}). For N = 20, 24, 28, 36
these are (400,190,90,90), (576,276,132,132), (784,378,182,182) and (1296,630,306,306). All four are already "+" in
Brouwer's table, as "RSHCD+". Γ₀ gives the "+" rows k = 209, 299, 405, 665 ("Goethals-Seidel(2,N−1)"). Neither paper
gives LS_{N/2−1}.

**Why Brouwer still shows "?".** Brouwer's only listed route to LS_{N/2−1}(N) is an OA(N, N/2−1), i.e. N/2−3 MOLS of
order N, which is not known for N = 20, 24, 28, 36. No published construction deletes a second spread. The live rows
were re-fetched on 2026-10-11 (UTC 04:02), and are saved in `out/family_2026_10_12/brouwer_live/` and
`brouwer_ls_rows.txt`:

```
?  400 171  74  72  LS_9(20)   | OA(20,9)?      (complement 228 128 132 | OA(20,12)?)
?  576 253 112 110  LS_11(24)  | OA(24,11)?     (complement 322 178 182 | OA(24,14)?)
?  784 351 158 156  LS_13(28)  | OA(28,13)?     (complement 432 236 240 | OA(28,16)?)
? 1296 595 274 272  LS_17(36)  | OA(36,17)?     (complement 700 376 380 | OA(36,20)?)
?  306  55   4  11             | (no comment)   (complement 250 205 200)
```

The neighbouring rows read "+ 400 190 90 90 | OA(20,10)?; Wallis (AR(2,5)+S(2,2,20)); RSHCD+; 2-graph" and
"+ 400 209 108 110 | OA(20,11)?; Wallis2 …; Goethals-Seidel(2,19); 2-graph".

## 2. Rebuilding the known constructions and comparing (N = 12, 16, 20, 24, 28, 36)

`step2_known.py` builds, for each available Hadamard matrix H (Sylvester, Paley I, Paley II, H₂⊗Paley I,
Paley II⊗H₂) and each Latin square L (round robin, a random colour/point relabelling of it, and XOR for 2-powers):
* the Kharaghani matrix K(H, L) (checked: symmetric, unit diagonal, K² = N²I);
* Γ₀ (expected LS_{N/2+1}), the BHK twin (expected LS_{N/2}), and Γ₀ − rows − columns (expected LS_{N/2−1});
* for symmetric H, also the paper's rule K_{(a,b),(c,d)} = H_ab H_bc H_cd H_da.

Logs: `step2_a.log` (N = 12–24), `step2_b.log` (N = 28) and `step2_c.log` (N = 36, 40, 44; canonical forms of G2 only, because labelg on Γ₀ at 1296 vertices ran over 30 min and was stopped). Graphs are in `g6/`.

* **All exact checks pass.** Every Γ₀, every BHK twin and every two-spread deletion has exactly the expected
  LS parameters.
* **My code reproduces ours.** The rule applied to Pal_II(9) and Pal_II(5)⊗H₂ gives the canonical forms of our
  published srg400 (`b15910f8…`) and srg576 (`077482ff…`). Kharaghani(Pal_I(19), round robin) gives the referee's
  `khar_palI_19` (`f0ef9bbf…`). Sylvester 16 by the rule equals Kharaghani(Syl16, XOR) (`9c2c323b…`).
* **Isomorphism with known constructions: impossible on parameters.** Every graph that Kharaghani 1985 / BHK 2001
  (and Wallis, Goethals–Seidel, Fon-Der-Flaass) produce has LS_{N/2+1} or LS_{N/2} (λ = μ) parameters. Ours have
  LS_{N/2−1} with λ = μ+2. They are also not Latin square (OA) graphs (paper, Computation 4.9; the clique counts are
  re-derived in §3 below). **So no graph obtainable by a published construction is isomorphic to any of ours.**
* **Two-spread deletions of Kharaghani matrices (the referee's generalization) give further graphs.** These are
  pairwise distinct from ours, so ours are not the "Kharaghani form" of the same family:

| N | ours (canonical) | other two-spread deletions found (canonical, all distinct) |
|---|---|---|
| 20 | Pal_II(9) rule `b15910f8` | K(Pal_I19, rr) `f0ef9bbf`, K(Pal_I19, rr*) `a535920a`, K(Pal_II9, rr) `454baa6c`, K(Pal_II9, rr*) `a5ff9877` |
| 24 | Pal_II(5)⊗H₂ rule `077482ff` | K(Pal_I23, rr) `0f50c45d`, rr* `e737ba94`; K(H₂⊗Pal_I11, rr) `efcea09d`, rr* `0d117300`; K(Pal_II5⊗H₂, rr) `ed973300`, rr* `67918c94` |
| 28 | Pal_II(13) rule `1f455843` | K(Pal_I27, rr) `68288734`, rr* `57b21e8e`; K(Pal_II13, rr) `bf91d851`, rr* `e633e123` |
| 36 | symplectic `e64993c7`, Z₆ `e8ba25bb`, S₃ `3a31fb59`, Pal_II(17) rule `d4d55b4d` | K(Pal_II17, rr) `38798860`, rr* `0f1ea859` |

* **Not literally Kharaghani form.** For a symmetric H the paper's block vectors are x_{ac} = r_a∘r_c. In Kharaghani's
  form only N distinct ±vectors occur. For Sylvester we get 16 = N, consistent with Syl16 being Kharaghani(XOR). For
  Pal_II(5), Pal_II(9) and Pal_II(5)⊗H₂ we get 67, 191 and 134 distinct ±vectors. The paper's graphs therefore come
  from symmetric rank-one Bush-type matrices that are **not** of Kharaghani's Latin-square form. This is a second
  source inside the same new family.

## 3. The spread lemma, and j-spread deletion

**Lemma (spread deletion).** Let Γ be a primitive srg(v,k,λ,μ) with eigenvalues k > r > s. Let S be a *spread*:
a partition of V into cliques of size K = 1 − k/s (Delsarte cliques). Let Γ' be Γ with the edges inside the
cliques of S removed.

(a) Γ' is strongly regular **iff** K = r − s, i.e. iff Γ has the parameters of LS_t(n) with n = r − s and t = −s.

(b) Γ' then has the parameters of LS_{t−1}(n). It is a connected srg if t ≥ 3, and nK_n if t = 2.

(c) **Iteration.** Let S_1, …, S_j be pairwise *orthogonal* spreads, meaning cliques from different spreads meet in
exactly one vertex. Then deleting all of them from an LS_t(n)-type srg gives an srg of LS_{t−j}(n) type
(t − j ≥ 2), or nK_n (t − j = 1).

*Proof.*
1. **Setup.** Let N be the v × (v/K) characteristic matrix of S, so E := NNᵀ − I is the adjacency matrix of the spread.
2. **Outside neighbours.** For a Delsarte clique C, every vertex outside C has the same number e of neighbours in C
   (Haemers–Tonchev 1996, Lemma 2.1). Counting edges leaving C gives e = K(k−K+1)/(v−K). This yields
   AN = N((K−1−e)I + eJ), so A commutes with NNᵀ.
3. **Value on the spread space.** On col(N) ∩ 1^⊥, A acts as K−1−e, and this equals r, as one sees from the
   eigenmatrix in Haemers–Tonchev Prop. 4.1, or by direct substitution.
4. **Spectrum of A' = A − E.**
   * on 1: k − K + 1 = k + k/s;
   * on col(N) ∩ 1^⊥ (dimension v/K − 1): r − K + 1 = r + k/s;
   * on col(N)^⊥, where E = −I: A + I, with eigenvalues r+1 and s+1 and multiplicities f − v/K + 1 and g.
5. **Proof of (a).** For primitive Γ, f − v/K + 1 > 0 (HT96 Thm 5.1 gives g ≤ (f−v/K+1)(v/K−1)). So A' has at most
   three eigenvalues iff r + k/s ∈ {r+1, s+1}. Since k/s < 0, this means r + k/s = s+1, i.e. K = 1 − k/s = r − s.
   * Put n = r − s and t = −s. Then k = −s(K−1) = t(n−1), μ = k + rs = t(t−1), λ = μ + r + s = n−2+(t−1)(t−2),
     and v = (k−r)(k−s)/μ = n².
6. **Proof of (b).** A' has eigenvalues (t−1)(n−1), n−t+1 and −(t−1), which is the LS_{t−1}(n) spectrum. A regular
   graph with three distinct eigenvalues whose degree is simple is a connected srg. The degree is simple iff
   (t−1)(n−1) ≠ n−t+1, i.e. t ≠ 2.
7. **Proof of (c).** A clique of S_2 meets each clique of S_1 in one vertex, so it loses no edge when S_1 is deleted.
   It is still an n-clique, and n = 1 − k'/s' for LS_{t−1}(n), so it is Delsarte again. Induct. ∎

Remarks.
* (a)–(b) is essentially Haemers–Tonchev 1996 Prop. 4.1: the 3-class scheme with A₁ = Γ'. The "iff K = r−s" form is
  stated in our CHANGELOG (line 35), so the lemma itself is known.
* Our Theorem is the lemma applied twice to Γ₀, with rows and columns as orthogonal spreads. In Kharaghani's matrices
  the column spread exists because diag(c c^T) = 1. That is the whole point BHK did not use.

**j-spread search.** A third spread orthogonal to rows and columns consists of *transversal* N-cliques
{(a, π(a))} of Γ₀. `transv.c` enumerates them all (exhaustive DFS with forward checking, verdict COMPLETE).
`step3_spreads.py` finds every spread (exact cover, exhaustive) and the largest set of mutually orthogonal spreads.
Logs: `step3_N{12,16,20,24,28,36}.log` and `step3_ourfiles.log`.

| N | sources tested (all COMPLETE) | transversal N-cliques | third spread? |
|---|---|---|---|
| 8 (control) | SAT model below | – | yes: srg(64,14,6,2) = LS_2(8), exact |
| 12 | K(Pal_I11 / Pal_II5, rr + 4 random rr), rule Pal_II5 | 0 in every case | no |
| 16 (control) | K(Syl16, XOR) and the rule on Syl16 | 448 (= 28 alternating invertible M × 16 shifts) | yes: 54,208 spreads; j=3 gives srg(256,90,34,30) = LS_6(16), exact |
| 16 | K(Syl16, rr ×3), K(H₂⊗Pal_I7, rr ×3, XOR) | 0 | no |
| 20 | K(Pal_I19 / Pal_II9, rr + 6 random each), rule Pal_II9 | 0 | no |
| 24 | K(Pal_I23 / H₂⊗Pal_I11 / Pal_II5⊗H₂, rr + 6 random each), rule Pal_II5⊗H₂ | 0 | no |
| 28 | K(Pal_I27 / Pal_II13, rr + 6 random each), rule Pal_II13 | 0 | no |
| 36 | K(Pal_II17, rr + 6 random), rule Pal_II17 | 0 | no |
| 36 | our symplectic / Z₆ / S₃ graphs | 64 / 4 / 12, pairwise meeting in 6–16 / 0 / 0 cells | no spread (exact cover empty) |

**SAT over all Latin squares L** (`sat_third_spread.py`, kissat; the model contains L, the spread and the clique
constraints; π₀ = id is without loss of generality).

*Why π₀ = id loses nothing (added 2026-10-12 after the paper agent questioned it).* Permuting the grid rows a → s(a)
of K(H, L), i.e. the cells (a,b) → (s(a),b), gives exactly K(H, L^s) with L^s(s(a),s(c)) = L(a,c), which is again a
symmetric constant-diagonal Latin square. A transversal {(a, π(a))} of a spread goes to the diagonal under s = π⁻¹,
and L^s is still inside the model's range, since the model quantifies over ALL L. Checked as a matrix identity
P K(H,L) Pᵀ = K(H, L^s) on random L and s at N = 8 and 12 (`scripts/family_2026_10_12/wlog_check.py`, 6/6 True). The
labels of the other transversals ("transversal k contains (0,k)") are a pure relabelling. Hence the N = 12 verdict
covers every Kharaghani matrix K(Pal_I(11), L). Moreover K(H, L) depends on H only up to Hadamard equivalence:
row negations are removed by normalization, column negations do not change c_i c_iᵀ, row permutations of H permute
grid columns, and column permutations of H relabel L. So no Kharaghani matrix of order 144 has a third spread.
(The paper, by choice, claims only the model's literal statement.) Controls: N = 8 Syl8 and Pal_I7 SAT,
decoded and verified exactly. Results:
* N = 12, Pal_I(11): **UNSAT**. Every Hadamard matrix of order 12 is equivalent to this one, and its automorphism
  group is transitive on columns, so no Kharaghani matrix of order 144 has a third spread.
* N = 20, Pal_I(19) and Pal_II(9): **TIMEOUT after 7200 s each (no verdict; this supports nothing either way)**. N = 24 and 28 were not awaited (both were stopped a few seconds after starting). So whether some Latin square L makes a Kharaghani matrix of order 400 carry a third spread is **open**.

**Reach of the family in Brouwer's table** ("?" rows of LS type with v = n² ≤ 1300; the complement is in the same row):

| row | type | j needed from Γ₀ | status after this work |
|---|---|---|---|
| (400,133,48,42) | LS_7(20) | 4 | still open (no third spread found) |
| (400,152,60,56) | LS_8(20) | 3 | still open |
| **(400,171,74,72)** | LS_9(20) | **2** | **settled (+)** |
| (576,230,94,90) | LS_10(24) | 3 | still open |
| **(576,253,112,110)** | LS_11(24) | **2** | **settled (+)** |
| (784,216,68,56) | LS_8(28) | 6 | out of reach |
| (784,324,136,132) | LS_12(28) | 3 | still open |
| **(784,351,158,156)** | LS_13(28) | **2** | **settled (+)** |
| (1296,385..560) | LS_11..16(36) | 3..8 | still open |
| **(1296,595,274,272)** | LS_17(36) | **2** | **settled (+)** |

* **Within the table, the family settles exactly these four rows**, which are the ones we already have.
* **Beyond the table.** It gives LS_{N/2−1}(N) for **every** Hadamard order N = 4m, with no symmetric H needed, via
  Kharaghani's matrices. For N = 40 and 44 (v = 1600, 1936), N(40) and N(44) are far below N/2−3. So
  srg(1600,741,344,342) and srg(1936,903,422,420) exist, together with every N = 4m ≥ 20 that is not a power of 2.
  For powers of 2 an affine plane gives the OA anyway.
* Both v = 1600 and v = 1936 are beyond Brouwer's table (v ≤ 1300). Their membership in the family follows from the
  lemma and needs no computation. Both were nevertheless built and checked exactly (`step2_c.log`): K(H₂⊗Pal_I19), K(Pal_II9⊗H₂) give srg(1600,741,344,342) and K(Pal_I43) gives srg(1936,903,422,420), with Γ₀ and the BHK twin also exact.

## 4. The graph on 306 vertices

`step4_delta.py` re-implements Construction 6.1 of the paper over F_q (own GF(p^e) code) in two variants. In the
first, the chosen nonsingular points are those with Q(y) a non-square, as in the paper. In the second, Q(y) is a
non-zero square. Logs: `step4_q3_q5.log` and `step4_q7_q9.log`.

| q | non-square points | NO^{⊥} on them | Δ_q | |
|---|---|---|---|---|
| 3 | 36 | srg(36,15,6,6) | **srg(40,12,2,4)**, 40 four-cliques | canonically **equal to the collinearity graph of Q(4,3)** (`0d4a0e63`), not W(3) (`ad665721`) |
| 5 | 300 | srg(300,65,10,15) = NO^{−⊥}_5(5) | **srg(306,55,4,11)**, 61 six-cliques | canonically equal to our graph (`da974d5b`) |
| 7 | 1176 | not srg | 154-regular on 1184 vertices, **not srg** | |
| 9 | 3240 | not srg | 333-regular on 3250 vertices, **not srg** | |

* **The square variant is undefined.** For every q the square-type point set meets ℓ^⊥ \ ℓ, so P(y) is not defined
  there.
* **Pseudo-geometric parameters.** For all q the parameters would be those of GQ(q, q(q−1)/2): q=3 gives GQ(3,3),
  q=5 gives GQ(5,10), q=7 gives GQ(7,21), q=9 gives GQ(9,36). Only q = 3 and q = 5 give srgs. These are exactly the
  q for which the underlying NO^{ε⊥}_5(q) graph is strongly regular (Wilbrink; Brouwer–Van Maldeghem 2022, the
  chapter on polar-space graphs; our exact checks at q = 7 and 9 confirm it fails there).
* **Not geometric.** GQ(5,10) is not in the list of (s,t) for which a GQ is known: (1,q), (q,1), (q±1,q∓1), (q,q),
  (q,q²), (q²,q), (q²,q³), (q³,q²); see van Dam–Guo, arXiv:2204.04755 §6.3. A GQ(5,10) would need 561 lines; Δ has
  only 61 six-cliques, so Δ is pseudo-geometric but not geometric. Brouwer's 306 row has no comment, so no GQ(5,10)
  or pseudo-geometric graph is recorded there.
* **Dimension 2m+1 ≥ 7 does not generalize.** The construction needs every chosen point y to have a unique
  orthogonal point on a totally singular subspace ℓ. That happens only when ℓ is a line of Q(4,q), i.e. 2m+1 = 5. For
  2m+1 ≥ 7, ℓ^⊥/ℓ is a non-degenerate space containing nonsingular points of both types. If ℓ is a plane or larger,
  B(y,·) vanishes on a subspace of ℓ, not a point.
* **Verdict.** Δ is new as a graph. The parameter-set existence is new. Δ is not a member of a known family. It is
  the q = 5 member of a two-member pattern whose q = 3 member is the classical GQ Q(4,3). The pattern does not
  continue to q = 7 or 9. We found no literature source for srg(306,55,4,11) or for a pseudo-GQ(5,10).

## 5. Summary for the paper

* Present the Hadamard graphs as "Bush-type (Kharaghani) Hadamard graph Γ₀ with two orthogonal spreads deleted". Cite:
  * Kharaghani 1985 and BHK 2001 Thm 1 / Lemma 3, which stop at one spread;
  * Haemers–Tonchev 1996 Prop. 4.1, for the lemma.
* Generalize Theorem 4.2 to every Hadamard order (the referee's point, confirmed here at N = 12–40). The symmetric
  rule and Kharaghani's Latin-square form are two sources inside the same family, and they give non-isomorphic graphs.
* The claim "new parameter-set existence for the four LS rows" stands: no published construction gives LS_{N/2−1}(N)
  for N = 20, 24, 28, 36. The claim "new infinite family" is reasonable but should be checked with Kharaghani and
  Brouwer before publication (referee item N3).
* 306: claim a new graph and a new parameter set, not a family. Add that Δ_3 ≅ Q(4,3) and that Δ is a non-geometric
  pseudo-GQ(5,10).

## Final verification

`out/family_2026_10_12/final_verify.log` re-reads every cited graph6 file in `out/family_2026_10_12/g6/`: the 31 G2
graphs, Δ_3, Δ_5 and the two N = 8 controls. Each one is re-decoded, re-checked exactly with A², and re-hashed with
nauty. All 35 are strongly regular with the stated parameters, and every canonical hash matches the one quoted above.
The SAT CNFs (gzip) and the kissat outputs are kept in `out/family_2026_10_12/sat/`. Paper PDFs are kept locally in
`lit/` and are not committed, for copyright reasons.
