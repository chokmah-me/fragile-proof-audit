# Referee report, second round: `docs/paper/new_srgs_multiorbit.tex` version 2 (commit 5deadf6, 25 pp)

Referee: Claude Fable 5.1 (verification role, different model family from the authoring sessions). Date: 2026-10-12.
Own code and logs: `out/referee_multiorbit_v2_fable/` (scripts `v1_files.py`, `v1b_g2_only.py`, `v2_khar.py`, `v3_misc.py`,
`v5_cliques.py`, `cocl.c` + `v6_cover.py` + `v6_controls.py`, `v7_delta.py`, `v8_sat12.py` + `v8_decode.py`, `v9_aut.py`;
logs `*.log`, `cocl_*.txt`, `sat_*.out`). The scripts import only my own round-1 library `out/referee_multiorbit_fable/ref_lib.py`
(graph6 codec, GF(q), Paley matrices); nothing from `scripts/new_srgs_multiorbit/` or `scripts/family_2026_10_12/` was imported.
I read `cocl_cover.py`, `canon_files.py`, `famlib.canon_hash` and `wlog_check.py` only to learn the hashing convention and the
WLOG claim, not to copy algorithms. First-round report: `docs/referee_new_srgs_multiorbit_fable_2026_10_11.md`.

## Verdict

**MINOR REVISION.** Every lemma, proposition and theorem I checked line by line is correct (one proof relies on a
cited inequality, which I located in the source). Every number I could recompute agrees with the paper: all 11
published graph6 files and all 31 two-spread-deleted Kharaghani graphs are strongly regular with the stated
parameters; all 37 canonical hashes in Computation 4.18 and Section 8.2 reproduce; the clique counts, the Sylvester
control (448 cliques, 54208 spreads, LS_6(16)), the symplectic intersection pattern {6,8,16}, Table 4.1, the
block-vector counts, |Aut| = 171 and 253, the N=8/N=12 SAT verdicts, and the q = 3, 5, 7 analogues of Delta all
reproduce. New in this round: **the coclique counts 116, 56, 72 and the exact-cover result for n = 24, 28, 36, which
version 2 reports as not independently verified, are now reproduced by a third, independent program** (Hoffman-pruned
exact enumeration in C, `cocl.c`, controls on genuine Latin square complements). The remaining required changes are
citation precision, one notation inconsistency, and updating two sentences that this round makes outdated. The WLOG
argument of the family note for the N = 12 SAT verdict is correct, so the paper may claim the stronger statement
(R4). All first-round items were addressed (Section 1 below).

## 1. First-round items: all addressed

| round-1 item | status in v2 |
|---|---|
| N1 cite Kh85, BHK01 Lemma 3, Wallis/FDF/Muzychuk, GS70 | done (Section 1 "What is known", Remark 4.11, Section 9) |
| N2 state the spread-deletion lemma, present Theorem as Gamma_0 minus two spreads | done (Lemma 4.1, Theorem 4.2, title changed) |
| N3 "new as far as we can determine" wording | done (Sections 1 and 9) |
| generalize to all Hadamard orders via Kharaghani blocks | done (Prop. 4.5, Cor. 4.6, Computation 4.7, including v = 1600, 1936) |
| faithfulness gap in Prop. 6.3 | fixed (projective frame; I re-checked the frame: five basis vectors with Q = 2, combination (2,1,1,2,4) with Q = 3, all coefficients non-zero) |
| outdated "no referee review yet" sentence | fixed (Acknowledgements) |
| mention the NO^{-perp}_5(5) description of Delta | done (Section 6) |
| three coclique counts not independently verified | honestly reported in v2; now verified here (Section 3.6 below) |

Also checked: the "complements are not Latin square graphs" argument was replaced by the exact-cover test (Section 2.3 below:
sound and sufficient); no sentence of the "no human expert" type exists; the author is named as the responsible expert.

## 2. Mathematics (line-by-line)

### 2.1 Lemma 4.1 (spread deletion) - correct
* AN = N((omega-1-e)I + eJ) with e = omega(k-omega+1)/(v-omega): correct (Delsarte clique property, Conventions).
* theta = omega-1-e in {r,s}, theta >= 0 because e <= omega-1 (an outside vertex adjacent to all of C would extend the maximum clique), and theta = r since s <= -2: correct.
* Spectrum (1): the eigenvalue list is a multiset (r-omega+1 = s+1 in the case of (2)); the proof handles this. Fine.
* **f - m + 1 > 0.** The paper cites "the absolute bound g <= (f-m+1)(m-1) for the imprimitive 3-class scheme of [HT96, Prop. 4.1 and Section 4]". I checked the text of HT96 (`out/family_2026_10_12/lit/HaemersTonchev96.txt`, p. 149): directly after Prop. 4.1 they derive exactly g <= (f-K+1)(K-1) from the Krein parameter and Neumaier's absolute bound, and Theorem 5.1 restates it. The citation is accurate. (Optional: an elementary two-line proof exists. If f = m-1 the r-eigenspace is {Nz : z perp 1}, so A lies in span(I, J, NN^T); then the (x,x) entry and the (x,y) entry for x != y in one clique differ by exactly -s, i.e. 0 - 1 = s, contradicting s <= -2.)
* (2) "only if": the case split k' = r+1 (disconnected regular graph with three eigenvalues) vs k' a fourth eigenvalue is complete, since k' = k + k/s > 0 > s+1 and k' != r + k/s. "if": the parameter computation k = t(n-1), mu = t(t-1), lambda = n-2+(t-1)(t-2), v = n^2 and the multiplicities (t-1)(n-1), (n-1)(n-t+2) are right; (t-1)(n-1) - (n-t+1) = n(t-2) gives connectedness for t >= 3.
* (3) induction: Gamma_1 primitive for t-1 >= 2 (eigenvalues n-t+1 > 0 since n > t, and -(t-1) <= -2); S_2 cliques keep all edges and stay Delsarte (n = 1 + (t-1)(n-1)/(t-1)); omega = n = r_1 - s_1. Correct.

### 2.2 Theorem 4.2, Proposition 4.5, Corollary 4.6, Lemma 4.9, Theorem 4.10 (direct proof) - correct
* Theorem 4.2(1): K1 = n1, eigenvalues +-n on 1^perp, tr K = n^2 gives w_+ = (n+2)(n-1)/2, w_- = n(n-1)/2; A_0 eigenvalues (n^2+n)/2-1, n/2-1, -n/2-1; primitive for n >= 4; LS_{n/2+1}(n) parameters. (2) rows: K_aa = J; columns: unit diagonal; size n = 1 - k_0/s_0 = 1 + (n+2)(n-1)/(n+2). (4) A_0 - (E_1 - I) - (E_2 - I) = (J+K)/2 - E_1 - E_2 + I. All checked; n = 4 gives 4K_4 (t - j = 1), n >= 6 connected.
* Prop. 4.5 (Kharaghani): C_i J = 0 for i != 1 by column orthogonality with c_1 = 1; unit diagonal; C_i C_j = n delta_ij C_i; the block (a,c) of K^2 vanishes for a != c because L(a,e) and L(c,e) lie in one column of L in different rows; the diagonal block is n sum_i C_i = n HH^T = n^2 I. Correct. Round-robin squares (1-factorizations of K_n) exist for every even n. I rebuilt K(H,L) for 13 matrices (n = 12..44) and confirmed all four matrix properties and the three parameter sets (Section 3.3).
* Lemma 4.9: K_{(a,b),(c,d)} = (H_ab H_bc)(H_ad H_dc) = x_b x_d with x = h_a o h_c uses H_cd H_da = H_ad H_dc (symmetry). 1^T x^{(ac)} = (H^2)_{ac} = n delta_ac. Correct.
* Theorem 4.10, direct proof: identities (1)-(4) re-derived; decomposition into <1>, U_1, U_2, W; trace count 1 + 2(n-1) + w_+ - w_- = n gives w_+ = (n-1)(n-2)/2, w_- = n(n-1)/2; k > r for n >= 8 (also for n = 6); mu = k + rs = (n/2-1)(n/2-2), lambda = mu + 2. Correct. Remark 4.11: K = D (H (x) H) Pi D checked entrywise: D(H(x)H)PiD at ((a,b),(c,d)) is H_ab H_ad H_bc H_cd = K.
* Corollary 4.6 / Section 4.7 parameters: all ten rows (n = 8..44) recomputed (`v3_misc.log`).

### 2.3 Lemma 4.16, Computation 4.17, Section 7 "Complements" - correct and sufficient
* Lemma 4.16: rows and columns are cocliques, so an n-clique is a transversal; Delsarte since n = 1 - k/s; LS_{n/2-1}(n) has (n/2-1)n such cliques. Correct.
* The exact-cover test (Section 7): if the complement were LS_t(n), t = n/2+2, the t lines through (0,0) would be Delsarte cliques of the complement, i.e. n-cocliques of Gamma(H) through (0,0), pairwise meeting only in (0,0) and covering the (t)(n-1) = (n-1)(n+4)/2 non-neighbours of (0,0) exactly (the arithmetic (n-1)(n+4)/2 = (n/2+2)(n-1) holds). Since every vertex of a Latin square graph has this property, testing (0,0) alone is sufficient, and a negative answer rules out the Latin square structure regardless of how many other Delsarte cliques the complement has. The argument is sound and sufficient, PROVIDED the list of n-cocliques through (0,0) is complete - which is exactly what I re-verified independently (Section 3.6). The controls (complements of LS_3(5), LS_4(7), LS_5(11)) are the right ones; my own controls (LS_3(7), LS_5(11), LS_6(13)) also find the partition.

### 2.4 Proposition 4.13, Table 4.1, the symplectic two-graph - correct
* Prop. 4.13(1): H_aa H_ac H_cc H_ca = 1; 1 - k/s = n; outside count n(k-n+1)/(n^2-n) = (n-4)/2 = n/2-2. (2): the five cases are exhaustive ({a,b} and {c,d} share c=b, d=a, both, or nothing; a=c and b=d excluded) and each sign computation is right; the disjoint case uses S_ab S_bc S_cd S_da = type(abc) type(acd). (3) correct.
* The character sum: sum over singular u of (-1)^{B(v,u)} = (1/2) sum_u (-1)^{f_0(u)+B(v,u)} = (1/2)(-1)^{f_0(v)} sum_u (-1)^{f_0(u)} = 4(-1)^{f_0(v)}, and f_0(w+w') = B(w,w') for singular w, w'. So (S^2)_{ww'} = 4 S_ww' - 2 S_ww' = 2 S_ww', S^2 = 2S + 35I. Verified numerically too.
* Table 4.1: all nine valencies reproduced from my own build (35, 560; 16, 1, 16+16 = 32, 144, 96, 144, 144, 18; `v3_misc.log`), including the finer invariants (types of the four triples, w_a + w_b = w_c + w_d). The "same type" rule matched all 1122 disjoint pairs with 0 mismatches.

### 2.5 Section 6 (Delta) - correct
* Lemma 6.2: Q(y+tP) = Q(y); P(y+tP) = P(y) because B(P, l) = 0; B(y, y+tP) = 2Q(y) != 0; the two alternatives are disjoint and symmetric; 1 - k/s = 6. Correct. (The count "each point of l lies on 10 lines m_y" uses the transitivity of L on l proved in Prop. 6.3 - a forward reference, acceptable.)
* Prop. 6.3: |SO(5,5)| = 9,360,000; /156 = 60000 = 125 * 480. Frame argument verified (Section 1). The alternative argument (two complementary proper subspaces hold at most 156 + 1 points < 300) is also right. det(-I) = -1 in odd dimension. The Levi factor of the line stabiliser induces all of GL(2,5) on l (the determinant condition forces the O(1,5) component to be +1), hence PGL(2,5) = S_5 on the six points.
* Remark 6.5 (not geometric): GQ(5,10) would have 561 lines; Delta has 61 six-cliques (reproduced, and no 7-clique); (5,10) is not in the list of known GQ orders. Correct.
* Remark 6.6 (other q): I rebuilt the construction from scratch over F_3, F_5, F_7 (`v7_delta.log`): Delta_3 = srg(40,12,2,4) with 40 four-cliques, canonically equal to the collinearity graph of Q(4,3) (hash 0d4a0e63) and different from W(3) (ad665721); Delta_5 canonically equal to the published file; Delta_7 is 154-regular on 1184 vertices and not srg (lambda takes values 6 and 20), and the perpendicularity graph on the 1176 non-square points is 175-regular, not srg. I did not rebuild q = 9 (needs GF(9) in my 5-dimensional code); the author's log covers it.
* The NO^{-perp}_5(5) description: perpendicularity graph on the 300 non-square points is srg(300,65,10,15) (reproduced); Brouwer's live row for (300,65,10,15) reads "NO-,orth(5,5)", so the notation NO^{-perp}_5(5) is the right transcription. See R1 for the "only q = 3, 5" citation.

### 2.6 The WLOG argument for the N = 12 SAT verdict - correct; the paper may claim more
The note's claim: permuting the grid rows (a,b) -> (s(a),b) of K(H,L) gives K(H,L^s) with L^s(s(a),s(c)) = L(a,c). Proof: K(H,L)_{(a,b),(c,d)} = (C_{L(a,c)})_{bd} depends on (a,c) only through L(a,c), so the permuted matrix has block (s(a),s(c)) equal to C_{L(a,c)} = C_{L^s(s(a),s(c))}. L^s is again a symmetric Latin square with constant diagonal 1. The map is an isomorphism Gamma_{K(H,L)} -> Gamma_{K(H,L^s)} preserving block rows and block columns, so it carries spreads of transversal cliques to spreads of transversal cliques, and with s = pi (the note writes pi^{-1}; immaterial) it carries the transversal {(a,pi(a))} to the diagonal. Since the model quantifies over all admissible L, UNSAT for "some spread contains the diagonal" implies UNSAT for "some spread exists". I also verified the matrix identity P K(H,L) P^T = K(H,L^s) in my own code for random s at n = 12, 16, 20 (`v2_khar.log`). **So the paper may state: for H = Pal_I(11) and every symmetric constant-diagonal Latin square L, Gamma_0 = Gamma_{K(H,L)} has no third spread orthogonal to the block rows and block columns** (R4).

Going further to "every Kharaghani matrix of order 144" (as the note does) needs one more step, which the note has only in outline: a general Hadamard matrix H' of order 12 with first column 1 is D_r P Pal D_c Q; column negations leave c_i c_i^T unchanged, row permutations permute grid columns, column permutations relabel L, but the row signing D_r interacts with the normalisation. One checks that K(H',L) is grid-isomorphic to K(N_j, L') where N_j is Pal_I(11) normalised at column j; and since Aut(Pal_I(11)) (which induces M_12 on the columns) is transitive on columns, N_j is a row permutation, column signing and column permutation of N_1. So the stronger claim is also correct, but it should carry this sentence if the paper makes it. I re-ran the N = 12 case with my OWN SAT model (`v8_sat12.py`, different variable set and clause generation; kissat 11 s): UNSAT. Controls Syl_8 and Pal_I(7): SAT, decoded spreads verified, deletion gives srg(64,14,6,2) = LS_2(8) exactly.

### 2.7 Small points (none is an error)
* Theorem 1.1(1) says n >= 8; Theorem 4.2 gives a connected srg already for n >= 6 (n = 6 would need a symmetric Bush-type matrix of order 36 with unit-diagonal blocks; Janko's order-36 Bush-type matrix is not stated to have this form). Consistent, just noting the gap is deliberate.
* Section 3.1: 40 orbitals = 10 + 10 + 10 + 10, 28 symmetrised classes = 9 + 9 + 10, subdegrees 1 + 11 + 11 + 55 + 66 = 144: consistent. "M_12 has no subgroup of order 165": right (a group of order 165 has a normal C_11, but N_{M_12}(C_11) has order 55).
* Section 3.3: 1451520/1260 = 1152 = |S_4 wr S_2|: consistent.

## 3. Computations re-verified with my own code

### 3.1 Exact A^2 check and canonical hashes (`v1_files.log`, `v1b_g2_only.log`)
All 11 files of `out/new_srgs_multiorbit/` are strongly regular with the stated parameters; hit306/hit576/hit1296 have the
canonical forms of srg306 (Delta), srg576 and srg1296 (symplectic): da974d5b, 077482ff, e64993c7. The four 1296-vertex graphs
have four distinct canonical forms (e64993c7, e8ba25bb, 3a31fb59, d4d55b4d). All two-spread-deleted files in
`out/family_2026_10_12/g6/` are strongly regular with LS_{n/2-1}(n) parameters, and the hashes (SHA-256 of `nauty-labelg -q`
output, first 8 hex) agree with Computation 4.18 in every entry:

| v | paper | my hashes |
|---|---|---|
| 400 | b15910f8; f0ef9bbf, a535920a; 454baa6c, a5ff9877 | b15910f8; f0ef9bbf, a535920a; 454baa6c, a5ff9877 |
| 576 | 077482ff; 0f50c45d, e737ba94; efcea09d, 0d117300; ed973300, 67918c94 | 077482ff; 0f50c45d, e737ba94; efcea09d, 0d117300; ed973300, 67918c94 |
| 784 | 1f455843; 68288734, 57b21e8e; bf91d851, e633e123 | 1f455843; 68288734, 57b21e8e; bf91d851, e633e123 |
| 1296 | e64993c7, e8ba25bb, 3a31fb59, d4d55b4d; 38798860, 0f1ea859 | e64993c7, e8ba25bb, 3a31fb59, d4d55b4d; 38798860, 0f1ea859 |

Within each row all hashes are distinct, so "at least 5, 7, 5, 6 pairwise non-isomorphic graphs" is confirmed. The
sym_*_G2 files (symmetric rule) hash to the published graphs; the N = 8 SAT controls decode to srg(64,14,6,2). The G0 and
BHK (twin) files I checked are strongly regular with LS_{n/2+1} and LS_{n/2} parameters (the 1296-vertex G0/BHK were
checked for parameters but not hashed; hashing them is not needed for any claim).

### 3.2 |Aut| (`v9_aut2.log`, dreadnaut)
Gamma_{K(Pal_I(19),L)}: |Aut| = 171 (48 orbits); Gamma_{K(Pal_I(23),L)}: |Aut| = 253; Delta: 60000 - as claimed
(the other |Aut| values of Table 7.1 were verified in round 1).

### 3.3 Kharaghani matrices and Corollary 4.6 (`v2_khar.log`)
Own build of K(H,L) with my own round-robin square for Pal_I(11), Syl_16, Pal_I(19), Pal_II(9), Pal_I(23), H_2 (x) Pal_I(11),
Pal_II(5) (x) H_2, Pal_I(27) (own GF(27) = F_3[x]/(x^3-x-1)), Pal_II(13), Pal_II(17), H_2 (x) Pal_I(19), Pal_II(9) (x) H_2,
Pal_I(43). For each: K symmetric, unit-diagonal blocks, Bush type, K^2 = n^2 I; Gamma_0, twin and Gamma_K exactly
LS_{n/2+1}, LS_{n/2}, LS_{n/2-1}: in particular srg(1600,741,344,342) (two matrices) and srg(1936,903,422,420). Corollary 4.6 and
Computation 4.7 confirmed; the file `khar_H2xPalI19_rr_G2.g6` is also srg(1600,741,344,342).

### 3.4 Clique counts and the third-spread question (`v5_cliques.log`)
n-cliques (own transversal backtracking): 0 in all 26 Kharaghani G2 files with n in {12,...,36} and in the five sym_* files;
0, 0, 0, 0, 64, 4, 12 for the seven Gamma(H) of Table 7.1 (Computation 4.17 confirmed, third program). The 64 cliques of the
symplectic graph pairwise meet in 6 (1008 pairs), 8 (945) or 16 (63) vertices - no two disjoint, so no spread; the 4 (Z_6)
and 12 (S_3) cliques are pairwise disjoint but too few. Sylvester-16 control: Gamma(Syl_16) has 448 16-cliques, exactly
54208 spreads among them (own Algorithm X, 174 s), and deleting one gives srg(256,90,34,30) = LS_6(16). All as in
Computation 4.19(1).

### 3.5 Table 4.1, Remark 4.11, Prop. 4.13 (`v3_misc.log`)
See 2.4. Block vectors h_a o h_c up to sign: 16 (Syl_16), 67, 191, 134, 379 - as stated (also 631 for Pal_II(17) and for S - I).
Outside vertices of Gamma(S-I) have 16 = n/2-2 neighbours in the diagonal clique.

### 3.6 Cocliques through (0,0) and the exact cover - NOW INDEPENDENTLY VERIFIED (`cocl_runs.log`, `v6_400.log`, `v6_controls_run.log`)
`cocl.c` enumerates all n-cocliques through vertex 0 with bitsets and Hoffman pruning (every vertex outside an n-coclique has
exactly h = kn/(v-n) neighbours in it, so an excluded vertex u needs cnt(u) <= h and cnt(u) + |N(u) & Cand| >= h); the program
derives k, lambda, mu, the Hoffman bound (= n) and h from the file itself. Controls: complements of the cyclic LS_3(7), LS_5(11),
LS_6(13) give 3, 5, 6 cocliques and the exact cover exists. Results:

| graph | cocliques through 0 (paper) | mine | nodes | time | exact cover |
|---|---|---|---|---|---|
| Gamma(Pal_II(9)), n=20 | 40 | 40 | 152,496 | 0.1 s | none |
| Gamma(Pal_II(5)(x)H_2), n=24 | 116 | 116 | 584,978 | 1 s | none |
| Gamma(Pal_II(13)), n=28 | 56 | 56 | 2,470,371 | 3 s | none |
| symplectic, n=36 | 72 | 72 | 19,671,823 | 31 s | none |
| Z_6, n=36 | 72 | 72 | 32,587,942 | 54 s | none |
| S_3, n=36 | 72 | 72 | 31,735,768 | 49 s | none |
| Pal_II(17), n=36 | 72 | 72 | 27,631,800 | 44 s | none |

Every listed coclique was re-checked to be a coclique of size n containing 0; `v6_cover.py` (own Algorithm X) finds no
sub-family of t = n/2+2 cocliques partitioning the non-neighbours of 0. So the complements are not Latin square graphs, and the
three counts the paper flags as unverified are verified by a program that shares no code or algorithm with `props.py` /
`cocl_cover.py` (R5).

### 3.7 SAT (`v8_sat.log`)
Own CNF (variables l[a][c][j] for the Latin square, p[k][a][b] for the n transversals, pi_0 = id, transversal k through (0,k);
clause: p[k][a][b] & p[k][c][d] & L(a,c)=j forbidden when H_bj != H_dj). Syl_8: SAT (708 vars, 59,400 clauses), decoded spread
verified, Gamma_K minus the spread = srg(64,14,6,2). Pal_I(7): SAT, same. Pal_I(11), n = 12: UNSAT (2454 vars, 676,824 clauses,
11 s). Computation 4.19(2) confirmed; the n = 20 timeouts I did not repeat.

### 3.8 Not re-verified in this round
* The q = 9 analogue of Delta (my field code is prime-only in dimension 5); the author's `step4_q7_q9.log` covers it.
* The nauty canonical forms of the 1296-vertex Gamma_0 and twin files (not needed for any claim).
* The Section 2-3 search pipeline, GAP rebuilds, TomLib class numbers, and the orbital labels of Table 3.1 (the hits themselves are verified by canonical form against the explicit constructions, which is what the paper rests on).
* The n = 20 SAT timeouts (they support nothing, as the paper says).
* MathSciNet and the full text of BvM (see Section 4).

## 4. Literature and novelty

* **Bibliography entries written from memory - all four check out** (WebSearch, 2026-10-12):
  Wallis, Bull. Austral. Math. Soc. 4 (1971) 41-49 (a corrigendum appeared in vol. 5 (1971) p. 431 - optional to cite);
  Fon-Der-Flaass, Adv. Geom. 2 (2002) 301-306 (issue 3); Muzychuk, J. Algebraic Combin. 25 (2007) 169-187,
  doi 10.1007/s10801-006-0030-7; Janko-Kharaghani-Tonchev, Des. Codes Cryptogr. 24 (2001) 225-232, doi 10.1023/A:1011212922844.
  Kharaghani 1985: "New classes of weighing matrices", Ars Combin. 19 (1985) 69-72 - confirmed through a Springer reference list;
  the paper's title and pages agree (my round-1 report had the singular "class"; the plural is what the citing literature uses).
* **BHK01 numbering** (checked against the text `out/family_2026_10_12/lit/BHK2001_EJC8R1.txt`): Theorem 1 (Kharaghani's construction),
  Lemma 3 (twin graph), Theorem 5 (3-e.c.), Conjecture 8 - as cited. **HT96**: Prop. 4.1 with multiplicities 1, f-K+1, g, K-1 and the
  bound g <= (f-K+1)(K-1) in Section 4 / Theorem 5.1 - as cited.
* **Kharaghani 1985 / BHK 2001 described correctly**: Theorem 1 of BHK is Kharaghani's rank-one Latin-square construction;
  Lemma 3 deletes the diagonal blocks (one spread) and gives the twin srg(4n^2, 2n^2-n, n^2-n, n^2-n) = LS_{N/2}(N) with N = 2n.
  Nothing in BHK deletes a second spread. The paper's description is accurate. (Side note the author may use: Wallis showed that
  N/2-1 MOLS of order N give a symmetric Bush-type Hadamard matrix of order N^2, and Bush's original paper concerns projective
  planes of order N - the converse direction OA -> Bush-type, which fits the paper's framing that Bush-type matrices sit "below"
  orthogonal arrays.)
* **Brouwer's live table, re-read 2026-10-12**: `? 400 171 74 72 OA(20,9)?`, `? 576 253 112 110 OA(24,11)?`,
  `? 784 351 158 156 OA(28,13)?`, `? 1296 595 274 272 OA(36,17)?`, `? 306 55 4 11` (no comment); the LS_{N/2} rows "+ ... Wallis
  (AR(2,m)+S(2,2,N)); RSHCD+; 2-graph" and the LS_{N/2+1} rows "Wallis2 ...; Goethals-Seidel(2,N-1)" are quoted verbatim in Section 9.
  No row on these vertex numbers mentions Koval or Bush. The row (300,65,10,15) reads "+ ... NO-,orth(5,5)".
* **Does any published source give LS_{N/2-1}(N) for N = 20, 24, 28, 36?** I found none: web searches for the five parameter tuples
  (with and without "srg", and complements) return nothing; searches for Bush-type Hadamard matrices with "two spreads", "second
  spread", "pseudo Latin square" return only the known one-spread results (BHK01, Muzychuk-Xiang, JKT01, Kharaghani-Suda on Bush-type
  association schemes). Brouwer's table lists only the orthogonal arrays as the known route. I could not search MathSciNet or the
  full text of BvM, so a remark buried in a paper on another subject cannot be excluded; the paper says exactly this.
* **Novelty wording is honest**: "new as far as we can determine", with the sources checked listed, and "a short step from
  [Kh85, BHK01]". Keep it. Round-1 item N3 (ask Brouwer / Kharaghani before publication) stands as advice outside the text.
* **"No OA(40,19) / OA(44,21) known"**: correct, but currently unsourced. Known lower bounds (Handbook of Combinatorial Designs,
  2nd ed., Table III.3.87; mirrored in Sage `MOLS_handbook_data`) are N(20) >= 4, N(24) >= 7, N(28) >= 5, N(36) >= 8, N(40) >= 7,
  N(44) >= 5 (older tables give 5-6 for 24 and 36), all far below the N/2-3 = 7, 9, 11, 15, 17, 19 squares needed. Cite the table (R3).
* **"NO^{+-perp}_5(q) are strongly regular only for q = 3, 5 [BvM]"**: I could not confirm the "only" from the sources available to me.
  Sage's `NonisotropicOrthogonalPolarGraph` (perp variant) allows q = 5 only, calls these Wilbrink's graphs and cites
  Brouwer-van Lint 1984, Section 7.D; for q = 3 the perpendicularity graph on the 36 non-square points is srg(36,15,6,6)
  (my computation). The exact checks of the paper and of this review show failure at q = 7 (both reviews) and q = 9 (paper). Fix: R1.

## 5. Writing

* No "no human expert" sentence; the Acknowledgements name the author as the responsible expert. The status table is accurate
  except for the two items that this round makes outdated (R5).
* Notation: Theorem 1.1(4) writes Gamma(H_12 (x) H_2) and Section 7 writes Aut H_12, but H_12 is never defined; everywhere else the
  matrix is Pal_II(5) (R2).
* Parameters, labels and cross-references are consistent (Tables 1.1, 4.1, 7.1, 8.1, the status table, the SHA-256 list; checksums
  re-verified with `sha256sum -c`; `verify_srg.py` has the sha256 prefix 26954cc37ba0bc89 quoted in the run log).
* Data availability: all scripts named exist in `scripts/new_srgs_multiorbit/`, `scripts/find2026_10_11/`, `scripts/family_2026_10_12/`.
* Typos: none found that affect meaning. "Delsarte-clique" vs "Delsarte clique" is used consistently. The abstract and
  Theorem 1.1(2) agree on 5, 7, 5, 6.

## 6. Required changes (MINOR REVISION)

* **R1 (citation precision, Remark 6.6, line ~845).** Replace "matching the fact that the graphs NO^{+-perp}_5(q) are strongly regular
  only for q = 3, 5 \cite{BvM}" by a statement with an exact location, e.g. "matching the fact that the perpendicularity graphs on the
  nonisotropic points of one type of Q(4,q) are strongly regular for q = 3 and for q = 5 (Wilbrink; \cite[Section 7.D]{BvL84},
  \cite[Section 3.1.4]{BvM}) and, by our exact checks, not for q = 7, 9", and add Brouwer-van Lint, "Strongly regular graphs and
  partial geometries", in: Enumeration and Design (1984) 85-122, to the bibliography - or, if BvM really proves "only", cite the
  proposition number. The referee could not verify the "only" from the sources available.
* **R2 (notation, Theorem 1.1(4) line ~126 and Section 7 line ~882).** Define H_12 ("the Hadamard matrix of order 12, unique up to
  equivalence; we use Pal_II(5)") at first use, or write Gamma(Pal_II(5) (x) H_2) in Theorem 1.1(4) and "the Hadamard matrix of order
  12" in Section 7.
* **R3 (source for "no OA known", Section 4.7 last paragraph lines ~561-563 and Section 9 line ~999).** Add a citation for the MOLS
  lower bounds, e.g. "(the best known lower bounds are N(20) >= 4, N(24) >= 7, N(28) >= 5, N(36) >= 8, N(40) >= 7, N(44) >= 5
  \cite[Table III.3.87]{HCD})", with C. J. Colbourn and J. H. Dinitz (eds.), Handbook of Combinatorial Designs, 2nd ed., 2007 (already
  cited as the host of \cite{CK07}; one more bibitem or a page reference). Check the exact values against the table before quoting.
* **R4 (recommended strengthening, Computation 4.19(2) and the paragraph after it, lines ~737-749).** The symmetry breaking is
  without loss of generality (Section 2.6 above). Replace "The unsatisfiable case says only what the model says: for H = Pal_I(11)
  and every admissible L, no third spread of Gamma_0 contains the diagonal transversal" by "Fixing the first transversal to be the
  diagonal loses nothing: permuting the block rows (a,b) -> (s(a),b) maps K(H,L) to K(H,L^s) with L^s(s(a),s(c)) = L(a,c), again
  admissible, and carries any transversal of a spread to the diagonal. So for H = Pal_I(11) and every admissible L, Gamma_0 has no
  third spread orthogonal to the block rows and columns." Optionally add: "Since every Hadamard matrix of order 12 is equivalent to
  Pal_I(11) and Aut(Pal_I(11)) is transitive on columns, the same holds for every Kharaghani matrix of order 144." (If the optional
  sentence is added, include the one-line reason that row signings are absorbed by re-normalising at another column.) Update the
  corresponding row of Table 10.1 ("no third spread in the tested graphs; SAT results").
* **R5 (now-outdated verification statements, Section 7 lines ~913-919, Section 8.3 item (6) line ~980, Table 10.1 row "counts of
  n-cocliques").** The counts 116, 56, 72 and the exact-cover result are now reproduced by an independent third program (this review:
  `out/referee_multiorbit_v2_fable/cocl.c`, `v6_cover.py`, with controls). Rewrite the paragraph "The coclique counts have different
  standing..." to say so (and say the first review's run was stopped at a time limit, the second review's program is a different
  algorithm: Hoffman-count pruning), change the status row to "computer; three independent programs", and in 8.3(6) drop "except the
  three coclique counts" or move it to history. Also add `out/referee_multiorbit_v2_fable/` to the Data availability statement.
* **R6 (bibliography check).** Kh85: keep "New classes of weighing matrices" (confirmed through citing literature; verify against
  zbMATH if possible). Optionally add Wallis's corrigendum, Bull. Austral. Math. Soc. 5 (1971) 431. Add \cite{BvL84} and the Handbook
  (R1, R3).

## 7. Optional suggestions

* Lemma 4.1: add the elementary proof of f - m + 1 > 0 (Section 2.1) as a footnote, so the lemma is self-contained.
* Remark 4.11: the counts 631 (Pal_II(17) and S - I) could be added for completeness; also note that in K(H,L) the block vectors
  are the n columns of H, while in Lemma 4.9 they are the n^2 products h_a o h_c.
* Section 4.9: mention that any n-clique of Gamma_K is a transversal (Lemma 4.16), so "third spread orthogonal to rows and
  columns" is the same as "spread of Gamma_K" - this is implicit now.
* Section 6: the two-graph-style explanation of the 2-transitive clique in Delta is still open (Question 11.1); fine as a question.
* Section 1 "What is known": one could add Bush's original paper (K. A. Bush, Unbalanced Hadamard matrices and finite projective
  planes of even order, J. Combin. Theory Ser. A 11 (1971) 38-44) since the matrices are named after it.
* The Acknowledgements could name this second round (same model family as the first referee round).

## 8. What I could not verify
MathSciNet; the full text of BvM (hence the "only q = 3, 5" statement and the exact BvM section); Kharaghani 1985 itself (known via
BHK and citing literature, as the paper says); the search pipeline and GAP rebuilds of Sections 2-3 (not needed for the results, which
rest on the explicit constructions and canonical forms); the q = 9 analogue of Delta; the n = 20 SAT runs (timeouts).
