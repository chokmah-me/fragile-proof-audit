new_srgs_multiorbit_data.zip -- code and data for
  A. Kovaľ, "Strongly regular graphs on 306, 400, 576, 784 and 1296 vertices from multi-orbit coset fusion and Bush-type Hadamard matrices",
  preprint, October 2026.

Repository state: git commit 5a2eba0b4504e5cf170cfc5f9360dd080f06b254 (every git-tracked file below is taken from that commit;
12 of the 285 files are not tracked in git and were taken from the working tree; they are listed at the
end of this file; out/new_srgs_multiorbit/zenodo/verify_srg.log is generated when the archive is made).
All paths are repository-relative. MANIFEST_SHA256.txt gives the full SHA-256 of every file in this archive
(except README.txt and MANIFEST_SHA256.txt themselves). The SHA-256 checksums of the graph files printed in
the paper ("Data availability"), the hash prefix of verify_srg.py in the paper's run log (Section
"Verification") and the listed programs of the appendices were compared with these files (all 14 checked to match when this archive was made).
Files are stored with LF line endings.

CONTENTS
  docs/paper/new_srgs_multiorbit.tex           LaTeX source of the paper
  out/new_srgs_multiorbit/*.g6                  the graphs of the paper, one graph6 line (LF) per file, in the
                                                vertex order of build_all.py: srg306_55_4_11, srg400_171_74_72,
                                                srg576_253_112_110, srg784_351_158_156, srg1296_595_274_272
                                                (+ _latin, _latinS3, _paley); hit*.g6 = the three search hits
                                                (306, 576, 1296) in the vertex order of the search, identical to
                                                the graphs recorded in the search's HITS.txt
  out/family_2026_10_12/g6/*.g6                 graphs of Sections "Kharaghani matrices", "Non-isomorphism",
                                                "A third spread": khar_<H>_<L>_<G> = Kharaghani matrix K(H,L) for
                                                the Hadamard matrix H and the symmetric Latin square L (rr = round
                                                robin, rrx = relabelled round robin, xor), graph G0 (LS_{n/2+1}(n)
                                                parameters), BHK (one spread deleted, LS_{n/2}(n)) or G2 (both
                                                spreads deleted, LS_{n/2-1}(n)); sym_<H>_G2 = the symmetric rule;
                                                delta_q3_ns / delta_q5_ns = Delta over F_3 / F_5; sat_*_N8_j3 =
                                                third-spread controls (n=8). khar_H2xPalI19_rr_G2,
                                                khar_PalII9xH2_rr_G2 (srg(1600,741,344,342)) and khar_PalI43_rr_G2
                                                (srg(1936,903,422,420)) were rebuilt for this archive by
                                                out/new_srgs_multiorbit/zenodo/rebuild_khar_1600_1936.py (same
                                                construction as scripts/family_2026_10_12/step2_c.py, which
                                                checked them but did not save them); log next to it
  out/family_2026_10_12/*.log                   logs of the family computations
  scripts/new_srgs_multiorbit/                  programs of the paper: build_all.py (all constructions,
                                                Appendix B), verify_srg.py (Appendix A), canon.py, props.py,
                                                hadamard_graph.py, twograph1296.py, twograph_family.py,
                                                check_stabilisers.g, exploration scripts
  scripts/family_2026_10_12/                    programs of the family computations (famlib.py, step*.py,
                                                transv.c, sat_third_spread.py, cocl_cover*.py, ...)
  docs/family_question_2026_10_12.md            notes: the graphs vs Kharaghani 1985 / Bonato-Holzmann-
                                                Kharaghani 2001, spread lemma, third spread, q-analogues
  Referee (separate Claude Fable session, own code):
  docs/referee_new_srgs_multiorbit_fable_2026_10_11.md   referee report on version 1
  out/referee_multiorbit_fable/                 its code, logs and graphs
  docs/referee_new_srgs_multiorbit_v2_fable_2026_10_12.md   second referee report (version 2)
  out/referee_multiorbit_v2_fable/              second referee: code, logs, graphs, SAT instances
  out/new_srgs_multiorbit/zenodo/               how this archive was made and checked: verify_srg.py (the
                                                archive verifier, see below) and its log verify_srg.log over
                                                every graph6 file of the archive, stage_bundle.py,
                                                verify_fresh_unzip.py, rerun.sh, rebuild_khar_1600_1936.py/.log

  Left out: compiled executables (out/referee_multiorbit_v2_fable/cocl); rebuild them from the C sources next to them.
  Included: the search programs of the find lane (scripts/find2026_10_11/: GAP stage-1 enumeration, CP-SAT
  fusion solver, GAP rebuilds of the 576/306/1296 graphs, verifier). Not included: the run directory of the
  search (large, available from the author) and the archived copies of Brouwer's table pages (third-party).

HOW TO RERUN THE CHECKS (Python 3, standard library only)

    sha256sum -c MANIFEST_SHA256.txt
    python3 out/new_srgs_multiorbit/zenodo/verify_srg.py $(find . -name "*.g6" | sort)
    python3 scripts/new_srgs_multiorbit/verify_srg.py out/new_srgs_multiorbit/*.g6
    python3 scripts/new_srgs_multiorbit/build_all.py /tmp/rebuilt && sha256sum /tmp/rebuilt/*.g6

  out/new_srgs_multiorbit/zenodo/verify_srg.py decodes graph6 itself (size prefixes "~" and "~~", malformed
  input rejected), computes every entry of A^2 exactly with integer bitsets, checks
  A^2 = kI + lambda A + mu (J-I-A) entry by entry and checks connectedness; exit status 0 iff all graphs
  pass. Expected: all 132 graphs in 132 files print OK, with parameters
    srg(40,12,2,4), srg(49,30,17,20), srg(64,14,6,2), srg(121,70,39,42)
    srg(144,55,22,20), srg(144,66,30,30), srg(144,77,40,42), srg(169,96,53,56)
    srg(256,105,44,42), srg(256,120,56,56), srg(256,135,70,72), srg(306,55,4,11)
    srg(400,171,74,72), srg(400,190,90,90), srg(400,209,108,110), srg(576,253,112,110)
    srg(576,276,132,132), srg(576,299,154,156), srg(784,351,158,156), srg(784,378,182,182)
    srg(784,405,208,210), srg(1296,595,274,272), srg(1296,665,340,342), srg(1600,741,344,342)
    srg(1936,903,422,420)
  (the per-file expectations are in verify_fresh_unzip.py). scripts/new_srgs_multiorbit/verify_srg.py is
  the shorter verifier printed in Appendix A of the paper; its output on out/new_srgs_multiorbit/*.g6 is the
  run log printed in Section "Verification". build_all.py rebuilds the eight constructed graphs of
  out/new_srgs_multiorbit/ byte for byte (the SHA-256 checksums of the paper).
  The scripts of scripts/family_2026_10_12/ and of the referee directories use numpy, nauty (labelg,
  dreadnaut), GAP or a SAT solver in places, and some contain absolute paths below /work (the container mount
  of the repository); run them with the archive root mounted or linked at /work.

UNTRACKED FILES (taken from the working tree, not in git commit 5a2eba0b4504)
  out/new_srgs_multiorbit/zenodo/rebuild_khar_1600_1936.log
  out/referee_multiorbit_v2_fable/ctrl_LS3_7_compl.g6
  out/referee_multiorbit_v2_fable/ctrl_LS5_11_compl.g6
  out/referee_multiorbit_v2_fable/ctrl_LS6_13_compl.g6
  out/referee_multiorbit_v2_fable/dn_palI23.out
  out/referee_multiorbit_v2_fable/dn_palI23.txt
  out/referee_multiorbit_v2_fable/sat_PalI11.cnf
  out/referee_multiorbit_v2_fable/sat_PalI7.cnf
  out/referee_multiorbit_v2_fable/sat_Syl8.cnf
  out/referee_multiorbit_v2_fable/v9_countg.log
  scripts/new_srgs_multiorbit/spread_sat.py
  scripts/new_srgs_multiorbit/spreads.py

License of code and data: as stated on the Zenodo record.
