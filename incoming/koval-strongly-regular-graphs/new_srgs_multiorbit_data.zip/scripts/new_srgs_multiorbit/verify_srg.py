#!/usr/bin/env python3
"""Standalone exact verifier (Python 3 standard library only).
For every graph6 line in the given files: decode it, check that the graph is simple and k-regular, and check
A^2 = k I + lambda A + mu (J - I - A) entry by entry in exact integers (common-neighbour counts of all pairs,
computed with Python integers as bitsets).  Prints the parameters and OK, or the first failure.
Usage: verify_srg.py FILE.g6 [...] """
import sys

def decode(line):
    b = [ord(c) - 63 for c in line.strip()]
    if any(x < 0 or x > 63 for x in b): raise ValueError('not graph6')
    if b[0] < 63: n, pos = b[0], 1
    elif b[1] < 63: n, pos = (b[1] << 12) | (b[2] << 6) | b[3], 4
    else: raise ValueError('n too large')
    need = n * (n - 1) // 2
    if len(b) - pos != (need + 5) // 6: raise ValueError('wrong length')
    rows = [0] * n
    q = 0
    for j in range(1, n):
        for i in range(j):
            if (b[pos + q // 6] >> (5 - q % 6)) & 1:
                rows[i] |= 1 << j; rows[j] |= 1 << i
            q += 1
    return n, rows

def check(n, rows):
    if any(rows[x] >> x & 1 for x in range(n)): return 'FAIL loop'
    deg = {bin(r).count('1') for r in rows}
    if len(deg) != 1: return 'FAIL not regular: degrees %s' % sorted(deg)
    k = deg.pop()
    if not 0 < k < n - 1: return 'FAIL complete or empty'
    lam = mu = None
    for x in range(n):
        rx = rows[x]
        for y in range(x + 1, n):
            c = bin(rx & rows[y]).count('1')
            if rx >> y & 1:
                if lam is None: lam = c
                elif c != lam: return 'FAIL adjacent pair (%d,%d): %d common neighbours, expected %d' % (x, y, c, lam)
            else:
                if mu is None: mu = c
                elif c != mu: return 'FAIL non-adjacent pair (%d,%d): %d common neighbours, expected %d' % (x, y, c, mu)
    if mu is None: return 'FAIL no non-adjacent pair'
    # A^2 = kI + lam A + mu(J-I-A): diagonal entries are the degrees (= k), off-diagonal entries checked above.
    return 'OK srg(%d,%d,%d,%d); complement srg(%d,%d,%d,%d)' % (n, k, lam, mu, n, n - k - 1, n - 2 - 2 * k + mu, n - 2 * k + lam)

if __name__ == '__main__':
    bad = 0
    for fn in sys.argv[1:]:
        with open(fn) as fh:
            for ln, line in enumerate(fh, 1):
                if not line.strip(): continue
                n, rows = decode(line)
                res = check(n, rows)
                bad += not res.startswith('OK')
                print('%s:%d  n=%d  %s' % (fn, ln, n, res), flush=True)
    sys.exit(1 if bad else 0)
