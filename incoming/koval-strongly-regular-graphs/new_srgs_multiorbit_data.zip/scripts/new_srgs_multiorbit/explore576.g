# Exploration for srg(576,253,112,110): M12 on Y = P x P* (P, P* the two 12-point M12-sets).
M := MathieuGroup(12);;
mx := MaximalSubgroupClassReps(M);;
M11t := First(mx, h -> Size(h) = 7920 and IsTransitive(h, [1..12]));;
Ps := RightCosets(M, M11t);;
homs := ActionHomomorphism(M, Ps, OnRight);;
Print("P* action degree ", NrMovedPoints(Image(homs)), "\n");
# product action on P x P* : point (p,q) -> 12*(p-1)+q
gens := GeneratorsOfGroup(M);;
prod := List(gens, g -> PermList(List([0..143], z -> 12 * ((QuoInt(z, 12) + 1)^g - 1) + (RemInt(z, 12) + 1)^Image(homs, g))));;
MY := Group(prod);;
Print("transitive on 144: ", IsTransitive(MY, [1..144]), "  |M|=", Size(MY), "\n");
St := Stabilizer(MY, 1);;
Print("stabiliser order ", Size(St), "\n");
orbs := Orbits(St, [1..144]);;
Print("suborbits ", List(orbs, Length), "\n");
# stabiliser of (p,q) as a subgroup of M on P: orbits on P
Sp := PreImage(homs, Stabilizer(Image(homs), 1));; Sp := Intersection(Sp, Stabilizer(M, 1));;
Print("Stab(p,q) on P orbits ", List(Orbits(Sp, [1..12]), Length), " order ", Size(Sp), "\n");
# duad correspondence: setwise stabiliser of {1,2} in P acting on P*
D := Stabilizer(M, [1, 2], OnSets);;
Print("Stab{p,p'} order ", Size(D), " orbits on P*: ", List(Orbits(Image(homs, D), [1..12]), Length), "\n");
D2 := Stabilizer(M, [1, 2], OnTuples);;
Print("Stab(p,p') orbits on P*: ", List(Orbits(Image(homs, D2), [1..12]), Length), "\n");
# for each suborbit of size 55/66, describe a representative (p',q') relative to (p,q) = (1,1)
for o in orbs do
  z := o[1] - 1; pp := QuoInt(z, 12) + 1; qq := RemInt(z, 12) + 1;
  Print("suborbit ", Length(o), " rep (p',q') = ", [pp, qq], "\n");
od;
QUIT;
