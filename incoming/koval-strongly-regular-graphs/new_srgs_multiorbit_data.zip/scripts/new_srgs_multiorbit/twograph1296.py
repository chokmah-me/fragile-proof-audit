"""Test: build the 1296-vertex graph from a two-graph tau on 36 points (Omega plus the ordered pairs of Omega).
  points: pairwise adjacent;  point c ~ (a,b)  iff tau(a,b,c) = 1;
  (a,b) ~ (c,d):  a=c or b=d -> no;  (c,d)=(b,a) -> yes;  c=b -> tau(a,b,d);  d=a -> tau(a,b,c);
                  {a,b},{c,d} disjoint -> tau(a,b,c) == tau(a,c,d).
Usage: twograph1296.py symplectic | latin | file.g6 (a graph on 36 vertices in the switching class) [flip]."""
import itertools, sys
arg = sys.argv[1]
flip = len(sys.argv) > 2 and sys.argv[2] == 'flip'
if arg == 'symplectic':
    V = list(itertools.product((0, 1), repeat=6))
    def B(x, y): return (x[0]*y[1] + x[1]*y[0] + x[2]*y[3] + x[3]*y[2] + x[4]*y[5] + x[5]*y[4]) % 2
    def f0(x): return (x[0]*x[1] + x[2]*x[3] + x[4]*x[5]) % 2
    W = [w for w in V if f0(w) == 0]
    add = lambda x, y: tuple((a + b) % 2 for a, b in zip(x, y))
    def tau(a, b, c): return B(add(W[a], W[b]), add(W[a], W[c]))
else:
    if arg == 'latin':
        # Latin square graph LS_3(6) of the cyclic Latin square: cells (i,j), symbol i+j mod 6
        cells = [(i, j) for i in range(6) for j in range(6)]
        E = [[int(x != y and (x[0] == y[0] or x[1] == y[1] or (x[0] + x[1] - y[0] - y[1]) % 6 == 0)) for y in cells] for x in cells]
    else:
        s = open(arg).readline().strip(); b = [ord(c) - 63 for c in s]; nn = b[0]; bits = []
        for x in b[1:]: bits += [(x >> (5 - t)) & 1 for t in range(6)]
        E = [[0] * nn for _ in range(nn)]; q = 0
        for j in range(1, nn):
            for i in range(j):
                E[i][j] = E[j][i] = bits[q]; q += 1
    def tau(a, b, c): return (E[a][b] + E[a][c] + E[b][c]) % 2
T = {}
for a, b, c in itertools.permutations(range(36), 3):
    T[a, b, c] = tau(a, b, c) ^ (1 if flip else 0)
# regularity of the two-graph: each pair in the same number of triples
cnts = {sum(T[a, b, c] for c in range(36) if c not in (a, b)) for a, b in itertools.combinations(range(36), 2)}
print('triples per pair', cnts)
pairs = [(a, b) for a in range(36) for b in range(36) if a != b]
n = 36 + len(pairs)
nb = [0] * n
def setadj(x, y):
    nb[x] |= 1 << y; nb[y] |= 1 << x
for a in range(36):
    for c in range(a + 1, 36): setadj(a, c)
for i, (a, b) in enumerate(pairs):
    for c in range(36):
        if c not in (a, b) and T[a, b, c]: setadj(c, 36 + i)
for i, (a, b) in enumerate(pairs):
    for j in range(i + 1, len(pairs)):
        c, d = pairs[j]
        if a == c or b == d: continue
        if (c, d) == (b, a): e = 1
        elif c == b: e = T[a, b, d]
        elif d == a: e = T[a, b, c]
        elif len({a, b, c, d}) == 4: e = int(T[a, b, c] == T[a, c, d])
        else: e = 0          # remaining: c == a or d == b already excluded; d == b excluded
        if e: setadj(36 + i, 36 + j)
degs = sorted({bin(m).count('1') for m in nb})
print('degrees', degs)
L, Mu = set(), set()
for x in range(n):
    for y in range(x + 1, n):
        c = bin(nb[x] & nb[y]).count('1')
        (L if nb[x] >> y & 1 else Mu).add(c)
print('lambda', sorted(L), 'mu', sorted(Mu), 'SRG' if len(degs) == 1 and len(L) == 1 and len(Mu) == 1 else 'not srg')
if len(sys.argv) > 3:
    with open(sys.argv[3], 'w') as fh:
        fh.write('graph\n%d\n' % n)
        for x in range(n): fh.write(' '.join(str(y + 1) for y in range(n) if nb[x] >> y & 1) + '\n')
