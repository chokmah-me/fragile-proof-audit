#!/usr/bin/env python3
"""nauty (dreadnaut) invariants: |Aut|, number of Aut-orbits with their sizes, and the SHA-256 of the full canonical
graph (dreadnaut 'b' output), so that graphs can be compared exactly up to isomorphism.
Usage: canon.py FILE.g6 [...]"""
import hashlib, re, subprocess, sys
sys.path.insert(0, __file__.rsplit('/', 1)[0])
from verify_srg import decode

for fn in sys.argv[1:]:
    n, rows = decode(open(fn).readline())
    edges = ';\n'.join(' '.join(str(y) for y in range(x + 1, n) if rows[x] >> y & 1) for x in range(n))
    inp = f'n={n} g\n{edges}.\n-a -m c x o b\n'
    out = subprocess.run(['dreadnaut'], input=inp, capture_output=True, text=True).stdout
    grp = re.search(r'grpsize=([0-9.e+]+)', out).group(1)
    norb = re.search(r'(\d+) orbits?;', out).group(1)
    # canonical graph: the adjacency lines printed after the labelling by 'b'
    lines = out.split('\n')
    start = [i for i, l in enumerate(lines) if re.match(r'^\s+0 :', l)][-1]
    can = '\n'.join(lines[start:]).strip()
    print(f'{fn}: n={n} |Aut|={grp} orbits={norb} canon_sha256={hashlib.sha256(can.encode()).hexdigest()[:24]}', flush=True)
