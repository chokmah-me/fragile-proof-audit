"""Graph Gamma(H) of a symmetric Hadamard matrix H of order n:
vertices [n] x [n];  (a,b) ~ (c,d)  iff  a != c, b != d and H[a][b] H[b][c] H[c][d] H[d][a] = 1.
Claim: srg(n^2, (n-1)(n-2)/2, ., .) with eigenvalues 1 + n/2, 1 - n/2.
Usage: hadamard_graph.py paley2 q | sylvester k | paley2x2 q   [out.adj]"""
import sys, itertools
def jacobsthal(q):
    if q in (9, 25):
        p = 3 if q == 9 else 5
        # F_{p^2} = F_p[i], i^2 = nonsquare r (r = 2 for p = 3, 5)
        r = 2
        el = [(a, b) for a in range(p) for b in range(p)]
        mul = lambda x, y: ((x[0] * y[0] + r * x[1] * y[1]) % p, (x[0] * y[1] + x[1] * y[0]) % p)
        sq = {mul(x, x) for x in el if x != (0, 0)}
        chi = lambda x: 0 if x == (0, 0) else (1 if x in sq else -1)
        sub = lambda x, y: ((x[0] - y[0]) % p, (x[1] - y[1]) % p)
        return [[chi(sub(x, y)) for y in el] for x in el]
    sq = {(x * x) % q for x in range(1, q)}
    return [[0 if x == y else (1 if (x - y) % q in sq else -1) for y in range(q)] for x in range(q)]
def paley2(q):
    Q = jacobsthal(q); m = q + 1
    C = [[0] + [1] * q] + [[1] + Q[i] for i in range(q)]
    n = 2 * m; H = [[0] * n for _ in range(n)]
    for i in range(m):
        for j in range(m):
            for s in range(2):
                for t in range(2):
                    if i == j: H[2*i+s][2*j+t] = [[1, -1], [-1, -1]][s][t]
                    else: H[2*i+s][2*j+t] = C[i][j] * [[1, 1], [1, -1]][s][t]
    return H
def kron(A, B):
    return [[A[i][j] * B[k][l] for j in range(len(A)) for l in range(len(B))] for i in range(len(A)) for k in range(len(B))]
def sylvester(k):
    H = [[1]]
    for _ in range(k): H = kron(H, [[1, 1], [1, -1]])
    return H
kind = sys.argv[1]; par = int(sys.argv[2])
H = paley2(par) if kind == 'paley2' else sylvester(par) if kind == 'sylvester' else kron(paley2(par), [[1, 1], [1, -1]])
n = len(H)
assert all(H[i][j] == H[j][i] for i in range(n) for j in range(n))
assert all(sum(H[i][k] * H[j][k] for k in range(n)) == (n if i == j else 0) for i in range(n) for j in range(n))
print('symmetric Hadamard of order', n, 'diagonal', sorted({H[i][i] for i in range(n)}))
V = [(a, b) for a in range(n) for b in range(n)]
N = len(V); nb = [0] * N
for x, (a, b) in enumerate(V):
    m = 0
    for y, (c, d) in enumerate(V):
        if a != c and b != d and H[a][b] * H[b][c] * H[c][d] * H[d][a] == 1: m |= 1 << y
    nb[x] = m
degs = {bin(m).count('1') for m in nb}
L, M = set(), set()
for x in range(N):
    for y in range(x + 1, N):
        (L if nb[x] >> y & 1 else M).add(bin(nb[x] & nb[y]).count('1'))
ok = len(degs) == 1 and len(L) == 1 and len(M) == 1
print(f'v={N} k={sorted(degs)} lambda={sorted(L)} mu={sorted(M)}', 'SRG' if ok else 'not srg')
if len(sys.argv) > 3:
    with open(sys.argv[3], 'w') as fh:
        fh.write('graph\n%d\n' % N)
        for x in range(N): fh.write(' '.join(str(y + 1) for y in range(N) if nb[x] >> y & 1) + '\n')
