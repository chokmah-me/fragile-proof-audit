"""Which regular two-graphs give a strongly regular graph on n^2 vertices by the 1296 rule?
Two-graph on n points given by a graph E in its switching class: tau(a,b,c) = parity of edges in {a,b,c} (xor flip).
Graph on Omega + ordered pairs (see twograph1296.py).  Tests small regular two-graphs, both orientations."""
import itertools
def build(n, T):
    pairs = [(a, b) for a in range(n) for b in range(n) if a != b]
    N = n + len(pairs); nb = [0] * N
    def s(x, y): nb[x] |= 1 << y; nb[y] |= 1 << x
    for a in range(n):
        for c in range(a + 1, n): s(a, c)
    for i, (a, b) in enumerate(pairs):
        for c in range(n):
            if c not in (a, b) and T(a, b, c): s(c, n + i)
    for i, (a, b) in enumerate(pairs):
        for j in range(i + 1, len(pairs)):
            c, d = pairs[j]
            if a == c or b == d: continue
            if (c, d) == (b, a): e = 1
            elif c == b: e = T(a, b, d)
            elif d == a: e = T(a, b, c)
            else: e = int(T(a, b, c) == T(a, c, d))
            if e: s(n + i, n + j)
    degs = {bin(m).count('1') for m in nb}
    L, M = set(), set()
    for x in range(N):
        for y in range(x + 1, N):
            (L if nb[x] >> y & 1 else M).add(bin(nb[x] & nb[y]).count('1'))
    return N, sorted(degs), sorted(L), sorted(M)
def test(name, n, E):
    for flip in (0, 1):
        T = lambda a, b, c: (E[a][b] + E[a][c] + E[b][c] + flip) % 2
        per = {sum(T(a, b, c) for c in range(n) if c not in (a, b)) for a, b in itertools.combinations(range(n), 2)}
        N, d, L, M = build(n, T)
        ok = len(d) == 1 and len(L) == 1 and len(M) == 1
        print(f'{name} n={n} flip={flip} triples/pair={sorted(per)} -> v={N} k={d} lambda={L} mu={M}', 'SRG' if ok else '')
def adj(n, rel): return [[int(x != y and rel(x, y)) for y in range(n)] for x in range(n)]
# n=6: C5 + isolated point
test('C5+pt', 6, adj(6, lambda x, y: x < 5 and y < 5 and (x - y) % 5 in (1, 4)))
# n=10: Paley(9) + isolated point
F9 = [(a, b) for a in range(3) for b in range(3)]
def sq9(a, b):   # F9 = F3[i], i^2 = -1; nonzero squares: 1, 2, i, 2i  ( (1+i)^2 = 2i )
    return (a, b) in {(1, 0), (2, 0), (0, 1), (0, 2)}
test('Paley9+pt', 10, adj(10, lambda x, y: x < 9 and y < 9 and sq9((F9[x][0] - F9[y][0]) % 3, (F9[x][1] - F9[y][1]) % 3)))
# n=16: GQ(2,2) collinearity graph (pairs of {0..5}, adjacent iff disjoint) + isolated point
P2 = list(itertools.combinations(range(6), 2))
test('GQ22+pt', 16, adj(16, lambda x, y: x < 15 and y < 15 and not set(P2[x]) & set(P2[y])))
# n=28: complement of the Schlafli graph? use the triangular graph T(8) (srg(28,12,6,4)) which lies in the switching class of a regular two-graph on 28 points
P8 = list(itertools.combinations(range(8), 2))
test('T(8)', 28, adj(28, lambda x, y: bool(set(P8[x]) & set(P8[y]))))
