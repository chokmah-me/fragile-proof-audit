"""Exploration: describe the srg(1296,595,274,272) hit in coordinates.
V = F2^6 with B(x,y) = x1y2+x2y1+x3y4+x4y3+x5y6+x6y5, f0(x) = x1x2+x3x4+x5x6.
Plus-type forms polarising to B: f_w = f0 + B(w,.) with f0(w) = 0 (36 forms).
Flags: (f, p), f a plus form, p a nonzero singular vector of f (36*35 = 1260).
Pair invariants -> classes; exhaustive DFS over symmetric unions of classes of valency 595 that give an srg."""
import itertools, sys
V = list(itertools.product((0, 1), repeat=6))
def B(x, y): return (x[0]*y[1] + x[1]*y[0] + x[2]*y[3] + x[3]*y[2] + x[4]*y[5] + x[5]*y[4]) % 2
def f0(x): return (x[0]*x[1] + x[2]*x[3] + x[4]*x[5]) % 2
def fw(w, x): return (f0(x) + B(w, x)) % 2
def add(x, y): return tuple((a + b) % 2 for a, b in zip(x, y))
Z = (0,) * 6
forms = [w for w in V if f0(w) == 0]
assert len(forms) == 36
flags = [(w, p) for w in forms for p in V if p != Z and fw(w, p) == 0]
assert len(flags) == 1260
verts = [('F', w, None) for w in forms] + [('P', w, p) for (w, p) in flags]
n = len(verts)
def inv(a, b):
    ta, wa, pa = a; tb, wb, pb = b
    u = add(wa, wb)
    if ta == 'F' and tb == 'F':
        return ('FF', u == Z)
    if ta == 'F' and tb == 'P':
        # form f_wa, flag (f_wb, q)
        q = pb
        return ('FP', u == Z, u == q, B(u, q), fw(wa, q))
    if ta == 'P' and tb == 'F':
        return ('PF',) + inv(b, a)[1:]
    p, q = pa, pb
    return ('PP', u == Z, p == q, u == p, u == q, u == add(p, q), B(p, q), B(u, p), B(u, q), fw(wa, q), fw(wb, p))
lab = {}
M = [[0] * n for _ in range(n)]
for i in range(n):
    for j in range(n):
        if i != j: M[i][j] = lab.setdefault(inv(verts[i], verts[j]), len(lab) + 1)
keys = [None] + sorted(lab, key=lambda k: lab[k])
# transpose pairing
tr = {}
for i in range(n):
    for j in range(n):
        if i != j: tr[M[i][j]] = M[j][i]
cls = []
seen = set()
for t in range(1, len(keys)):
    if t not in seen: c = {t, tr[t]}; cls.append(sorted(c)); seen |= c
x1, x2 = 0, 36          # a form and a flag
def cnt(x, c, rng): return sum(1 for y in rng if y != x and M[x][y] in c)
FR, PR = range(36), range(36, n)
# uniformity check of valencies on each orbit
for x in list(range(36)) + list(range(36, n, 97)):
    assert [cnt(x, c, range(n)) for c in cls] == [cnt(x1 if x < 36 else x2, c, range(n)) for c in cls]
print('relations', len(keys) - 1, 'symmetric classes', len(cls))
for c in cls: print('  ', [keys[t] for t in c], 'from form', cnt(x1, c, range(n)), 'from flag', cnt(x2, c, range(n)))
k, lam, mu = 595, 274, 272
d1 = [cnt(x1, c, range(n)) for c in cls]; d2 = [cnt(x2, c, range(n)) for c in cls]
L = len(cls)
r1 = [sum(d1[i:]) for i in range(L + 1)]; r2 = [sum(d2[i:]) for i in range(L + 1)]
found = []
def test(chosen):
    S = set(t for i in chosen for t in cls[i])
    nb = [0] * n
    for x in range(n):
        m = 0
        for y in range(n):
            if x != y and M[x][y] in S: m |= 1 << y
        nb[x] = m
    if any(bin(m).count('1') != k for m in nb): return False
    for x in range(n):
        for y in range(x + 1, n):
            c = bin(nb[x] & nb[y]).count('1')
            if c != (lam if nb[x] >> y & 1 else mu): return False
    return nb
def quick(chosen):
    S = set(t for i in chosen for t in cls[i])
    rows = {}
    def row(x):
        if x not in rows: rows[x] = {y for y in range(n) if y != x and M[x][y] in S}
        return rows[x]
    for x in (x1, x2):
        for y in range(n):
            if y != x:
                c = len(row(x) & row(y))
                if c != (lam if y in row(x) else mu): return False
    return True
def dfs(i, chosen, a, b):
    if a > k or b > k or a + r1[i] < k or b + r2[i] < k: return
    if i == L:
        if quick(chosen): found.append(list(chosen))
        return
    dfs(i + 1, chosen + [i], a + d1[i], b + d2[i]); dfs(i + 1, chosen, a, b)
dfs(0, [], 0, 0)
print('quick-pass unions', len(found))
for ch in found:
    nb = test(ch)
    print('UNION', [[keys[t] for t in cls[i]] for i in ch], 'SRG' if nb else 'fail')
    if nb:
        with open('/work/out/new_srgs_multiorbit/model1296.adj', 'w') as fh:
            fh.write('graph\n%d\n' % n)
            for x in range(n): fh.write(' '.join(str(y + 1) for y in range(n) if nb[x] >> y & 1) + '\n')
