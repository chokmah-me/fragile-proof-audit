# Two-point stabiliser of Sp(6,2) on the 36 cosets of S8 is S4 wr S2.
S := Image(IsomorphismPermGroup(SymplecticGroup(6, 2)));;
M := First(MaximalSubgroupClassReps(S), m -> Index(S, m) = 36);;
A := Action(S, RightCosets(S, M), OnRight);;
St := Stabilizer(A, [1, 2], OnTuples);;
Print("2-point stabiliser order ", Size(St), " iso S4 wr S2: ",
      IsomorphismGroups(St, WreathProduct(SymmetricGroup(4), SymmetricGroup(2))) <> fail, "\n");
QUIT;
