#!/usr/bin/env python3
"""Combinatorial invariants used in the paper (standard library only).
  python3 props.py delta Q             : is the Q(4,q) rule of build_all.delta an srg for q?  (q = 3, 7)
  python3 props.py edgeclique FILE m   : for the first m edges at vertex 0 (and at the last vertex), the size of a
                                         largest clique containing the edge (exact branch and bound)
  python3 props.py cliques306 FILE     : all 6-cliques of the graph on 306 vertices
  python3 props.py permcliques NAME    : all n-cliques {(a, pi(a))} of Gamma(H) for a builder matrix NAME
                                         (symplectic36 | latin36 | latinS3 | paley2:q | kron:q)"""
import sys, itertools
sys.path.insert(0, __file__.rsplit('/', 1)[0])
import build_all as BA
from verify_srg import decode, check

def maxclique(rows, cand):
    """largest clique inside the vertex bitset cand (simple greedy-colouring branch and bound)."""
    best = [0]
    def colour_order(P):
        order, bounds, col = [], [], 0
        while P:
            col += 1; Q = P
            while Q:
                v = (Q & -Q).bit_length() - 1
                Q &= ~(1 << v) & ~rows[v]; P &= ~(1 << v)
                order.append(v); bounds.append(col)
        return order, bounds
    def expand(size, P):
        order, bounds = colour_order(P)
        for i in range(len(order) - 1, -1, -1):
            if size + bounds[i] <= best[0]: return
            v = order[i]
            NP = P & rows[v]
            if NP: expand(size + 1, NP)
            elif size + 1 > best[0]: best[0] = size + 1
            P &= ~(1 << v)
    expand(0, cand)
    return best[0]

mode = sys.argv[1]
if mode == 'delta':
    q = int(sys.argv[2]); n, adj = BA.delta(q)
    rows = [sum(1 << y for y in a) for a in adj]
    print('q =', q, 'n =', n, check(n, rows))
elif mode == 'edgeclique':
    n, rows = decode(open(sys.argv[2]).readline()); m = int(sys.argv[3])
    for x in (0, n - 1):
        nbrs = [y for y in range(n) if rows[x] >> y & 1][:m]
        for y in nbrs:
            print(f'edge ({x},{y}): largest clique through it has size {2 + maxclique(rows, rows[x] & rows[y])}', flush=True)
elif mode == 'cocl':
    # graph on [n]x[n] (vertex a*n+b): for m non-adjacent pairs (0, y) in different rows and columns, the size of a
    # largest coclique containing both (exact, in the complement)
    n, rows = decode(open(sys.argv[2]).readline()); m = int(sys.argv[3]); r = int(n ** 0.5)
    full = (1 << n) - 1
    comp = [full & ~rows[x] & ~(1 << x) for x in range(n)]
    ys = [y for y in range(1, n) if not rows[0] >> y & 1 and y // r != 0 and y % r != 0][:m]
    for y in ys:
        print(f'non-edge (0,{y}): largest coclique through it has size {2 + maxclique(comp, comp[0] & comp[y])}', flush=True)
elif mode == 'cocl_count':
    # all cocliques of size r = sqrt(n) through vertex 0 (graph on [r]x[r]); prints their number and whether the
    # union of their other members covers each non-neighbour of 0 exactly once (as in the complement of an LS graph)
    n, rows = decode(open(sys.argv[2]).readline()); r = int(round(n ** 0.5))
    full = (1 << n) - 1
    comp = [full & ~rows[x] & ~(1 << x) for x in range(n)]
    found = []
    def popc(x): return bin(x).count('1')
    def ext(size, P, members):
        if size == r: found.append(members); return
        if size + popc(P) < r: return
        # colouring bound
        Q, col, bound = P, 0, 0
        while Q:
            col += 1; R = Q
            while R:
                v = (R & -R).bit_length() - 1; R &= ~(1 << v) & ~comp[v]; Q &= ~(1 << v)
        if size + col < r: return
        while P:
            if size + popc(P) < r: return
            v = (P & -P).bit_length() - 1; P &= ~(1 << v)
            ext(size + 1, P & comp[v], members + [v])
    ext(1, comp[0], [0])
    cover = {}
    for c in found:
        for v in c[1:]: cover[v] = cover.get(v, 0) + 1
    nn = [y for y in range(1, n) if comp[0] >> y & 1]
    print('cocliques of size', r, 'through vertex 0:', len(found), '; non-neighbours of 0 covered', sorted(set(cover.get(y, 0) for y in nn)))
elif mode == 'cliques306':
    n, rows = decode(open(sys.argv[2]).readline())
    cl = []
    def ext(c, P):
        if len(c) == 6: cl.append(c); return
        while P:
            v = (P & -P).bit_length() - 1; P &= ~(1 << v)
            ext(c + [v], P & rows[v])
    for x in range(n): ext([x], rows[x] & ~((1 << (x + 1)) - 1))
    print('6-cliques:', len(cl), cl[:3])
    print('omega check: 7-cliques exist?', any(rows[c[0]] & rows[c[1]] & rows[c[2]] & rows[c[3]] & rows[c[4]] & rows[c[5]] for c in cl))
elif mode == 'permcliques':
    name = sys.argv[2]
    if name.startswith('paley2:'): H = BA.paley2(int(name[7:]))
    elif name.startswith('kron:'): H = BA.kron(BA.paley2(int(name[5:])), [[1, 1], [1, -1]])
    elif name == 'latinS3': H = BA.latinS3()
    else: H = getattr(BA, name)()
    n = len(H); pi = [None] * n; used = [False] * n; count = [0]; ex = []
    def ok(a, c):
        return H[a][pi[a]] * H[pi[a]][c] * H[c][pi[c]] * H[pi[c]][a] == 1
    def bt(a):
        if a == n:
            count[0] += 1
            if len(ex) < 3: ex.append(list(pi))
            return
        for b in range(n):
            if not used[b]:
                pi[a] = b
                if all(ok(c, a) for c in range(a)):
                    used[b] = True; bt(a + 1); used[b] = False
        pi[a] = None
    bt(0)
    print(name, 'n =', n, 'Delsarte cliques (permutations pi with all pairs adjacent):', count[0])
    print('  examples:', ex[:2])
