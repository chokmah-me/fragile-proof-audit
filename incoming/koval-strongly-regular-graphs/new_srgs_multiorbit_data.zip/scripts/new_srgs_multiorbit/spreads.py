"""Spread deletion in Latin-square-type strongly regular graphs (exploration for the
multi-orbit / Hadamard paper, 2026-10-11).

Objects
-------
* Bush-type matrix K of order n^2 (rows/cols indexed by (a,b), a,b in [n]):
  - 'khar'  : Kharaghani 1985: block (a,c) = h h^T with h = column L(a,c) of a
              normalized Hadamard matrix H, L a symmetric Latin square with L(a,a)=0.
  - 'sym'   : the paper's rule for symmetric H: K_{(a,b),(c,d)} = H_ab H_bc H_cd H_da.
* Gamma0 : (a,b)~(c,d) iff K=+1 (distinct vertices). LS_{n/2+1}(n) parameters.
  Rows {a}x[n] and columns [n]x{b} are two orthogonal spreads of n-cliques.

A 'spread' is a partition of the n^2 vertices into n-cliques; for LS_t(n) parameters
every n-clique is a Delsarte clique (n = 1 - k/s).  Lemma: deleting the edges of j
pairwise orthogonal spreads (cliques from different spreads meet in exactly one vertex)
from an LS_t(n)-type srg gives an LS_{t-j}(n)-type srg.

This module enumerates, for a given K,
  T+ : transversals {(a,pi a)} that are cliques of Gamma0   (n-cliques of Gamma(H)),
  T- : transversals that are cocliques of Gamma0             (n-cliques of complement),
and searches for spreads (Latin squares) made of them, and for orthogonal pairs.

All srg claims are checked with exact integer A^2 (check_srg).
"""
import random
import sys

import numpy as np


# ---------------------------------------------------------------- Hadamard matrices
def sylvester(m):
    H = np.array([[1]], dtype=np.int64)
    for _ in range(m):
        H = np.kron(H, np.array([[1, 1], [1, -1]], dtype=np.int64))
    return H


def _gf(q):
    """Return (elements, sub, chi) for GF(q), q = p^e, via an irreducible monic polynomial
    found by brute force (no roots / no factorisation, checked by exhaustive division)."""
    import itertools
    p = next(x for x in range(2, q + 1) if q % x == 0)
    e = 0
    t = q
    while t % p == 0:
        t //= p
        e += 1
    assert t == 1
    E = list(itertools.product(range(p), repeat=e))   # coefficient tuples, low degree first
    zero = tuple([0] * e)

    def polymulmod(x, y, f):
        prod = [0] * (2 * e - 1)
        for i, xi in enumerate(x):
            if xi:
                for j, yj in enumerate(y):
                    prod[i + j] = (prod[i + j] + xi * yj) % p
        for k in range(2 * e - 2, e - 1, -1):      # reduce with monic f of degree e
            c = prod[k]
            if c:
                for j in range(e + 1):
                    prod[k - e + j] = (prod[k - e + j] - c * f[j]) % p
        return tuple(prod[:e])

    f = None
    if e == 1:
        f = (0, 1)
    else:
        for low in itertools.product(range(p), repeat=e):
            cand = tuple(low) + (1,)
            # irreducible iff the multiplicative structure is a field: x^(q-1) = 1 for all x != 0
            # and no zero divisors; check zero divisors exhaustively (q <= 49)
            ok = True
            for x in E:
                if x == zero:
                    continue
                for y in E:
                    if y != zero and polymulmod(x, y, cand) == zero:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                f = cand
                break
    sub = lambda x, y: tuple((a - b) % p for a, b in zip(x, y))
    mul = lambda x, y: polymulmod(x, y, f)
    sq = {mul(x, x) for x in E if x != zero}
    chi = lambda x: 0 if x == zero else (1 if x in sq else -1)
    return E, sub, chi


def williamson(m, rng=None):
    """Williamson Hadamard matrix of order 4m from symmetric circulants A,B,C,D (brute force,
    small odd m).  Returns the first quadruple found."""
    import itertools
    half = (m - 1) // 2
    firsts = []
    for s in itertools.product((1, -1), repeat=half):
        row = [1] + list(s) + list(reversed(s))
        firsts.append(row)
    circ = lambda r: np.array([[r[(j - i) % m] for j in range(m)] for i in range(m)], dtype=np.int64)
    mats = [circ(r) for r in firsts]
    sqs = [M @ M for M in mats]
    target = 4 * m * np.eye(m, dtype=np.int64)
    for i, j, k, l in itertools.combinations_with_replacement(range(len(mats)), 4):
        if ((sqs[i] + sqs[j] + sqs[k] + sqs[l]) == target).all():
            A, B, C, D = mats[i], mats[j], mats[k], mats[l]
            H = np.block([[A, B, C, D], [-B, A, -D, C], [-C, D, A, -B], [-D, -C, B, A]])
            if is_hadamard(H):
                return H
    return None


def jacobsthal(q):
    E, sub, chi = _gf(q)
    return np.array([[chi(sub(x, y)) for y in E] for x in E], dtype=np.int64)


def paley1(q):
    assert q % 4 == 3
    Q = jacobsthal(q)
    n = q + 1
    S = np.zeros((n, n), dtype=np.int64)
    S[0, 1:] = 1
    S[1:, 0] = -1
    S[1:, 1:] = Q
    return S + np.eye(n, dtype=np.int64)


def paley2(q):
    assert q % 4 == 1
    Q = jacobsthal(q)
    C = np.zeros((q + 1, q + 1), dtype=np.int64)
    C[0, 1:] = 1
    C[1:, 0] = 1
    C[1:, 1:] = Q
    return (np.kron(C, np.array([[1, 1], [1, -1]]))
            + np.kron(np.eye(q + 1, dtype=np.int64), np.array([[1, -1], [-1, -1]])))


def is_hadamard(H):
    n = H.shape[0]
    return bool((np.abs(H) == 1).all() and (H @ H.T == n * np.eye(n, dtype=np.int64)).all())


def normalize(H):
    H = H * H[:, :1]
    return H * H[:1, :]


# ---------------------------------------------------------------- Latin squares
def round_robin(n):
    """Symmetric Latin square of even order n, constant diagonal 0 (GK_n 1-factorisation)."""
    m = n - 1
    inv2 = pow(2, -1, m)
    L = np.zeros((n, n), dtype=np.int64)
    for i in range(m):
        for j in range(m):
            if i != j:
                L[i, j] = 1 + ((i + j) * inv2) % m
        L[i, m] = L[m, i] = 1 + i
    return L


def xor_square(n):
    """L(a,c) = a xor c (n a power of 2)."""
    return np.array([[a ^ c for c in range(n)] for a in range(n)], dtype=np.int64)


def relabel(L, rng):
    """Random relabelling of points and of the non-zero symbols (keeps symmetric, diag 0)."""
    n = L.shape[0]
    p = list(range(n))
    rng.shuffle(p)
    s = list(range(1, n))
    rng.shuffle(s)
    sym = [0] + s
    P = np.array(p)
    L2 = L[np.ix_(P, P)]
    return np.array(sym)[L2]


# ---------------------------------------------------------------- Bush-type K
def K_khar(H, L):
    H = normalize(H)
    n = H.shape[0]
    K = np.zeros((n, n, n, n), dtype=np.int64)
    for a in range(n):
        for c in range(n):
            h = H[:, L[a, c]]
            K[a, :, c, :] = np.outer(h, h)
    return K


def K_sym(H):
    assert (H == H.T).all()
    K = (H[:, :, None, None] * H[None, :, :, None] * H[None, None, :, :] * H.T[:, None, None, :])
    return K


def check_K(K):
    n = K.shape[0]
    M = K.reshape(n * n, n * n)
    I = np.eye(n * n, dtype=np.int64)
    ok = (M == M.T).all() and (M @ M == n * n * I).all() and (np.diag(M) == 1).all()
    # rows and columns are +1 blocks
    for a in range(n):
        ok = ok and (K[a, :, a, :] == 1).all()
    for b in range(n):
        ok = ok and (K[:, b, :, b] == 1).all()
    return bool(ok)


# ---------------------------------------------------------------- graphs / checks
def check_srg(A):
    """Exact integer A^2 check. Returns (v,k,lam,mu) or None."""
    A = np.asarray(A, dtype=np.int64)
    n = A.shape[0]
    if (A != A.T).any() or A.diagonal().any() or ((A != 0) & (A != 1)).any():
        return None
    deg = A.sum(1)
    if (deg != deg[0]).any():
        return None
    A2 = A @ A
    off = ~np.eye(n, dtype=bool)
    lam = set(A2[(A == 1) & off].tolist())
    mu = set(A2[(A == 0) & off].tolist())
    if len(lam) > 1 or len(mu) > 1:
        return None
    return (n, int(deg[0]), lam.pop() if lam else None, mu.pop() if mu else None)


def ls_params(n, t):
    return (n * n, t * (n - 1), n - 2 + (t - 1) * (t - 2), t * (t - 1))


def gamma0(K):
    n = K.shape[0]
    A = (K.reshape(n * n, n * n) == 1).astype(np.int64)
    np.fill_diagonal(A, 0)
    return A


def spread_matrix(classes, n):
    """Adjacency (E - I) of a spread given as list of cell-lists (cells as a*n+b)."""
    E = np.zeros((n * n, n * n), dtype=np.int64)
    for C in classes:
        for x in C:
            for y in C:
                if x != y:
                    E[x, y] = 1
    return E


def rows_spread(n):
    return [[a * n + b for b in range(n)] for a in range(n)]


def cols_spread(n):
    return [[a * n + b for a in range(n)] for b in range(n)]


def latin_spread(M):
    """Spread of transversals from a Latin square M (cells with equal symbol)."""
    n = M.shape[0]
    cl = [[] for _ in range(n)]
    for a in range(n):
        for b in range(n):
            cl[M[a, b]].append(a * n + b)
    return cl


# ---------------------------------------------------------------- transversal enumeration
def transversal_masks(K, sign):
    """mask[a][b][c] = bitmask of d (d != b) with K((a,b),(c,d)) == sign, for c != a."""
    n = K.shape[0]
    W = [1 << d for d in range(n)]
    masks = [[[0] * n for _ in range(n)] for _ in range(n)]
    for a in range(n):
        for b in range(n):
            for c in range(n):
                if c == a:
                    continue
                row = K[a, b, c, :]
                m = 0
                for d in range(n):
                    if d != b and row[d] == sign:
                        m |= W[d]
                masks[a][b][c] = m
    return masks


def enum_transversals(K, sign, limit=None, first_b=None):
    """All permutations pi with K((a,pi a),(c,pi c)) == sign for all a != c.
    Returns list of tuples pi.  Row order: dynamic (fewest options first)."""
    n = K.shape[0]
    masks = transversal_masks(K, sign)
    full = (1 << n) - 1
    out = []
    pi = [-1] * n

    def rec(avail, used):
        # avail[c] = allowed columns for unassigned row c
        best = None
        bc = n + 1
        for c in range(n):
            if pi[c] < 0:
                m = avail[c] & ~used
                cnt = bin(m).count('1')
                if cnt < bc:
                    bc = cnt
                    best = c
                    if cnt == 0:
                        return
        if best is None:
            out.append(tuple(pi))
            return limit is not None and len(out) >= limit
        c = best
        m = avail[c] & ~used
        while m:
            low = m & -m
            d = low.bit_length() - 1
            m ^= low
            pi[c] = d
            mk = masks[c][d]
            nav = [avail[x] & mk[x] if pi[x] < 0 else 0 for x in range(n)]
            if rec(nav, used | low):
                return True
            pi[c] = -1
        return False

    bs = range(n) if first_b is None else first_b
    for b in bs:
        pi[0] = b
        mk = masks[0][b]
        avail = [mk[x] if x != 0 else 0 for x in range(n)]
        if rec(avail, 1 << b):
            break
        pi[0] = -1
    return out


# ---------------------------------------------------------------- spread search (exact cover)
def find_spreads(trans, n, limit=1, seed=None):
    """Find sets of n pairwise disjoint transversals (each pi is a set of cells (a,pi[a])).
    Exact cover of the n^2 cells.  Returns list of spreads (lists of pi)."""
    cells_of = [frozenset(a * n + p[a] for a in range(n)) for p in trans]
    by_cell = [[] for _ in range(n * n)]
    for i, cs in enumerate(cells_of):
        for x in cs:
            by_cell[x].append(i)
    if seed is not None:
        r = random.Random(seed)
        for L in by_cell:
            r.shuffle(L)
    out = []
    chosen = []
    covered = set()
    alive = [True] * len(trans)

    def rec():
        if len(covered) == n * n:
            out.append([trans[i] for i in chosen])
            return len(out) >= limit
        best = None
        bc = 10 ** 9
        for x in range(n * n):
            if x in covered:
                continue
            c = sum(1 for i in by_cell[x] if alive[i])
            if c < bc:
                bc = c
                best = x
                if c == 0:
                    return False
        for i in by_cell[best]:
            if not alive[i]:
                continue
            killed = []
            for x in cells_of[i]:
                for j in by_cell[x]:
                    if alive[j]:
                        alive[j] = False
                        killed.append(j)
            chosen.append(i)
            covered.update(cells_of[i])
            if rec():
                return True
            covered.difference_update(cells_of[i])
            chosen.pop()
            for j in killed:
                alive[j] = True
        return False

    rec()
    return out


def spread_to_latin(spread, n):
    M = -np.ones((n, n), dtype=np.int64)
    for s, p in enumerate(spread):
        for a in range(n):
            M[a, p[a]] = s
    assert (M >= 0).all()
    return M


def orthogonal(M1, M2):
    n = M1.shape[0]
    return len({(M1[a, b], M2[a, b]) for a in range(n) for b in range(n)}) == n * n


if __name__ == '__main__':
    print('library; see spread_explore.py', file=sys.stderr)
