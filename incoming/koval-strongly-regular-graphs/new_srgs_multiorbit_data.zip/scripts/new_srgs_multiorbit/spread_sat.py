"""SAT search for a third spread in a Kharaghani Bush-type graph Gamma0(H, L).

Given a normalized Hadamard matrix H of order n (fixed), search simultaneously for
  * a symmetric Latin square L with L(a,a) = 0 (a 1-factorisation of K_n whose colour
    classes are matched with the non-constant columns 1..n-1 of H), and
  * a Latin square M (the spread: cells with equal symbol),
such that every class of M is a clique (mode 'clique') or a coclique (mode 'coclique')
of Gamma0, where (a,b) ~ (c,d) iff h_{L(a,c)}(b) h_{L(a,c)}(d) = 1 (a != c).

mode clique   : Gamma0 minus rows, columns and M is LS_{n/2-2}(n)  (spread lemma, j = 3)
mode coclique : complement(Gamma0) minus M is LS_{n/2-1}(n)        (spread lemma, j = 1)

Encoding (O(n^4) clauses):
  L[a][c][i]  (a<c, 1<=i<n)   L(a,c) = i
  Q[a][c][b]  (a<c)           h_{L(a,c)}(b) = +1
  M[a][b][x]                  M(a,b) = x
  U[a][c][x]  (a<c)           Q[a][c][ rho_a^{-1}(x) ]   (rho_a = row a of M)
  V[a][c][x]  (a<c)           Q[a][c][ rho_c^{-1}(x) ]
  clique: U = V ; coclique: U != V.
Symmetry breaking (relabel M's symbols and the block index a, both isomorphisms):
  M(0,b) = b, M(a,0) = a.

Every solution is decoded and checked exactly (spreads.check_srg on the resulting graph).
"""
import os
import subprocess
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import spreads as S  # noqa: E402


class CNF:
    def __init__(self):
        self.nv = 0
        self.cl = []

    def var(self):
        self.nv += 1
        return self.nv

    def add(self, c):
        self.cl.append(c)

    def exactly_one(self, xs):
        self.add(list(xs))
        xs = list(xs)
        if len(xs) <= 6:
            for i in range(len(xs)):
                for j in range(i + 1, len(xs)):
                    self.add([-xs[i], -xs[j]])
        else:  # sequential counter AMO
            s = [self.var() for _ in range(len(xs) - 1)]
            self.add([-xs[0], s[0]])
            for i in range(1, len(xs) - 1):
                self.add([-xs[i], s[i]])
                self.add([-s[i - 1], s[i]])
                self.add([-xs[i], -s[i - 1]])
            self.add([-xs[-1], -s[-1]])

    def write(self, path):
        with open(path, 'w') as f:
            f.write('p cnf %d %d\n' % (self.nv, len(self.cl)))
            for c in self.cl:
                f.write(' '.join(map(str, c)) + ' 0\n')


def build(H, mode):
    H = S.normalize(H)
    n = H.shape[0]
    F = CNF()
    pairs = [(a, c) for a in range(n) for c in range(a + 1, n)]
    L = {(a, c): {i: F.var() for i in range(1, n)} for (a, c) in pairs}
    Q = {(a, c): [F.var() for _ in range(n)] for (a, c) in pairs}
    M = [[[F.var() for _ in range(n)] for _ in range(n)] for _ in range(n)]
    U = {(a, c): [F.var() for _ in range(n)] for (a, c) in pairs}
    V = {(a, c): [F.var() for _ in range(n)] for (a, c) in pairs}
    Lv = lambda a, c, i: L[(min(a, c), max(a, c))][i]
    # L: symmetric unipotent Latin square
    for (a, c) in pairs:
        F.exactly_one([L[(a, c)][i] for i in range(1, n)])
    for a in range(n):
        for i in range(1, n):
            F.exactly_one([Lv(a, c, i) for c in range(n) if c != a])
    # Q from L and H
    for (a, c) in pairs:
        for i in range(1, n):
            for b in range(n):
                F.add([-L[(a, c)][i], Q[(a, c)][b] if H[b, i] == 1 else -Q[(a, c)][b]])
    # M Latin square
    for a in range(n):
        for b in range(n):
            F.exactly_one([M[a][b][x] for x in range(n)])
    for a in range(n):
        for x in range(n):
            F.exactly_one([M[a][b][x] for b in range(n)])
    for b in range(n):
        for x in range(n):
            F.exactly_one([M[a][b][x] for a in range(n)])
    for b in range(n):
        F.add([M[0][b][b]])
    for a in range(n):
        F.add([M[a][0][a]])
    # U, V
    for (a, c) in pairs:
        for b in range(n):
            q = Q[(a, c)][b]
            for x in range(n):
                u = U[(a, c)][x]
                F.add([-M[a][b][x], -u, q])
                F.add([-M[a][b][x], u, -q])
                v = V[(a, c)][x]
                F.add([-M[c][b][x], -v, q])
                F.add([-M[c][b][x], v, -q])
        for x in range(n):
            u, v = U[(a, c)][x], V[(a, c)][x]
            if mode == 'clique':
                F.add([-u, v])
                F.add([u, -v])
            else:
                F.add([u, v])
                F.add([-u, -v])
    return F, L, M, n


def decode(model, L, M, n):
    Lm = np.zeros((n, n), dtype=np.int64)
    for (a, c), d in L.items():
        for i, v in d.items():
            if model.get(v, False):
                Lm[a, c] = Lm[c, a] = i
    Mm = np.zeros((n, n), dtype=np.int64)
    for a in range(n):
        for b in range(n):
            for x in range(n):
                if model.get(M[a][b][x], False):
                    Mm[a, b] = x
    return Lm, Mm


def verify(H, Lm, Mm, mode):
    """Exact check. Returns the parameters of the resulting graph and the graph."""
    n = H.shape[0]
    K = S.K_khar(H, Lm)
    assert S.check_K(K)
    A0 = S.gamma0(K)
    assert S.check_srg(A0) == S.ls_params(n, n // 2 + 1)
    Es = S.spread_matrix(S.latin_spread(Mm), n)
    if mode == 'clique':
        G = A0 - S.spread_matrix(S.rows_spread(n), n) - S.spread_matrix(S.cols_spread(n), n) - Es
        want = S.ls_params(n, n // 2 - 2)
    else:
        Ac = 1 - A0 - np.eye(n * n, dtype=np.int64)
        G = Ac - Es
        want = S.ls_params(n, n // 2 - 1)
    p = S.check_srg(G)
    return p, want, G


def run(H, mode, timeout, workdir, tag):
    t0 = time.time()
    F, L, M, n = build(H, mode)
    cnf = os.path.join(workdir, tag + '.cnf')
    F.write(cnf)
    print('[%s] n=%d mode=%s vars=%d clauses=%d (build %.1fs)' % (tag, n, mode, F.nv, len(F.cl), time.time() - t0),
          flush=True)
    t1 = time.time()
    try:
        r = subprocess.run(['/work/bin/kissat', '-q', '--time=%d' % timeout, cnf], capture_output=True, text=True)
        out = r.stdout
    finally:
        os.remove(cnf)
    status = 'UNKNOWN'
    model = {}
    for line in out.splitlines():
        if line.startswith('s '):
            status = line[2:].strip()
        elif line.startswith('v '):
            for t in line[2:].split():
                v = int(t)
                if v:
                    model[abs(v)] = v > 0
    print('[%s] kissat: %s (%.1fs)' % (tag, status, time.time() - t1), flush=True)
    if status == 'SATISFIABLE':
        Lm, Mm = decode(model, L, M, n)
        p, want, G = verify(H, Lm, Mm, mode)
        print('[%s] exact check: %s  wanted %s  %s' % (tag, p, want, 'OK' if p == want else 'FAIL'), flush=True)
        np.save(os.path.join(workdir, tag + '_L.npy'), Lm)
        np.save(os.path.join(workdir, tag + '_M.npy'), Mm)
        return status, Lm, Mm
    return status, None, None


if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('hname')
    ap.add_argument('mode', choices=['clique', 'coclique'])
    ap.add_argument('--timeout', type=int, default=600)
    ap.add_argument('--out', default='/work/out/spread_deletion')
    a = ap.parse_args()
    H2 = np.array([[1, 1], [1, -1]], dtype=np.int64)
    HS = {
        'syl8': lambda: S.sylvester(3), 'syl16': lambda: S.sylvester(4),
        'palI11': lambda: S.paley1(11), 'palII5': lambda: S.paley2(5),
        'palI19': lambda: S.paley1(19), 'palII9': lambda: S.paley2(9), 'will5': lambda: S.williamson(5),
        'palI23': lambda: S.paley1(23), 'H2xH12': lambda: np.kron(H2, S.paley1(11)),
        'palI27': lambda: S.paley1(27), 'palII13': lambda: S.paley2(13), 'will7': lambda: S.williamson(7),
    }
    H = HS[a.hname]()
    assert S.is_hadamard(H)
    run(H, a.mode, a.timeout, a.out, '%s_%s' % (a.hname, a.mode))
