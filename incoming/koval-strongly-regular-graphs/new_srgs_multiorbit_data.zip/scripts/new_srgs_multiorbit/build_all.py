#!/usr/bin/env python3
"""Builders for the graphs of docs/paper/new_srgs_multiorbit.tex (standard library only).

  Gamma(H)   for a symmetric Hadamard matrix H of order n:
             vertices (a,b) in [n]x[n];  (a,b) ~ (c,d)  iff  a != c, b != d, H[a][b]H[b][c]H[c][d]H[d][a] = 1.
  Delta_306  the graph on the 300 non-square points of Q(4,5) and the 6 points of a totally singular line l.

Writes out/new_srgs_multiorbit/<name>.g6 (one graph per file, one line + LF).
Usage: build_all.py [OUTDIR] [names...]   (default: all)"""
import itertools, os, sys

# ---------------------------------------------------------------- graph6
def to_g6(n, adj):
    """adj: list of sets.  graph6 for n < 258048."""
    if n < 63: head = [n]
    else: head = [63, (n >> 12) & 63, (n >> 6) & 63, n & 63]
    bits = []
    for j in range(1, n):
        for i in range(j):
            bits.append(1 if j in adj[i] else 0)
    while len(bits) % 6: bits.append(0)
    body = [sum(bits[t + s] << (5 - s) for s in range(6)) for t in range(0, len(bits), 6)]
    return ''.join(chr(x + 63) for x in head + body)

# ---------------------------------------------------------------- symmetric Hadamard matrices
def kron(A, B):
    return [[A[i][j] * B[k][l] for j in range(len(A)) for l in range(len(B))]
            for i in range(len(A)) for k in range(len(B))]

def jacobsthal(q):
    """Jacobsthal matrix of F_q, q = p or p^2 (F_{p^2} = F_p[i], i^2 = 2, 2 a non-square mod p for p = 3, 5)."""
    if q in (9, 25):
        p = 3 if q == 9 else 5
        el = [(a, b) for a in range(p) for b in range(p)]
        mul = lambda x, y: ((x[0] * y[0] + 2 * x[1] * y[1]) % p, (x[0] * y[1] + x[1] * y[0]) % p)
        sq = {mul(x, x) for x in el if x != (0, 0)}
        sub = lambda x, y: ((x[0] - y[0]) % p, (x[1] - y[1]) % p)
        chi = lambda x: 0 if x == (0, 0) else (1 if x in sq else -1)
        return [[chi(sub(x, y)) for y in el] for x in el]
    sq = {(x * x) % q for x in range(1, q)}
    return [[0 if x == y else (1 if (x - y) % q in sq else -1) for y in range(q)] for x in range(q)]

def paley2(q):
    """Paley II symmetric Hadamard matrix of order 2(q+1), q = 1 mod 4:  H = C (x) [[1,1],[1,-1]] + I (x) [[1,-1],[-1,-1]],
    C the symmetric conference matrix [[0, 1^T], [1, Q]]."""
    Q = jacobsthal(q); m = q + 1
    C = [[0] + [1] * q] + [[1] + Q[i] for i in range(q)]
    return [[(C[i][j] * [[1, 1], [1, -1]][s][t]) if i != j else [[1, -1], [-1, -1]][s][t]
             for j in range(m) for t in range(2)] for i in range(m) for s in range(2)]

def symplectic36():
    """H = S - I, S the Seidel matrix (-1)^{B(w_a,w_b)} on the 36 vectors w of F_2^6 with f0(w) = 0."""
    B = lambda x, y: (x[0]*y[1] + x[1]*y[0] + x[2]*y[3] + x[3]*y[2] + x[4]*y[5] + x[5]*y[4]) % 2
    f0 = lambda x: (x[0]*x[1] + x[2]*x[3] + x[4]*x[5]) % 2
    W = [w for w in itertools.product((0, 1), repeat=6) if f0(w) == 0]
    return [[-1 if a == b else (-1) ** B(W[a], W[b]) for b in range(36)] for a in range(36)]

def latin36():
    """H = 2E - J, E the Latin square graph LS_3(6) of the cyclic Latin square of order 6 (an srg(36,15,6,6))."""
    cells = [(i, j) for i in range(6) for j in range(6)]
    E = lambda x, y: x != y and (x[0] == y[0] or x[1] == y[1] or (x[0] + x[1] - y[0] - y[1]) % 6 == 0)
    return [[(1 if E(x, y) else -1) if x != y else -1 for y in cells] for x in cells]

def latinS3():
    """H = 2E - J, E the Latin square graph LS_3(6) of the Cayley table of S_3."""
    G = list(itertools.permutations(range(3)))
    mul = lambda g, h: tuple(g[h[i]] for i in range(3))
    L = [[G.index(mul(g, h)) for h in G] for g in G]
    cells = [(i, j) for i in range(6) for j in range(6)]
    E = lambda x, y: x != y and (x[0] == y[0] or x[1] == y[1] or L[x[0]][x[1]] == L[y[0]][y[1]])
    return [[(1 if E(x, y) else -1) if x != y else -1 for y in cells] for x in cells]

def check_hadamard(H):
    n = len(H)
    assert all(H[i][j] == H[j][i] for i in range(n) for j in range(n)), 'not symmetric'
    assert all(sum(H[i][k] * H[j][k] for k in range(n)) == (n if i == j else 0)
               for i in range(n) for j in range(n)), 'not Hadamard'

def gamma(H):
    check_hadamard(H)
    n = len(H); V = [(a, b) for a in range(n) for b in range(n)]
    adj = [set() for _ in V]
    for x, (a, b) in enumerate(V):
        for y in range(x + 1, len(V)):
            c, d = V[y]
            if a != c and b != d and H[a][b] * H[b][c] * H[c][d] * H[d][a] == 1:
                adj[x].add(y); adj[y].add(x)
    return len(V), adj

# ---------------------------------------------------------------- the graph on 306 vertices
def delta(q):
    """Points of PG(4,q), Q = y0^2 + y1 y2 + y3 y4, l = <e1,e3>.  Vertices: the non-square points (Q(y) a non-square)
    and the q+1 points of l.  l is a clique; y ~ P (P on l) iff B(y,P) = 0; for non-square y != z:
    y ~ z iff (B(y,z) = 0 and P(y) != P(z)) or z lies on the line <y, P(y)>, where P(y) = the point of l orthogonal to y."""
    p = q
    Q = lambda y: (y[0] * y[0] + y[1] * y[2] + y[3] * y[4]) % p
    B = lambda y, z: (2 * y[0] * z[0] + y[1] * z[2] + y[2] * z[1] + y[3] * z[4] + y[4] * z[3]) % p
    def norm(y):
        for c in y:
            if c: inv = pow(c, p - 2, p); return tuple((inv * a) % p for a in y)
    sq = {(x * x) % p for x in range(1, p)}
    pts = sorted({norm(y) for y in itertools.product(range(p), repeat=5) if any(y)})
    N = [y for y in pts if Q(y) and Q(y) not in sq]
    L = sorted({norm((0, a, 0, b, 0)) for a in range(p) for b in range(p) if (a, b) != (0, 0)})
    att = {y: norm((0, y[4], 0, (-y[2]) % p, 0)) for y in N}           # P(y): a1 y2 + a3 y4 = 0
    V = N + L; idx = {v: i for i, v in enumerate(V)}
    adj = [set() for _ in V]
    def e(x, y): adj[x].add(y); adj[y].add(x)
    for i in range(len(N), len(V)):
        for j in range(i + 1, len(V)): e(i, j)
    for y in N: e(idx[y], idx[att[y]])
    for i, y in enumerate(N):
        line = {norm(tuple((y[t] + s * att[y][t]) % p for t in range(5))) for s in range(p)}
        for j in range(i + 1, len(N)):
            z = N[j]
            if (B(y, z) == 0 and att[y] != att[z]) or z in line: e(i, j)
    return len(V), adj

BUILDERS = {
    'srg306_55_4_11':            lambda: delta(5),
    'srg400_171_74_72':          lambda: gamma(paley2(9)),
    'srg576_253_112_110':        lambda: gamma(kron(paley2(5), [[1, 1], [1, -1]])),
    'srg784_351_158_156':        lambda: gamma(paley2(13)),
    'srg1296_595_274_272':       lambda: gamma(symplectic36()),
    'srg1296_595_274_272_latin': lambda: gamma(latin36()),
    'srg1296_595_274_272_paley': lambda: gamma(paley2(17)),
    'srg1296_595_274_272_latinS3': lambda: gamma(latinS3()),
}

if __name__ == '__main__':
    out = sys.argv[1] if len(sys.argv) > 1 else 'out/new_srgs_multiorbit'
    names = sys.argv[2:] or list(BUILDERS)
    os.makedirs(out, exist_ok=True)
    for name in names:
        n, adj = BUILDERS[name]()
        with open(os.path.join(out, name + '.g6'), 'w', newline='\n') as fh:
            fh.write(to_g6(n, adj) + '\n')
        print(name, n, 'written', flush=True)
