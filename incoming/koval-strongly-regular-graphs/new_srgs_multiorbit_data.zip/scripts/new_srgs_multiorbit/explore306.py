"""Exploration: is the srg(306,55,4,11) hit an L-invariant graph on (300 points of PG(4,5)) + (6 points of a line l)?
Q(y) = y0^2 + y1 y2 + y3 y4 over F5, l = <e1,e3>.  Each off-l^perp point y is attached to P(y) = l cap y^perp.
Search all unions of pair-invariant classes on the 300 points (degree 54) for which the 306-graph is srg(306,55,4,11)."""
import itertools, sys
import numpy as np
p = 5
SQ = {1, 4}
def Q(y): return (y[0] * y[0] + y[1] * y[2] + y[3] * y[4]) % p
def B(y, z): return (2 * y[0] * z[0] + y[1] * z[2] + y[2] * z[1] + y[3] * z[4] + y[4] * z[3]) % p
def norm(y):
    for c in y:
        if c:
            inv = pow(c, p - 2, p); return tuple((inv * a) % p for a in y)
pts = sorted({norm(y) for y in itertools.product(range(p), repeat=5) if any(y)})
assert len(pts) == 781
lpts = [norm((0, a1, 0, a3, 0)) for a1 in range(p) for a3 in range(p) if (a1, a3) != (0, 0)]
lpts = sorted(set(lpts)); assert len(lpts) == 6
def attach(y):
    # point a1 e1 + a3 e3 with B(y,a) = a1 y2 + a3 y4 = 0
    return norm((0, y[4] % p, 0, (-y[2]) % p, 0))
def rep(y, c):
    """scale the point y to a vector with Q = c (c in {1,2}); return one of the two such vectors"""
    for s in range(1, p):
        z = tuple((s * a) % p for a in y)
        if Q(z) == c: return z
    return None
which = sys.argv[1] if len(sys.argv) > 1 else 'sq'
if which == 'sq':
    V = [y for y in pts if Q(y) in SQ and (y[2], y[4]) != (0, 0)]
    V = [rep(y, 1) for y in V]
else:
    V = [y for y in pts if Q(y) in {2, 3}]
    V = [rep(y, 2) for y in V]
assert len(V) == 300, len(V)
def inv(y, z):
    c0 = Q(y)
    beta = (B(y, z) ** 2 * pow(c0 * c0, p - 2, p)) % p
    same = attach(y) == attach(z)
    cc = tt = None
    if same:
        # pi(y) = c pi(z)
        py, pz = (y[2], y[4]), (z[2], z[4])
        for c in range(1, p):
            if ((c * pz[0]) % p, (c * pz[1]) % p) == py: break
        cc = min(c, p - c)
        w = tuple((a - c * b) % p for a, b in zip(y, z))
        tt = Q(w)
    return (beta, same, cc, tt)
n = 300
lab = {}
M = [[None] * n for _ in range(n)]
for i in range(n):
    for j in range(n):
        if i != j:
            k = inv(V[i], V[j]); M[i][j] = lab.setdefault(k, len(lab))
keys = sorted(lab, key=lambda k: lab[k])
deg = [sum(1 for j in range(n) if j != 0 and M[0][j] == t) for t in range(len(keys))]
degs_all = [[sum(1 for j in range(n) if j != i and M[i][j] == t) for t in range(len(keys))] for i in range(n)]
print('classes', len(keys), 'uniform valencies', all(d == deg for d in degs_all))
for k, d in zip(keys, deg): print('  ', k, d)
L = np.array([[lab and (M[i][j] if i != j else -1) for j in range(n)] for i in range(n)])
att = [lpts.index(attach(y)) for y in V]
found = 0
for r in range(1, len(keys) + 1):
    for S in itertools.combinations(range(len(keys)), r):
        if sum(deg[t] for t in S) != 54: continue
        A = np.zeros((306, 306), dtype=np.int64)
        A[:300, :300] = np.isin(L, S)
        for i in range(300): A[i, 300 + att[i]] = A[300 + att[i], i] = 1
        A[300:, 300:] = 1 - np.eye(6, dtype=np.int64)
        if not (A.sum(1) == 55).all(): continue
        A2 = A @ A; I = np.eye(306, dtype=np.int64); J = np.ones_like(A)
        if (A2 == 55 * I + 4 * A + 11 * (J - I - A)).all():
            found += 1; print('SRG', [keys[t] for t in S])
            with open(f'/work/out/new_srgs_multiorbit/model306_{which}_{found}.adj', 'w') as fh:
                fh.write('graph\n306\n')
                for i in range(306): fh.write(' '.join(str(j + 1) for j in np.nonzero(A[i])[0]) + '\n')
print('found', found)
