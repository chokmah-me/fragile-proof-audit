"""Shard driver: driver.py PASSFILE RANKMIN RANKMAX SHARD NSHARDS TAG [CHUNK]
Exports two-orbit actions (GAP, export.g) chunk by chunk and solves them (solve.py), appending to
/work/out/find2026_10_11/results_TAG_SHARD.tsv; finished jobs are listed in done_TAG_SHARD.txt (resumable)."""
import sys, os, subprocess, glob
pf, rmin, rmax, sh, ns, tag = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5]), sys.argv[6]
chunk = int(sys.argv[7]) if len(sys.argv) > 7 else 60
base = '/work/out/find2026_10_11'
jobs = []
for n, line in enumerate(open(pf)):
    a = line.rstrip('\n').split('\t')
    if len(a) < 8 or line.startswith('#'): continue
    if rmin <= int(a[6]) <= rmax and n % ns == sh: jobs.append((a[0], int(a[1]), int(a[2]), int(a[6])))
jobs.sort(key=lambda t: (t[3] // 10, t[0]))
donef = f'{base}/done_{tag}_{sh}.txt'
done = set(open(donef).read().split('\n')) if os.path.exists(donef) else set()
key = lambda j: f'{j[0]}|{j[1]}|{j[2]}'
jobs = [j for j in jobs if key(j) not in done]
print(f'shard {sh}: {len(jobs)} jobs to do', flush=True)
wd = f'/tmp/f2_{tag}_{sh}'; os.makedirs(wd, exist_ok=True)
res = open(f'{base}/results_{tag}_{sh}.tsv', 'a')
for c in range(0, len(jobs), chunk):
    part = jobs[c:c + chunk]
    for f in glob.glob(wd + '/*.txt'): os.remove(f)
    jl = 'F2_JOBS := [' + ','.join('["%s",%d,%d]' % j[:3] for j in part) + '];\nF2_DIR := "%s";\n' % wd
    open(wd + '/jobs.g', 'w').write(jl)
    open(wd + '/run.g', 'w').write(f'F2_JOBFILE := "{wd}/jobs.g";\nRead("/work/scripts/find2026_10_11/export.g");\n')
    try:
        subprocess.run(['gap', '-q', '-o', '6g', wd + '/run.g'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=3600)
    except subprocess.TimeoutExpired:
        res.write(f'CHUNK_EXPORT_TIMEOUT\t{part[0]}\n')
    files = sorted(glob.glob(wd + '/*__*.txt'))
    open(wd + '/list', 'w').write('\n'.join(files) + '\n')
    out = subprocess.run(['/opt/ortools-venv/bin/python', '/work/scripts/find2026_10_11/solve.py', '@' + wd + '/list',
                          os.environ.get('F2_TARGETS', f'{base}/open_sets.tsv'), os.environ.get('F2_TL', '30'), os.environ.get('F2_HITS', f'{base}/hits')], capture_output=True, text=True)
    res.write(out.stdout); res.flush()
    if out.stderr.strip(): res.write('STDERR\t' + out.stderr.strip().replace('\n', ' | ')[:500] + '\n')
    got = {os.path.basename(f) for f in files}
    with open(donef, 'a') as fh:
        for j in part:
            fn = (j[0].replace('/', '_').replace(' ', '_')) + f'__{j[1]}_{j[2]}.txt'
            if fn in got: fh.write(key(j) + '\n')
            else: res.write(f'NOTEXPORTED\t{key(j)}\n')
    print(f'shard {sh}: {min(c + chunk, len(jobs))}/{len(jobs)}', flush=True)
