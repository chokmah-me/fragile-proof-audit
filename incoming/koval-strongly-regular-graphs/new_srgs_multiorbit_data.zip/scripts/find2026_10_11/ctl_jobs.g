LoadPackage("tomlib");
F2_DIR := "/work/out/find2026_10_11/ctl_jobs";
F2_JOBS := [];
for spec in [["A6.2_1", [12,15]], ["U3(5).2", [50,50]], ["M22", [22,77]], ["A8", [15, 20]]] do
  tom := TableOfMarks(spec[1]); o := OrdersTom(tom); n := o[Length(o)];
  for i in [1..Length(o)] do for j in [i..Length(o)] do
    if SortedList([n/o[i], n/o[j]]) = SortedList(spec[2]) then Add(F2_JOBS, [spec[1], i, j]); fi;
  od; od;
od;
Print(F2_JOBS, "\n");
