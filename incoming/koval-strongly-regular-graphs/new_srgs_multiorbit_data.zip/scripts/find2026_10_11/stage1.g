# Stage 1 (v2): every TomLib table; every pair i<=j of subgroup classes, idx>=2, idx_i+idx_j = v of an open
# integral target; keep pairs where (a) the action on the two orbits is faithful and (b) the equitable-partition
# condition d12 = (k-theta)*idx_j/v in Z_{>0} holds for some target and theta in {r,s}.  Output suborbit data.
LoadPackage("tomlib");
if IsBound(F1_TFILE) then Read(F1_TFILE); else Read("/work/out/find2026_10_11/open_targets.g"); fi;   # OPENT := [[v,k,r,s,l,m],...]
VS := Set(List(OPENT, t -> t[1]));
out := OutputTextFile(F1_OUT, false); SetPrintFormattingStatus(out, false);
Arith := function(v, a, b)   # a = idx_i, b = idx_j
  local t, th, res; res := [];
  for t in Filtered(OPENT, t -> t[1] = v) do
    for th in [t[3], t[4]] do
      if ((t[2]-th)*b) mod v = 0 and (t[2]-th)*b/v > 0 and (t[2]-th)*b/v <= t[2] and (t[2]-th)*a/v <= t[2] then
        Add(res, [t[2], th]); fi;
    od;
  od;
  return res;
end;
Row := function(tom, i) local r; r := List(OrdersTom(tom), x -> 0); r{SubsTom(tom)[i]} := MarksTom(tom)[i]; return r; end;
Dec := function(tom, M, o, a, b)   # list of [|Ha|/|K|, |Hb|/|K|, mult]  (M = sparse row cache)
  local d, n, res, K;
  d := DecomposedFixedPointVector(tom, List([1..Length(o)], k -> M(a)[k]*M(b)[k]));
  n := o[Length(o)]; res := [];
  for K in [1..Length(d)] do if d[K] <> 0 then Add(res, [o[a]/o[K], o[b]/o[K], d[K]]); fi; od;
  return res;
end;
names := AllLibTomNames();
for nmi in F1_RANGE do
  nm := names[nmi];
  tom := TableOfMarks(nm); o := OrdersTom(tom); n := o[Length(o)];
  idx := List(o, x -> n/x); lens := LengthsTom(tom);
  cand := Filtered([1..Length(o)], i -> idx[i] >= 2 and idx[i] <= 1298);
  normals := Filtered([2..Length(o)], k -> lens[k] = 1);
  M := fail; cnt := 0;
  for i in cand do for j in cand do
    if j >= i and idx[i]+idx[j] in VS then
      ar := Arith(idx[i]+idx[j], idx[i], idx[j]);
      if ar <> [] then
        if M = fail then rc := []; M := function(r) if not IsBound(rc[r]) then rc[r] := Row(tom, r); fi; return rc[r]; end; fi;
        if not ForAny(normals, k -> M(i)[k] = idx[i] and M(j)[k] = idx[j]) then
          cnt := cnt + 1;
          WriteAll(out, Concatenation(nm, "\t", String(n), "\t", String(i), "\t", String(j), "\t",
            String(idx[i]), "\t", String(idx[j]), "\t", String(ar), "\t", String(Dec(tom,M,o,i,i)), "\t",
            String(Dec(tom,M,o,j,j)), "\t", String(Dec(tom,M,o,i,j)), "\n"));
        fi;
      fi;
    fi;
  od; od;
  WriteAll(out, Concatenation("TOMDONE\t", nm, "\t", String(cnt), "\n"));
od;
CloseStream(out);
QUIT;
