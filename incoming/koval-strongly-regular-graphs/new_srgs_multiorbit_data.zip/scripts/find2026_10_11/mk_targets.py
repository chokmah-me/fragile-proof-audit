"""Open targets with integer eigenvalues as GAP list [v,k,r,s,l,m] (k <= (v-1)/2 orientation)."""
import math
out = []
for line in open('/work/out/find2026_10_11/open_sets.tsv'):
    v, k, l, m = map(int, line.split())
    kc = v - k - 1
    if kc < k: k, l, m = kc, v - 2 - 2 * k + m, v - 2 * k + l
    D = (l - m) ** 2 + 4 * (k - m)
    q = math.isqrt(D)
    if q * q != D or (l - m + q) % 2: continue
    r, s = (l - m + q) // 2, (l - m - q) // 2
    out.append((v, k, r, s, l, m))
out = sorted(set(out))
open('/work/out/find2026_10_11/open_targets.g', 'w').write(
    'OPENT := [' + ','.join('[%d,%d,%d,%d,%d,%d]' % t for t in out) + '];\n')
print(len(out), 'integral open targets')
