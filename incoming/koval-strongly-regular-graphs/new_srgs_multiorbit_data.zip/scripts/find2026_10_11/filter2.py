"""Stage-1 rows -> pairs that pass the degree conditions of a 2-part equitable partition:
cross subdegree d12=(k-theta)idx_j/v as a sub-multiset sum of cross suborbit lengths, and k-d12 / k-d21 as
sub-multiset sums of the nontrivial suborbit lengths in each orbit.  Output: tom i j v idx_i idx_j rank targets."""
import sys, ast, glob
def sums(items, cap):        # items: list of (len, mult) ; bounded subset sums <= cap
    S = 1
    mask = (1 << (cap + 1)) - 1
    for ln, mu in items:
        for _ in range(mu):
            if ln > cap: break
            S = (S | (S << ln)) & mask
    return S
outl = []; tot = 0
for fn in sys.argv[1:]:
    for line in open(fn):
        a = line.rstrip('\n').split('\t')
        if a[0] == 'TOMDONE': continue
        tot += 1
        nm, n, i, j, ii, ij = a[0], int(a[1]), int(a[2]), int(a[3]), int(a[4]), int(a[5])
        v = ii + ij
        ar = ast.literal_eval(a[6]); D1 = ast.literal_eval(a[7]); D2 = ast.literal_eval(a[8]); X = ast.literal_eval(a[9])
        d1 = [(x[0], x[2]) for x in D1]; d2 = [(x[0], x[2]) for x in D2]
        # remove the diagonal (one suborbit of length 1)
        for d in (d1, d2):
            p = [t for t, (ln, mu) in enumerate(d) if ln == 1][0]
            d[p] = (1, d[p][1] - 1)
        cx = [(x[0], x[2]) for x in X]
        rank = sum(m for _, m in d1) + sum(m for _, m in d2) + sum(m for _, m in cx)
        good = []
        for k, th in ar:
            d12 = (k - th) * ij // v; d21 = (k - th) * ii // v
            if not (sums(cx, d12) >> d12) & 1: continue
            if not (sums(d1, k - d12) >> (k - d12)) & 1: continue
            if not (sums(d2, k - d21) >> (k - d21)) & 1: continue
            good.append(f"{k}/{th}")
        if good: outl.append((rank, nm, i, j, v, ii, ij, ','.join(good)))
outl.sort()
for r in outl: print('\t'.join(map(str, (r[1], r[2], r[3], r[4], r[5], r[6], r[0], r[7]))))
print(f"# rows {tot} pass {len(outl)}", file=sys.stderr)
