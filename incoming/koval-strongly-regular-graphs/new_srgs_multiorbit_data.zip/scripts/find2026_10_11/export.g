# Export two-orbit actions G on G/H_i ⊔ G/H_j for the jobs in F2_JOBS (list of [tomname, i, j]) to F2_DIR.
# File format (one job per file, name <tom>__<i>_<j>.txt):
#   line1: v idx1 ngens ; then ngens lines of images (1-based) ; then line: suborbit labels of x1=1 (v ints, 0-based ids)
#   then line: suborbit labels of x2=idx1+1.
LoadPackage("tomlib");
Read(F2_JOBFILE);   # defines F2_JOBS, F2_DIR
WriteJob := function(nm, i, j, G, tom)
  local H1, H2, a1, a2, i1, gens, imgs, P, v, f, f2, lab, orbs, k, x, fn;
  H1 := RepresentativeTom(tom, i); H2 := RepresentativeTom(tom, j);
  a1 := FactorCosetAction(G, H1); a2 := FactorCosetAction(G, H2);
  i1 := Index(G, H1); v := i1 + Index(G, H2);
  gens := GeneratorsOfGroup(G);
  imgs := List(gens, g -> Concatenation(ListPerm(Image(a1, g), i1), List(ListPerm(Image(a2, g), Index(G,H2)), y -> y + i1)));
  imgs := List(imgs, l -> Concatenation(l, [Length(l)+1..v]));
  P := Group(List(imgs, PermList));
  fn := Concatenation(F2_DIR, "/", ReplacedString(ReplacedString(nm, "/", "_"), " ", "_"), "__", String(i), "_", String(j), ".txt");
  f := OutputTextFile(fn, false); SetPrintFormattingStatus(f, false);
  WriteAll(f, Concatenation(String(v), " ", String(i1), " ", String(Length(imgs)), "\n"));
  for k in imgs do WriteAll(f, JoinStringsWithSeparator(List(k, String), " ")); WriteAll(f, "\n"); od;
  for x in [1, i1+1] do
    orbs := OrbitsDomain(Stabilizer(P, x), [1..v]);
    lab := List([1..v], y -> 0);
    for k in [1..Length(orbs)] do for f2 in orbs[k] do lab[f2] := k-1; od; od;
    WriteAll(f, JoinStringsWithSeparator(List(lab, String), " ")); WriteAll(f, "\n");
  od;
  CloseStream(f);
end;
cur := ""; G := fail; tom := fail;
for job in F2_JOBS do
  if job[1] <> cur then cur := job[1]; tom := TableOfMarks(cur); G := UnderlyingGroup(tom); fi;
  WriteJob(job[1], job[2], job[3], G, tom);
  Print("EXPORTED ", job, "\n");
od;
QUIT;
