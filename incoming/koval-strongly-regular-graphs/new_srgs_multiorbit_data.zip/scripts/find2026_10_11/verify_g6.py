"""Independent exact check of graph6 files: own decoder, integer A^2 = k I + l A + m (J - I - A).
Usage: verify_g6.py FILE.g6 ...   prints v k l m SRG_OK / FAIL per graph."""
import sys
def decode(s):
    s = s.strip(); b = [ord(c) - 63 for c in s]
    if b[0] < 63: n, p = b[0], 1
    else: n, p = (b[1] << 12) | (b[2] << 6) | b[3], 4
    bits = []
    for x in b[p:]: bits += [(x >> (5 - t)) & 1 for t in range(6)]
    adj = [set() for _ in range(n)]; q = 0
    for j in range(1, n):
        for i in range(j):
            if bits[q]: adj[i].add(j); adj[j].add(i)
            q += 1
    return n, adj
for fn in sys.argv[1:]:
    for line in open(fn):
        if not line.strip(): continue
        n, adj = decode(line)
        degs = {len(a) for a in adj}
        if len(degs) != 1: print(fn, n, 'FAIL irregular'); continue
        k = degs.pop(); L = set(); M = set()
        for x in range(n):
            for y in range(x + 1, n):
                c = len(adj[x] & adj[y])
                (L if y in adj[x] else M).add(c)
        ok = len(L) <= 1 and len(M) == 1 and 0 < k < n - 1
        print(fn, n, k, sorted(L), sorted(M), 'SRG_OK' if ok else 'FAIL')
