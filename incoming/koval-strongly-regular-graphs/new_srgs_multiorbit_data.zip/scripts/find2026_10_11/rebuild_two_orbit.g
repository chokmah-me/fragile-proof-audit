# Generic independent rebuild of a two-orbit fusion hit (no TomLib class representatives, no Python):
# needs RB_G (group), RB_I1, RB_I2 (indices), RB_K, RB_L, RB_M, RB_THETAS (eigenvalues r,s), RB_OUT (dir).
# Subgroup classes recomputed by ConjugacyClassesSubgroups; all orbitals by OrbitsDomain on pairs; exhaustive DFS.
v := RB_I1 + RB_I2;;
if IsBound(RB_H1S) then cl := Concatenation(RB_H1S, RB_H2S); else cl := List(ConjugacyClassesSubgroups(RB_G), Representative); fi;
H1s := Filtered(cl, h -> Index(RB_G, h) = RB_I1);; H2s := Filtered(cl, h -> Index(RB_G, h) = RB_I2);;
if IsBound(RB_H1FILTER) then H1s := Filtered(H1s, RB_H1FILTER); fi;
out := OutputTextFile(Concatenation(RB_OUT, "/rebuild.log"), false); SetPrintFormattingStatus(out, false);
WriteAll(out, Concatenation("classes index ", String(RB_I1), ": ", String(Length(H1s)), "  index ", String(RB_I2), ": ", String(Length(H2s)), "\n"));
nfound := 0;;
D12 := List(RB_THETAS, t -> (RB_K - t) * RB_I2 / v);;
for a in [1..Length(H1s)] do for b in [1..Length(H2s)] do
  if RB_I1 <> RB_I2 or a <= b then
  H1 := H1s[a]; H2 := H2s[b];
  act1 := Action(RB_G, RightCosets(RB_G, H1), OnRight);; act2 := Action(RB_G, RightCosets(RB_G, H2), OnRight);;
  hom1 := ActionHomomorphism(RB_G, RightCosets(RB_G, H1), OnRight);; hom2 := ActionHomomorphism(RB_G, RightCosets(RB_G, H2), OnRight);;
  gens := GeneratorsOfGroup(RB_G);;
  big := Group(List(gens, g -> PermList(Concatenation(ListPerm(Image(hom1, g), RB_I1), List(ListPerm(Image(hom2, g), RB_I2), y -> y + RB_I1)))));;
  if NrMovedPoints(big) < v and Size(big) > 1 then Print(""); fi;
  orb := OrbitsDomain(big, Cartesian([1..v], [1..v]), OnTuples);;
  lab := List([1..v], i -> List([1..v], j -> 0));;
  for t in [1..Length(orb)] do for p in orb[t] do lab[p[1]][p[2]] := t; od; od;
  cls := []; seen := [];
  for t in [1..Length(orb)] do
    p := orb[t][1];
    if p[1] <> p[2] and not t in seen then
      tt := lab[p[2]][p[1]]; Add(cls, Set([t, tt])); AddSet(seen, t); AddSet(seen, tt);
    fi;
  od;
  x1 := 1; x2 := RB_I1 + 1;
  w1 := List(cls, c -> Number([1..RB_I1], y -> lab[x1][y] in c));
  c1 := List(cls, c -> Number([RB_I1+1..v], y -> lab[x1][y] in c));
  w2 := List(cls, c -> Number([RB_I1+1..v], y -> lab[x2][y] in c));
  c2 := List(cls, c -> Number([1..RB_I1], y -> lab[x2][y] in c));
  L := Length(cls);
  r1 := List([1..L+1], i -> Sum(w1{[i..L]}) + Sum(c1{[i..L]}));
  r2 := List([1..L+1], i -> Sum(w2{[i..L]}) + Sum(c2{[i..L]}));
  rc := List([1..L+1], i -> Sum(c1{[i..L]}));
  tested := 0;
  dfs := function(i, chosen, a1, b1, a2, b2)
    local ok, x, y, nb, NB, cnt, edges, fn;
    if a1 + b1 > RB_K or a2 + b2 > RB_K then return; fi;
    if a1 + b1 + r1[i] < RB_K or a2 + b2 + r2[i] < RB_K then return; fi;
    if b1 > Maximum(D12) or b1 + rc[i] < Minimum(D12) then return; fi;
    if i > L then
      if b1 in D12 then
        tested := tested + 1;
        edges := Union(List(chosen, j -> cls[j]));
        nb := [];
        NB := function(x) if not IsBound(nb[x]) then nb[x] := Filtered([1..v], y -> lab[x][y] in edges); fi; return nb[x]; end;
        ok := Length(NB(x1)) = RB_K and Length(NB(x2)) = RB_K;
        if ok then
          for x in [x1, x2] do
            for y in [1..v] do
              if y <> x then
                cnt := Length(Intersection(NB(x), NB(y)));
                if (y in NB(x) and cnt <> RB_L) or (not y in NB(x) and cnt <> RB_M) then ok := false; break; fi;
              fi;
            od;
            if not ok then break; fi;
          od;
        fi;
        if ok then
          nb := List([1..v], NB);
          ok := ForAll(nb, l -> Length(l) = RB_K);
        fi;
        if ok then
          for x in [x1, x2] do
            for y in [1..v] do
              if y <> x then
                cnt := Length(Intersection(nb[x], nb[y]));
                if (y in nb[x] and cnt <> RB_L) or (not y in nb[x] and cnt <> RB_M) then ok := false; break; fi;
              fi;
            od;
            if not ok then break; fi;
          od;
        fi;
        if ok then
          nfound := nfound + 1;
          WriteAll(out, Concatenation("FOUND H1class=", String(a), " H2class=", String(b), " |H1|=", String(Size(H1)), " |H2|=", String(Size(H2)), " classes=", String(chosen), "\n"));
          fn := Concatenation(RB_OUT, "/r", String(nfound), ".adj");
          PrintTo(fn, "graph\n", v, "\n");
          for x in [1..v] do AppendTo(fn, JoinStringsWithSeparator(List(nb[x], String), " "), "\n"); od;
        fi;
      fi;
      return;
    fi;
    dfs(i+1, Concatenation(chosen, [i]), a1 + w1[i], b1 + c1[i], a2 + w2[i], b2 + c2[i]);
    dfs(i+1, chosen, a1, b1, a2, b2);
  end;
  dfs(1, [], 0, 0, 0, 0);
  WriteAll(out, Concatenation("pair ", String([a, b]), " faithful ", String(Size(big) = Size(RB_G)), " orbitals ", String(Length(orb)), " symclasses ", String(L),
     " degree-candidates ", String(tested), " found(total) ", String(nfound), "\n"));
  fi;
od; od;
WriteAll(out, "DONE\n"); CloseStream(out);
