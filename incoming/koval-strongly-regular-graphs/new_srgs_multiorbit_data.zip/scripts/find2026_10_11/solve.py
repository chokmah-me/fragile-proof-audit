"""Two-orbit coherent-configuration fusion: decide whether a union of symmetrised orbitals of G on
Omega1 ⊔ Omega2 is an srg(v,k,l,m) for each target with this v.  Exact model (intersection numbers of the
configuration), CP-SAT, one worker.  Usage: solve.py JOBFILE TARGETS.tsv TIMELIMIT HITDIR [tag]"""
import sys, os, numpy as np
from ortools.sat.python import cp_model

def load(fn):
    with open(fn) as f:
        v, i1, ng = map(int, f.readline().split())
        gens = [np.array(f.readline().split(), dtype=np.int32) - 1 for _ in range(ng)]
        r1 = np.array(f.readline().split(), dtype=np.int32)
        r2 = np.array(f.readline().split(), dtype=np.int32)
    return v, i1, gens, r1, r2

def full_labels(v, i1, gens, r1, r2):
    R1 = int(r1.max()) + 1
    rows = {0: r1, i1: r2 + R1}
    L = np.full((v, v), -1, dtype=np.int32)
    for x in (0, i1):
        row = rows[x]
        L[x] = row
        g = {x: np.arange(v, dtype=np.int32)}
        stack = [x]
        while stack:
            y = stack.pop()
            for s in gens:
                z = int(s[y])
                if z not in g:
                    gz = s[g[y]]           # point p -> (p^g_y)^s
                    g[z] = gz
                    inv = np.empty(v, dtype=np.int32); inv[gz] = np.arange(v, dtype=np.int32)
                    L[z] = row[inv]
                    stack.append(z)
    assert (L >= 0).all(), "two orbits expected"
    return L, R1 + int(r2.max()) + 1

def graph6(A):
    n = A.shape[0]
    bits = [int(A[i, j]) for j in range(1, n) for i in range(j)]
    bits += [0] * ((6 - len(bits) % 6) % 6)
    if n < 63: hdr = [n + 63]
    elif n < 258048: hdr = [126, 63 + (n >> 12 & 63), 63 + (n >> 6 & 63), 63 + (n & 63)]
    out = bytes(hdr + [63 + int(''.join(map(str, bits[i:i+6])), 2) for i in range(0, len(bits), 6)])
    return out.decode()

def main():
    first, tf, tl, hitdir = sys.argv[1], sys.argv[2], float(sys.argv[3]), sys.argv[4]
    files = [l.strip() for l in open(first[1:]) if l.strip()] if first.startswith('@') else [first]
    tlines = open(tf).read().splitlines()
    for jf in files:
        try:
            solve_one(jf, tlines, tl, hitdir)
        except Exception as e:
            print(os.path.basename(jf) + "\tERROR\t" + repr(e))
        sys.stdout.flush()

def solve_one(jf, tlines, tl, hitdir):
    v, i1, gens, r1, r2 = load(jf)
    targets = []
    for line in tlines:
        a = line.split()
        if not a: continue
        vv, k, l, m = map(int, a[:4])
        if vv != v: continue
        kc, lc, mc = v - k - 1, v - 2 - 2 * k + m, v - 2 * k + l
        targets.append((k, l, m) if k <= kc else (kc, lc, mc))
    targets = sorted(set(targets))
    name = os.path.basename(jf)
    if not targets: print(f"{name}\tNOTARGET"); return
    L, R = full_labels(v, i1, gens, r1, r2)
    T = L.T
    # transpose map and symmetric classes
    trans = np.full(R, -1)
    rep = {}
    for x in (0, i1):
        for w in range(v):
            a = int(L[x, w])
            if a not in rep: rep[a] = (x, w)
    assert len(rep) == R
    for a, (x, w) in rep.items(): trans[a] = L[w, x]
    diag = {int(L[0, 0]), int(L[i1, i1])}
    cls = -np.ones(R, dtype=np.int64); nc = 0
    for a in range(R):
        if a in diag or cls[a] >= 0: continue
        cls[a] = nc; cls[trans[a]] = nc; nc += 1
    s1 = np.bincount(cls[L[0]][cls[L[0]] >= 0], minlength=nc)
    s2 = np.bincount(cls[L[i1]][cls[L[i1]] >= 0], minlength=nc)
    # intersection data: for one representative label per class (and the diagonals implicitly via degree)
    creps = {}
    for a in range(R):
        if cls[a] >= 0 and cls[a] not in creps: creps[int(cls[a])] = rep[a]
    quad = {}
    for c, (x, z) in creps.items():
        ca = cls[L[x]]; cb = cls[L[:, z]]
        ok = (ca >= 0) & (cb >= 0)
        lo = np.minimum(ca[ok], cb[ok]); hi = np.maximum(ca[ok], cb[ok])
        key, cnt = np.unique(lo * nc + hi, return_counts=True)
        quad[c] = [(int(kk // nc), int(kk % nc), int(n)) for kk, n in zip(key, cnt)]
    for (k, l, m) in targets:
        # 2-D subset-sum prefilter on the two degrees
        S = np.zeros((k + 1, k + 1), dtype=bool); S[0, 0] = True
        for c in range(nc):
            a, b = int(s1[c]), int(s2[c])
            if a <= k and b <= k:
                S2 = S.copy(); S2[a:, b:] |= S[:k + 1 - a, :k + 1 - b]; S = S2
        if not S[k, k]:
            print(f"{name}\tv={v}\t{k},{l},{m}\tnc={nc}\tDEGREE-INFEASIBLE"); sys.stdout.flush(); continue
        md = cp_model.CpModel()
        C = [md.NewBoolVar(f"c{c}") for c in range(nc)]
        md.Add(sum(int(s1[c]) * C[c] for c in range(nc)) == k)
        md.Add(sum(int(s2[c]) * C[c] for c in range(nc)) == k)
        Y = {}
        def prod(a, b):
            if a == b: return C[a]
            if (a, b) not in Y:
                y = md.NewBoolVar(""); Y[(a, b)] = y
                md.AddImplication(y, C[a]); md.AddImplication(y, C[b])
                md.AddBoolOr([y, C[a].Not(), C[b].Not()])
            return Y[(a, b)]
        for c, terms in quad.items():
            md.Add(sum(n * prod(a, b) for a, b, n in terms) == m + (l - m) * C[c])
        sv = cp_model.CpSolver(); sv.parameters.num_workers = 1; sv.parameters.max_time_in_seconds = tl
        st = sv.Solve(md)
        stn = sv.StatusName(st)
        line = f"{name}\tv={v}\t{k},{l},{m}\tnc={nc}\t{stn}\t{sv.WallTime():.1f}s"
        if st in (cp_model.FEASIBLE, cp_model.OPTIMAL):
            sol = np.array([sv.Value(C[c]) for c in range(nc)] + [0], dtype=np.int64)
            A = sol[np.where(cls[L] >= 0, cls[L], nc)].astype(np.int64)
            assert (A == A.T).all() and (np.diag(A) == 0).all()
            A2 = A @ A
            J = np.ones((v, v), dtype=np.int64); I = np.eye(v, dtype=np.int64)
            good = (A2 == k * I + l * A + m * (J - I - A)).all()
            g6 = graph6(A)
            os.makedirs(hitdir, exist_ok=True)
            safe = ''.join(ch if ch.isalnum() or ch in '._-' else '_' for ch in name[:-4])
            with open(os.path.join(hitdir, f"{safe}__{v}_{k}_{l}_{m}.g6"), "w") as fh: fh.write(g6 + "\n")
            line += f"\tEXACT_SRG={'YES' if good else 'NO'}\tclasses={''.join(map(str, sol[:-1]))}"
        print(line); sys.stdout.flush()

if __name__ == "__main__":
    main()
