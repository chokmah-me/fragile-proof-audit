"""graph6 -> .adj (format of scripts/coset_fusion/verify_hit_full.py). Usage: g6_to_adj.py in.g6 out.adj"""
import sys
sys.path.insert(0, '/work/scripts/find2026_10_11')
from importlib import util
spec = util.spec_from_file_location('vg', '/work/scripts/find2026_10_11/verify_g6.py')
src = open('/work/scripts/find2026_10_11/verify_g6.py').read().split('for fn in sys.argv')[0]
ns = {}; exec(src, ns)
n, adj = ns['decode'](open(sys.argv[1]).readline())
with open(sys.argv[2], 'w') as f:
    f.write('graph\n%d\n' % n)
    for x in range(n): f.write(' '.join(str(y + 1) for y in sorted(adj[x])) + '\n')
