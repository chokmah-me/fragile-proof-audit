"""Parse Brouwer srgtab pages (out/brouwer_check_1011, fetched 2026-10-10) -> open/known lists, v<=1300.
Output TSV: status v k l m (the representative row as printed; complement implied)."""
import re, glob, html, sys
src = sys.argv[1] if len(sys.argv) > 1 else '/work/out/brouwer_check_1011'
out = sys.argv[2] if len(sys.argv) > 2 else '/work/out/find2026_10_11'
rows = []
for f in glob.glob(src + '/t*-*.html'):
    s = open(f, encoding='utf-8', errors='replace').read()
    for col, tr in re.findall(r'<tr bgcolor="(#[0-9a-f]+)">(.*?)</tr>', s, re.S):
        cells = [html.unescape(re.sub(r'<[^>]*>', '', c)).strip() for c in re.findall(r'<td>(.*?)</td>', tr, re.S)]
        if len(cells) < 5: continue
        try: v, k, l, m = map(int, cells[1:5])
        except ValueError: continue
        assert k*(k-l-1) == (v-k-1)*m, (v, k, l, m)
        rows.append((cells[0].replace('\xa0', ''), col, v, k, l, m))
op = sorted({r[2:] for r in rows if r[1] == '#ffffb0' and '?' in r[0]})
kn = sorted({r[2:] for r in rows if r[1] == '#b0ffb0'})
with open(out + '/open_sets.tsv', 'w') as fh:
    for v, k, l, m in op: fh.write(f"{v}\t{k}\t{l}\t{m}\n")
with open(out + '/known_sets.tsv', 'w') as fh:
    for v, k, l, m in kn: fh.write(f"{v}\t{k}\t{l}\t{m}\n")
print('open', len(op), 'distinct v', len({r[0] for r in op}), 'known', len(kn))
