# Independent from-scratch rebuild (no TomLib, no Python): G = M12 x C2 acting on two copies of G/H, H = L2(11) < M12.
# Enumerate ALL symmetric unions of orbitals of G on Omega x Omega that are srg(576,253,112,110); write each to .adj.
# Equitable-partition prune: cross degree d12 in {(253-13)/2, (253+11)/2} = {120, 132}.
M := MathieuGroup(12);;
C := Group((13,14));;
G := ClosureGroup(M, C);;                       # M12 x C2 on 14 points
Hs := Filtered(List(ConjugacyClassesSubgroups(M), Representative), h -> Size(h) = 660);;
Print("L2(11) classes in M12: ", Length(Hs), "\n");
out := OutputTextFile("/work/out/find2026_10_11/rebuild576/rebuild.log", false); SetPrintFormattingStatus(out, false);
nfound := 0;;
for hi in [1..Length(Hs)] do
  H := Hs[hi];
  cos := RightCosets(G, H);;                     # 288 cosets
  act := Action(G, cos, OnRight);;
  gens := GeneratorsOfGroup(act);;
  # disjoint union of two copies: points 1..288 and 289..576
  big := Group(List(gens, g -> PermList(Concatenation(ListPerm(g, 288), List(ListPerm(g, 288), y -> y + 288)))));;
  n := 576;
  orb := OrbitsDomain(big, Cartesian([1..n], [1..n]), OnTuples);;
  Print("H class ", hi, ": orbitals ", Length(orb), "\n");
  lab := List([1..n], i -> List([1..n], j -> 0));;
  for t in [1..Length(orb)] do for p in orb[t] do lab[p[1]][p[2]] := t; od; od;
  # symmetric classes (orbital + its transpose), skipping the diagonal
  cls := []; seen := [];
  for t in [1..Length(orb)] do
    p := orb[t][1];
    if p[1] <> p[2] and not t in seen then
      tt := lab[p[2]][p[1]]; Add(cls, Set([t, tt])); AddSet(seen, t); AddSet(seen, tt);
    fi;
  od;
  Print("symmetric classes ", Length(cls), "\n");
  # degree contributions from x1 = 1 (copy 1) and x2 = 289 (copy 2), split into within / cross
  w1 := List(cls, c -> Number([1..288], y -> lab[1][y] in c));
  c1 := List(cls, c -> Number([289..576], y -> lab[1][y] in c));
  w2 := List(cls, c -> Number([289..576], y -> lab[289][y] in c));
  c2 := List(cls, c -> Number([1..288], y -> lab[289][y] in c));
  cand := 0; tested := 0;
  L := Length(cls);
  r1 := List([1..L+1], i -> Sum(w1{[i..L]}) + Sum(c1{[i..L]}));
  r2 := List([1..L+1], i -> Sum(w2{[i..L]}) + Sum(c2{[i..L]}));
  rc := List([1..L+1], i -> Sum(c1{[i..L]}));
  dfs := function(i, chosen, a1, b1, a2, b2)
    local A, ok, x, y, nb, z, cnt, row, edges, k;
    if a1 + b1 > 253 or a2 + b2 > 253 or b1 > 132 or b2 > 132 then return; fi;
    if a1 + b1 + r1[i] < 253 or a2 + b2 + r2[i] < 253 or b1 + rc[i] < 120 then return; fi;
    if i > Length(cls) then
      if a1 + b1 = 253 and a2 + b2 = 253 and b1 in [120, 132] then
        tested := tested + 1;
        edges := Union(List(chosen, j -> cls[j]));
        nb := List([1..n], x -> Filtered([1..n], y -> lab[x][y] in edges));
        ok := ForAll(nb, l -> Length(l) = 253);
        if ok then
          for x in [1, 289] do
            for y in [1..n] do
              if y <> x then
                cnt := Length(Intersection(nb[x], nb[y]));
                if (y in nb[x] and cnt <> 112) or (not y in nb[x] and cnt <> 110) then ok := false; break; fi;
              fi;
            od;
            if not ok then break; fi;
          od;
        fi;
        if ok then
          nfound := nfound + 1;
          WriteAll(out, Concatenation("FOUND H=", String(hi), " classes=", String(chosen), "\n"));
          PrintTo(Concatenation("/work/out/find2026_10_11/rebuild576/r", String(nfound), ".adj"), "graph\n", n, "\n");
          for x in [1..n] do AppendTo(Concatenation("/work/out/find2026_10_11/rebuild576/r", String(nfound), ".adj"),
             JoinStringsWithSeparator(List(nb[x], String), " "), "\n"); od;
        fi;
      fi;
      return;
    fi;
    dfs(i+1, Concatenation(chosen, [i]), a1 + w1[i], b1 + c1[i], a2 + w2[i], b2 + c2[i]);
    dfs(i+1, chosen, a1, b1, a2, b2);
  end;
  dfs(1, [], 0, 0, 0, 0);
  WriteAll(out, Concatenation("H class ", String(hi), " orbitals ", String(Length(orb)), " symclasses ", String(Length(cls)),
     " degree-candidates ", String(tested), " found(total) ", String(nfound), "\n"));
od;
WriteAll(out, "DONE\n"); CloseStream(out);
QUIT;
