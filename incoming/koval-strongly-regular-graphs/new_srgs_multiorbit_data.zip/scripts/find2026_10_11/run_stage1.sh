#!/bin/sh
# usage: run_stage1.sh LO HI PART
cd /work
cat > /tmp/s1_$3.g <<G
F1_OUT := "/work/out/find2026_10_11/stage1_$3.tsv"; F1_RANGE := [$1..$2];
Read("/work/scripts/find2026_10_11/stage1.g");
G
gap -q -o 12g /tmp/s1_$3.g > /work/out/find2026_10_11/stage1_$3.log 2>&1
