"""Clique number of the common-neighbourhood graph of edges (Delsarte-clique / Latin-square test).
Usage: clique_probe.py FILE.g6 NEDGES"""
import sys, itertools
src = open('/work/scripts/find2026_10_11/verify_g6.py').read().split('for fn in sys.argv')[0]
ns = {}; exec(src, ns)
n, adj = ns['decode'](open(sys.argv[1]).readline())
def maxclique(V):
    V = list(V); best = []
    def expand(R, P):
        nonlocal best
        if len(R) + len(P) <= len(best): return
        if not P:
            best = R[:]; return
        P = list(P)
        while P:
            if len(R) + len(P) <= len(best): return
            v = P.pop()
            expand(R + [v], [u for u in P if u in adj[v]])
    expand([], sorted(V, key=lambda u: len(adj[u] & set(V))))
    return best
x = 0
for y in sorted(adj[0])[:int(sys.argv[2])]:
    C = adj[x] & adj[y]
    print('edge', x, y, 'common', len(C), 'max clique in common nbhd', len(maxclique(C)), flush=True)
