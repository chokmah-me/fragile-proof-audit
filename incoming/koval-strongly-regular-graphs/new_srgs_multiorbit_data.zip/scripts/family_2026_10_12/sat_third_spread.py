"""Task 3 (search beyond fixed L): does some symmetric constant-diagonal Latin square L make the
Kharaghani matrix K(H, L) carry a THIRD spread of transversal N-cliques (orthogonal to rows and
columns)?  If yes, deleting rows+cols+it gives LS_{N/2-2}(N).

H fixed (normalized, column 0 = all ones, placed on the diagonal of L).  SAT variables:
  Lv[a,c,i]  (a<c, i=1..N-1): L(a,c) = i ; each edge one colour, each colour class a perfect matching
  X[a,b,k]   : cell (a,b) lies in transversal k (Latin square: cell/row-symbol/col-symbol exactly one)
  Y[k,a,i]   : H[pi_k(a), i] = +1   (X[a,b,k] -> Y[k,a,i] or its negation)
  clique     : Lv[a,c,i] -> (Y[k,a,i] <-> Y[k,c,i])  for every k
Symmetry breaking (WLOG over row permutations of H, which give isomorphic graphs): pi_0 = identity.
Cardinality: pairwise AMO (sizes <= 36) + ALO.
usage: sat_third_spread.py N Hname out.cnf
"""
import sys, os, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *

N = int(sys.argv[1]); hname = sys.argv[2]; out = sys.argv[3]
H = dict(hadamards(N))[hname] if hname in dict(hadamards(N)) else None
assert H is not None, [h for h, _ in hadamards(N)]
H = normalize(H)
nv = 0
def new():
    global nv; nv += 1; return nv
Lv = {}
for a in range(N):
    for c in range(a + 1, N):
        for i in range(1, N): Lv[a, c, i] = Lv[c, a, i] = new()
X = {(a, b, k): new() for a in range(N) for b in range(N) for k in range(N)}
Y = {(k, a, i): new() for k in range(N) for a in range(N) for i in range(1, N)}
cl = []
def exactly_one(vs):
    cl.append(list(vs))
    for x, y in itertools.combinations(vs, 2): cl.append([-x, -y])
for a in range(N):
    for c in range(a + 1, N): exactly_one([Lv[a, c, i] for i in range(1, N)])
for a in range(N):
    for i in range(1, N): exactly_one([Lv[a, c, i] for c in range(N) if c != a])
for a in range(N):
    for b in range(N): exactly_one([X[a, b, k] for k in range(N)])
for a in range(N):
    for k in range(N): exactly_one([X[a, b, k] for b in range(N)])
for b in range(N):
    for k in range(N): exactly_one([X[a, b, k] for a in range(N)])
for a in range(N):
    for b in range(N):
        for k in range(N):
            for i in range(1, N):
                cl.append([-X[a, b, k], Y[k, a, i] if H[b, i] == 1 else -Y[k, a, i]])
for a in range(N):
    for c in range(a + 1, N):
        for i in range(1, N):
            for k in range(N):
                cl.append([-Lv[a, c, i], -Y[k, a, i], Y[k, c, i]])
                cl.append([-Lv[a, c, i], Y[k, a, i], -Y[k, c, i]])
for a in range(N): cl.append([X[a, a, 0]])          # pi_0 = id
for b in range(N): cl.append([X[0, b, b]])          # transversal k contains (0,k): labels the k
with open(out, 'w') as f:
    f.write('p cnf %d %d\n' % (nv, len(cl)))
    for c in cl: f.write(' '.join(map(str, c)) + ' 0\n')
print('N=%d H=%s vars=%d clauses=%d' % (N, hname, nv, len(cl)))
# decoder info
import json
json.dump({'N': N, 'H': hname, 'Lv': {'%d,%d,%d' % k: v for k, v in Lv.items() if k[0] < k[1]},
           'X': {'%d,%d,%d' % k: v for k, v in X.items()}}, open(out + '.map.json', 'w'))
