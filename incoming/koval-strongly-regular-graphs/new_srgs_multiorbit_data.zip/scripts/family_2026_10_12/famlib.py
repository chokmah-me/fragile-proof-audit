"""Own library for the family question (2026-10-12).  Written from scratch; does not import
scripts/new_srgs_multiorbit or out/referee_multiorbit_fable.

Hadamard matrices, Kharaghani 1985 Bush-type matrices, the graphs
  G0   = (J+K)/2 - I                      (LS_{N/2+1}(N) parameters, Goethals-Seidel type)
  BHK  = G0 - row spread                  (Bonato-Holzmann-Kharaghani 2001 Lemma 3 twin, LS_{N/2}(N))
  G2   = G0 - row spread - column spread  (LS_{N/2-1}(N), the two-spread deletion)
exact integer srg check, graph6 I/O, nauty canonical hashes.
"""
import hashlib, itertools, math, os, random, subprocess
import numpy as np

# ------------------------------------------------------------------ finite fields
class GF:
    """GF(p^e) with elements 0..q-1 (base-p digits = polynomial coefficients, low first)."""
    def __init__(self, q):
        p = next(d for d in range(2, q + 1) if q % d == 0)
        e = round(math.log(q, p)); assert p ** e == q
        self.p, self.e, self.q = p, e, q
        if e == 1:
            self.mod = None
        else:
            for low in itertools.product(range(p), repeat=e):
                f = list(low) + [1]
                if low[0] == 0: continue
                # irreducible <=> no root and (for e<=3) no factor of degree <= e/2; test by
                # checking that x has multiplicative structure of a field: brute-force zero divisors
                self.mod = f
                if self._is_field(): break
            else:
                raise ValueError
        self.mul_t = [[self._mul(a, b) for b in range(q)] for a in range(q)]
        self.add_t = [[self._add(a, b) for b in range(q)] for a in range(q)]
        self.neg = [next(b for b in range(q) if self.add_t[a][b] == 0) for a in range(q)]
        sq = {self.mul_t[a][a] for a in range(1, q)}
        self.chi = [0] + [1 if a in sq else -1 for a in range(1, q)]

    def digits(self, a):
        return [(a // self.p ** i) % self.p for i in range(self.e)]
    def undigits(self, d):
        return sum(c * self.p ** i for i, c in enumerate(d))
    def _add(self, a, b):
        return self.undigits([(x + y) % self.p for x, y in zip(self.digits(a), self.digits(b))])
    def _mul(self, a, b):
        if self.e == 1: return a * b % self.p
        x, y = self.digits(a), self.digits(b)
        prod = [0] * (2 * self.e - 1)
        for i, xi in enumerate(x):
            for j, yj in enumerate(y):
                prod[i + j] = (prod[i + j] + xi * yj) % self.p
        f = self.mod
        for k in range(2 * self.e - 2, self.e - 1, -1):
            c = prod[k]
            if c:
                for j in range(self.e + 1):
                    prod[k - self.e + j] = (prod[k - self.e + j] - c * f[j]) % self.p
        return self.undigits(prod[:self.e])
    def _is_field(self):
        q = self.q
        for a in range(1, q):
            for b in range(1, q):
                if self._mul(a, b) == 0: return False
        return True
    def sub(self, a, b):
        return self.add_t[a][self.neg[b]]

# ------------------------------------------------------------------ Hadamard matrices
H2 = np.array([[1, 1], [1, -1]], dtype=np.int64)

def is_hadamard(H):
    n = H.shape[0]
    return bool((np.abs(H) == 1).all() and (H @ H.T == n * np.eye(n, dtype=np.int64)).all())

def sylvester(m):
    H = np.ones((1, 1), dtype=np.int64)
    for _ in range(m): H = np.kron(H, H2)
    return H

def jacobsthal(q):
    F = GF(q)
    return np.array([[F.chi[F.sub(x, y)] for y in range(q)] for x in range(q)], dtype=np.int64)

def paley1(q):
    """order q+1, q = 3 mod 4: I + S, S skew conference matrix."""
    assert q % 4 == 3
    Q = jacobsthal(q); n = q + 1
    S = np.zeros((n, n), dtype=np.int64); S[0, 1:] = 1; S[1:, 0] = -1; S[1:, 1:] = Q
    H = S + np.eye(n, dtype=np.int64); assert is_hadamard(H); return H

def paley2(q):
    """order 2(q+1), q = 1 mod 4, symmetric."""
    assert q % 4 == 1
    Q = jacobsthal(q)
    C = np.zeros((q + 1, q + 1), dtype=np.int64); C[0, 1:] = 1; C[1:, 0] = 1; C[1:, 1:] = Q
    H = np.kron(C, H2) + np.kron(np.eye(q + 1, dtype=np.int64), np.array([[1, -1], [-1, -1]]))
    assert is_hadamard(H) and (H == H.T).all(); return H

def normalize(H):
    H = H * H[:, :1]
    return H * H[:1, :]

def hadamards(N):
    """A few inequivalent-looking Hadamard matrices of order N (name, H)."""
    out = []
    if N & (N - 1) == 0: out.append(('Syl%d' % N, sylvester(N.bit_length() - 1)))
    if (N - 1) % 4 == 3 and _pp(N - 1): out.append(('PalI(%d)' % (N - 1), paley1(N - 1)))
    if N % 2 == 0 and (N // 2 - 1) % 4 == 1 and _pp(N // 2 - 1): out.append(('PalII(%d)' % (N // 2 - 1), paley2(N // 2 - 1)))
    if N % 4 == 0 and (N // 2 - 1) % 4 == 3 and _pp(N // 2 - 1): out.append(('H2xPalI(%d)' % (N // 2 - 1), np.kron(H2, paley1(N // 2 - 1))))
    if N % 4 == 0 and (N // 4 - 1) % 4 == 1 and _pp(N // 4 - 1): out.append(('PalII(%d)xH2' % (N // 4 - 1), np.kron(paley2(N // 4 - 1), H2)))
    return out

def _pp(q):
    if q < 2: return False
    p = next(d for d in range(2, q + 1) if q % d == 0)
    while q % p == 0: q //= p
    return q == 1

# ------------------------------------------------------------------ Latin squares
def round_robin(N):
    """Symmetric Latin square on 0..N-1 with constant diagonal 0 (1-factorisation of K_N)."""
    m = N - 1
    L = np.zeros((N, N), dtype=np.int64)
    for i in range(m):
        for j in range(m):
            if i != j: L[i, j] = 1 + ((i + j) % m)
    for i in range(m):
        L[i, m] = L[m, i] = 1 + ((2 * i) % m)
    assert ok_sym_latin(L); return L

def xor_square(N):
    return np.array([[a ^ b for b in range(N)] for a in range(N)], dtype=np.int64)

def ok_sym_latin(L):
    N = L.shape[0]
    return bool((L == L.T).all() and (np.diag(L) == L[0, 0]).all() and
                all(len(set(L[i])) == N for i in range(N)))

def relabel_rr(N, rng):
    """random symmetric constant-diagonal Latin square: permute points and colours of round robin."""
    L = round_robin(N); P = list(range(N)); rng.shuffle(P)
    C = [0] + rng.sample(range(1, N), N - 1)
    L2 = np.zeros_like(L)
    for i in range(N):
        for j in range(N): L2[P[i], P[j]] = C[L[i, j]]
    assert ok_sym_latin(L2); return L2

# ------------------------------------------------------------------ Bush-type matrices
def kharaghani(H, L):
    """Kharaghani 1985: block (a,c) = c_i c_i^T, i = L(a,c), c_i = column i of normalized H,
    the all-ones column sitting on the diagonal of L.  Vertex (a,b) -> index a*N+b."""
    H = normalize(H); N = H.shape[0]
    d = L[0, 0]
    perm = [d] + [i for i in range(N) if i != d]       # column 0 of H (all ones) -> colour d
    cols = np.zeros_like(H); cols[:, perm] = H        # cols[:, d] = all-ones
    K = np.zeros((N * N, N * N), dtype=np.int64)
    for a in range(N):
        for c in range(N):
            x = cols[:, L[a, c]]
            K[a * N:(a + 1) * N, c * N:(c + 1) * N] = np.outer(x, x)
    return K

def sym_rule(H):
    """the paper's rule K_{(a,b),(c,d)} = H_ab H_bc H_cd H_da (H symmetric)."""
    N = H.shape[0]
    K = np.einsum('ab,bc,cd,da->abcd', H, H, H, H).reshape(N * N, N * N)
    return K

def check_K(K):
    N2 = K.shape[0]
    return bool((K == K.T).all() and (np.diag(K) == 1).all() and (K @ K == N2 * np.eye(N2, dtype=np.int64)).all())

def spread_rows(N):
    return np.kron(np.eye(N, dtype=np.int64), np.ones((N, N), dtype=np.int64)) - np.eye(N * N, dtype=np.int64)

def spread_cols(N):
    return np.kron(np.ones((N, N), dtype=np.int64), np.eye(N, dtype=np.int64)) - np.eye(N * N, dtype=np.int64)

def graphs_from_K(K):
    N2 = K.shape[0]; N = math.isqrt(N2)
    G0 = (np.ones((N2, N2), dtype=np.int64) + K) // 2 - np.eye(N2, dtype=np.int64)
    R, C = spread_rows(N), spread_cols(N)
    assert ((G0 - R) >= 0).all() and ((G0 - C) >= 0).all()
    return G0, G0 - R, G0 - R - C

# ------------------------------------------------------------------ exact srg check
def srg_params(A):
    """exact: returns (v,k,lam,mu) if A is the adjacency matrix of an srg, else None.
    A@A computed in float64 (entries < 2^53, exact), then compared as int64."""
    A = np.asarray(A, dtype=np.int64); v = A.shape[0]
    if not ((A == A.T).all() and (np.diag(A) == 0).all() and ((A == 0) | (A == 1)).all()): return None
    deg = A.sum(1)
    if not (deg == deg[0]).all(): return None
    k = int(deg[0])
    Af = A.astype(np.float64); A2 = np.rint(Af @ Af).astype(np.int64)
    if not (np.diag(A2) == k).all(): return None
    off = ~np.eye(v, dtype=bool)
    lv = np.unique(A2[(A == 1) & off]); mv = np.unique(A2[(A == 0) & off])
    if len(lv) > 1 or len(mv) > 1: return None
    lam = int(lv[0]) if len(lv) else 0; mu = int(mv[0]) if len(mv) else 0
    # final identity check A^2 = kI + lam A + mu (J - I - A)
    J = np.ones((v, v), dtype=np.int64); I = np.eye(v, dtype=np.int64)
    if not (A2 == k * I + lam * A + mu * (J - I - A)).all(): return None
    return (v, k, lam, mu)

def ls_params(N, t):
    return (N * N, t * (N - 1), N - 2 + (t - 1) * (t - 2), t * (t - 1))

# ------------------------------------------------------------------ graph6 + nauty
def to_g6(A):
    A = np.asarray(A); n = A.shape[0]
    if n < 63: out = [n + 63]
    elif n < 258048: out = [126, ((n >> 12) & 63) + 63, ((n >> 6) & 63) + 63, (n & 63) + 63]
    else: raise ValueError
    bits = [int(A[i, j]) for j in range(1, n) for i in range(j)]
    bits += [0] * ((-len(bits)) % 6)
    for i in range(0, len(bits), 6):
        x = 0
        for b in bits[i:i + 6]: x = (x << 1) | b
        out.append(x + 63)
    return bytes(out).decode()

def from_g6(s):
    s = s.strip().encode();
    if s[0] == 126:
        n = ((s[1] - 63) << 12) | ((s[2] - 63) << 6) | (s[3] - 63); p = 4
    else:
        n = s[0] - 63; p = 1
    bits = []
    for c in s[p:]:
        x = c - 63
        bits += [(x >> (5 - i)) & 1 for i in range(6)]
    A = np.zeros((n, n), dtype=np.int64); t = 0
    for j in range(1, n):
        for i in range(j):
            A[i, j] = A[j, i] = bits[t]; t += 1
    return A

def canon_hash(g6line, tmpdir='/tmp'):
    """sha256 (first 24 hex) of nauty-labelg canonical graph6, plus |Aut| from labelg -v? (we use dreadnaut separately)."""
    r = subprocess.run(['nauty-labelg', '-q'], input=g6line.strip() + '\n', capture_output=True, text=True, check=True)
    return hashlib.sha256(r.stdout.strip().encode()).hexdigest()[:24]

def aut_order(g6line):
    """|Aut| via nauty-countg? use dreadnaut on the graph6 input."""
    A = from_g6(g6line); n = A.shape[0]
    lines = ['n=%d g' % n]
    for i in range(n):
        nb = [str(j) for j in range(i + 1, n) if A[i, j]]
        lines.append(' '.join(nb) + (';' if i < n - 1 else '.'))
    lines.append('-a x')   # -a: do not print generators
    r = subprocess.run(['dreadnaut'], input='\n'.join(lines) + '\nq\n', capture_output=True, text=True, check=True)
    import re
    m = re.search(r'grpsize=([0-9.e+]+);\s*(\d+) orbit', r.stdout)
    return (m.group(1), int(m.group(2))) if m else (r.stdout[-300:], None)
