"""Task 2: rebuild Kharaghani 1985 G0, BHK 2001 one-spread deletion, and the two-spread deletion
for N = 12,16,20,24,28,36; verify exactly; nauty canonical hashes; compare with our graphs."""
import sys, os, time, glob, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *
OUT = '/work/out/family_2026_10_12/g6'; os.makedirs(OUT, exist_ok=True)
Ns = [int(x) for x in sys.argv[1:]] or [12, 16, 20, 24, 28, 36]
rng = random.Random(20261012)
for N in Ns:
    Hs = hadamards(N)
    Ls = [('rr', round_robin(N)), ('rr*', relabel_rr(N, rng))]
    if N & (N - 1) == 0: Ls.append(('xor', xor_square(N)))
    for hn, H in Hs:
        for ln, L in Ls:
            t0 = time.time()
            K = kharaghani(H, L); assert check_K(K)
            G0, B1, G2 = graphs_from_K(K)
            res = []
            for tag, A, t in (('G0', G0, N // 2 + 1), ('BHK', B1, N // 2), ('G2', G2, N // 2 - 1)):
                p = srg_params(A); ok = p == ls_params(N, t)
                g = to_g6(A); fn = '%s/khar_%s_%s_%s.g6' % (OUT, hn.replace('(', '').replace(')', ''), ln.replace('*', 'x'), tag)
                open(fn, 'w', newline='\n').write(g + '\n')
                res.append('%s %s %s %s' % (tag, p, 'OK' if ok else 'FAIL', canon_hash(g)))
            print('N=%d H=%s L=%s | %s | %.1fs' % (N, hn, ln, ' | '.join(res), time.time() - t0), flush=True)
    # the paper's symmetric rule on the symmetric H available here
    for hn, H in Hs:
        if (H == H.T).all():
            K = sym_rule(H); assert check_K(K)
            G0, B1, G2 = graphs_from_K(K)
            p = srg_params(G2); g = to_g6(G2)
            open('%s/sym_%s_G2.g6' % (OUT, hn.replace('(', '').replace(')', '')), 'w', newline='\n').write(g + '\n')
            # how many distinct +-(r_a o r_c) vectors (Kharaghani form needs exactly N)
            vecs = set()
            for a in range(N):
                for c in range(N):
                    x = H[a] * H[c]; x = x * x[0]; vecs.add(tuple(x))
            print('N=%d SYM %s G2 %s %s | distinct +-(r_a o r_c) = %d' % (N, hn, p, canon_hash(g), len(vecs)), flush=True)
