import sys, time
def decode(line):
    s=line.strip(); d=[ord(c)-63 for c in s]
    if d[0]==63: n=(d[1]<<12)|(d[2]<<6)|d[3]; p=4
    else: n=d[0]; p=1
    bits=[]
    for x in d[p:]:
        for i in range(5,-1,-1): bits.append((x>>i)&1)
    rows=[0]*n; k=0
    for j in range(1,n):
        for i in range(j):
            if bits[k]: rows[i]|=1<<j; rows[j]|=1<<i
            k+=1
    return n,rows
t0=time.time()
n,rows=decode(open(sys.argv[1]).readline()); r=int(round(n**0.5))
full=(1<<n)-1
comp=[full & ~rows[x] & ~(1<<x) for x in range(n)]
found=[]
popc=lambda x: bin(x).count('1')
def ext(size,P,mask):
    if size==r: found.append(mask); return
    if size+popc(P)<r: return
    Q,col=P,0
    while Q:
        col+=1; R=Q
        while R:
            v=(R&-R).bit_length()-1; R&=~(1<<v)&~comp[v]; Q&=~(1<<v)
    if size+col<r: return
    while P:
        if size+popc(P)<r: return
        v=(P&-P).bit_length()-1; P&=~(1<<v)
        ext(size+1,P&comp[v],mask|(1<<v))
ext(1,comp[0],0)
target=comp[0]
print(sys.argv[1].split('/')[-1],'cocliques through 0:',len(found),'non-neighbours:',popc(target),'need',popc(target)//(r-1),'%.0fs'%(time.time()-t0),flush=True)
# exact cover of target by members of found (each covers r-1 non-neighbours of 0)
sols=[0]
def cover(rem,avail,depth):
    if rem==0: sols[0]+=1; return sols[0]>=1
    v=(rem&-rem).bit_length()-1
    for c in avail:
        if c>>v&1 and (c & ~rem)==0:
            if cover(rem&~c,[d for d in avail if d&c==0],depth+1): return True
    return False
cover(target,found,0)
print('exact cover of the non-neighbours of 0 by cocliques through 0 exists:',sols[0]>0,'%.0fs'%(time.time()-t0),flush=True)
