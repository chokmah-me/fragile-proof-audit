"""N = 36 (and 40, 44): exact checks of G0, BHK twin and two-spread deletion; canonical hash for the
two-spread deletion only (labelg on G0 at 1296 vertices took > 30 min and was stopped)."""
import sys, os, time, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *
OUT = '/work/out/family_2026_10_12/g6'
rng = random.Random(20261012)
for N in map(int, sys.argv[1:]):
    canon = N <= 36
    for hn, H in hadamards(N):
        Ls = [('rr', round_robin(N))] + ([('rr*', relabel_rr(N, rng))] if canon else [])
        for ln, L in Ls:
            t0 = time.time(); K = kharaghani(H, L); assert check_K(K)
            G0, B1, G2 = graphs_from_K(K)
            ps = [srg_params(X) for X in (G0, B1, G2)]
            ok = ps == [ls_params(N, N // 2 + 1), ls_params(N, N // 2), ls_params(N, N // 2 - 1)]
            line = 'N=%d H=%s L=%s G0 %s | BHK %s | G2 %s | %s' % (N, hn, ln, ps[0], ps[1], ps[2], 'OK' if ok else 'FAIL')
            if canon:
                g = to_g6(G2); open('%s/khar_%s_%s_G2.g6' % (OUT, hn.replace('(', '').replace(')', ''), ln.replace('*', 'x')), 'w', newline='\n').write(g + '\n')
                line += ' | G2 canon %s' % canon_hash(g)
            print(line + ' | %.0fs' % (time.time() - t0), flush=True)
