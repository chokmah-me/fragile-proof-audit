# control: complement of genuine LS_t(n) graphs (cyclic OA over Z_p) must admit the exact cover
def g6(n,adj):
    bits=[]
    for j in range(1,n):
        for i in range(j): bits.append(1 if adj(i,j) else 0)
    while len(bits)%6: bits.append(0)
    s=chr(n+63) if n<63 else chr(126)+chr(((n>>12)&63)+63)+chr(((n>>6)&63)+63)+chr((n&63)+63)
    for k in range(0,len(bits),6):
        v=0
        for b in bits[k:k+6]: v=v*2+b
        s+=chr(v+63)
    return s
for p,t in [(5,3),(7,4),(11,5)]:
    V=[(i,j) for i in range(p) for j in range(p)]
    def lsadj(x,y):
        (a,b),(c,d)=V[x],V[y]
        if a==c or b==d: return True
        return any((a+m*b-c-m*d)%p==0 for m in range(1,t-1))
    open('/tmp/ctrl_%d_%d.g6'%(p,t),'w').write(g6(p*p,lambda x,y: not lsadj(x,y))+'\n')
