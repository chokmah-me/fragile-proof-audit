"""Task 3: j-spread deletion.  For a Bush-type K (Kharaghani or the symmetric rule) take
G0 = (J+K)/2 - I (LS_{N/2+1}(N)).  Spreads 1,2 = rows, columns.  Further spreads must be
orthogonal to both, i.e. consist of transversal N-cliques {(a,pi a)} of G0.  We enumerate ALL
transversal cliques (C program transv, exhaustive, verdict COMPLETE/INCOMPLETE), all spreads made
of them (exact cover, exhaustive), and the largest set of mutually orthogonal spreads; then delete
rows + cols + j-2 further spreads and verify the result exactly (A^2) as LS_{N/2+1-j}(N).

usage: step3_spreads.py N [nodelimit]   (runs every (H, L) source for that N)
"""
import sys, os, time, random, subprocess, itertools, struct
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *

TRANSV = '/work/out/family_2026_10_12/transv'
OUT = '/work/out/family_2026_10_12/g6'; os.makedirs(OUT, exist_ok=True)

def transversal_cliques(G0, N, limit):
    nb = np.zeros((N * N, N), dtype=np.uint64)
    for v in range(N * N):
        a, b = divmod(v, N)
        for c in range(N):
            if c == a: continue
            m = 0
            for d in range(N):
                if d != b and G0[v, c * N + d]: m |= 1 << d
            nb[v, c] = m
    data = struct.pack('<i', N) + nb.astype('<u8').tobytes()
    r = subprocess.run([TRANSV, str(limit)], input=data, capture_output=True, check=True)
    lines = r.stdout.decode().strip().split('\n')
    status = lines[-1]
    T = [tuple(map(int, l.split())) for l in lines[:-1]]
    return T, status

def all_spreads(T, N, cap=100000):
    """exact cover of the N^2 cells by transversals (each covers (a, pi a)); exhaustive up to cap."""
    cover = {}
    for i, t in enumerate(T):
        for a, b in enumerate(t): cover.setdefault((a, b), []).append(i)
    cells = [(a, b) for a in range(N) for b in range(N)]
    if any(c not in cover for c in cells): return [], 'COMPLETE'
    out = []; used = set(); chosen = []
    state = {'inc': False}
    def rec():
        if len(out) >= cap: state['inc'] = True; return
        free = [c for c in cells if c not in used]
        if not free: out.append(tuple(sorted(chosen))); return
        best = None; bl = None
        for c in free:
            l = [i for i in cover[c] if all((a, b) not in used for a, b in enumerate(T[i]))]
            if best is None or len(l) < len(bl):
                best, bl = c, l
                if not l: return
        for i in bl:
            if chosen and i < chosen[0]: pass
            cs = [(a, b) for a, b in enumerate(T[i])]
            for c in cs: used.add(c)
            chosen.append(i); rec(); chosen.pop()
            for c in cs: used.discard(c)
            if state['inc']: return
    rec()
    return sorted(set(out)), ('INCOMPLETE' if state['inc'] else 'COMPLETE')

def orthogonal(S1, S2, T):
    for i in S1:
        si = set(enumerate(T[i]))
        for j in S2:
            if len(si & set(enumerate(T[j]))) != 1: return False
    return True

def max_mos(spreads, T):
    """largest set of mutually orthogonal spreads (exhaustive clique search; small)."""
    n = len(spreads)
    adj = [[i != j and orthogonal(spreads[i], spreads[j], T) for j in range(n)] for i in range(n)]
    best = []
    def rec(cl, cand):
        nonlocal best
        if len(cl) > len(best): best = cl[:]
        for x in cand:
            rec(cl + [x], [y for y in cand if y > x and adj[x][y]])
    rec([], list(range(n)))
    return best

def spread_matrix(S, T, N):
    E = np.zeros((N * N, N * N), dtype=np.int64)
    for i in S:
        vs = [a * N + b for a, b in enumerate(T[i])]
        for x in vs:
            for y in vs:
                if x != y: E[x, y] = 1
    return E

def sources(N, nrand, rng):
    for hn, H in hadamards(N):
        Ls = [('rr', round_robin(N))] + [('rr%d' % i, relabel_rr(N, rng)) for i in range(nrand)]
        if N & (N - 1) == 0: Ls.append(('xor', xor_square(N)))
        for ln, L in Ls:
            yield 'khar_%s_%s' % (hn, ln), kharaghani(H, L)
        if (H == H.T).all():
            yield 'sym_%s' % hn, sym_rule(H)

if __name__ == '__main__':
    N = int(sys.argv[1]); limit = int(sys.argv[2]) if len(sys.argv) > 2 else 2_000_000_000
    nrand = int(sys.argv[3]) if len(sys.argv) > 3 else 6
    rng = random.Random(1000 + N)
    for name, K in sources(N, nrand, rng):
        t0 = time.time()
        assert check_K(K)
        G0, B1, G2 = graphs_from_K(K)
        T, st = transversal_cliques(G0, N, limit)
        sp, sst = all_spreads(T, N) if st.startswith('COMPLETE') else ([], 'n/a')
        mos = max_mos(sp, T) if sp and sst == 'COMPLETE' and len(sp) <= 400 else []
        line = '%s N=%d transversal-cliques=%d [%s] spreads=%d [%s] max-MOS=%d' % (
            name, N, len(T), st, len(sp), sst, len(mos))
        # build and verify j-spread deletions, j = 3 .. 2+len(mos)
        A = G2.copy()
        for j, s in enumerate(mos, start=3):
            A = A - spread_matrix(sp[s], T, N)
            p = srg_params(A); t = N // 2 + 1 - j
            ok = p == ls_params(N, t)
            g = to_g6(A); fn = '%s/%s_j%d.g6' % (OUT, name.replace('(', '').replace(')', ''), j)
            open(fn, 'w', newline='\n').write(g + '\n')
            line += ' | j=%d %s %s %s' % (j, p, 'OK' if ok else 'FAIL', canon_hash(g))
        # also a single extra spread on its own (if any) even when MOS search skipped
        if sp and not mos:
            A = G2 - spread_matrix(sp[0], T, N); p = srg_params(A)
            line += ' | j=3(first spread) %s' % (p,)
        print(line + ' | %.1fs' % (time.time() - t0), flush=True)
