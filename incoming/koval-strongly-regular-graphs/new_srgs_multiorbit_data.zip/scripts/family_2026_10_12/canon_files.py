"""exact srg check + nauty canonical hash for every graph6 file given (first line)."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *
for fn in sys.argv[1:]:
    t0 = time.time()
    g = open(fn).readline().strip(); A = from_g6(g)
    print('%s %s %s %.0fs' % (os.path.relpath(fn, '/work'), srg_params(A), canon_hash(g), time.time() - t0), flush=True)
