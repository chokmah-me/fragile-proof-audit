"""Task 4: the 306-vertex graph Delta and its analogues over F_q (own code, from the paper's
Construction 6.1 text only).

Q(y) = y0^2 + y1 y2 + y3 y4 on F_q^5, B its polar form, l = <e1,e3> totally singular,
P(y) = <y4 e1 - y2 e3>.  Variant 'type' selects the nonsingular points used:
  'ns' = Q(y) non-square (the paper), 'sq' = Q(y) non-zero square.
Delta_q(type): those points + the q+1 points of l; l is a clique; y ~ P(y); y ~ z iff
(B(y,z)=0 and P(y)!=P(z)) or z in <y,P(y)>.
Also NO_perp(type): the chosen points alone, y ~ z iff B(y,z) = 0 (the NO^{+-perp}_5(q) graphs).
Every srg claim: exact A^2.  For q=3 the canonical form is compared with the collinearity
graphs of W(3) and Q(4,3).
usage: step4_delta.py q [q ...]
"""
import sys, os, time, itertools
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *

def points(F, dim):
    """normalized representatives (first non-zero coordinate = 1)."""
    pts = []
    for v in itertools.product(range(F.q), repeat=dim):
        nz = [c for c in v if c]
        if nz and nz[0] == 1: pts.append(v)
    return pts

def build(q, typ):
    F = GF(q); M, Ad = F.mul_t, F.add_t
    def Q(y): return Ad[Ad[M[y[0]][y[0]]][M[y[1]][y[2]]]][M[y[3]][y[4]]]
    def B(y, z):
        two = Ad[1][1]
        s = M[two][M[y[0]][z[0]]]
        for i, j in ((1, 2), (2, 1), (3, 4), (4, 3)): s = Ad[s][M[y[i]][z[j]]]
        return s
    pts = points(F, 5); idx = {p: i for i, p in enumerate(pts)}
    def norm(v):
        nz = next(c for c in v if c); inv = next(x for x in range(1, q) if M[x][nz] == 1)
        return tuple(M[inv][c] for c in v)
    want = (lambda x: F.chi[x] == -1) if typ == 'ns' else (lambda x: F.chi[x] == 1)
    Y = [p for p in pts if want(Q(p))]
    ell = sorted({norm((0, x, 0, z, 0)) for x in range(q) for z in range(q) if x or z})
    assert len(ell) == q + 1
    # sanity: no chosen point in l-perp, P(y) singular-orthogonal
    Pof = {}
    if any(y[2] == 0 and y[4] == 0 for y in Y): return None, None, len(Y)   # a chosen point in l-perp: P(y) undefined
    for y in Y:
        Py = norm((0, y[4], 0, F.neg[y[2]], 0))
        assert B(y, Py) == 0 and Py in ell
        Pof[y] = Py
    V = Y + ell; vi = {p: i for i, p in enumerate(V)}; n = len(V)
    A = np.zeros((n, n), dtype=np.int64)
    # NO-perp graph on Y
    nY = len(Y)
    Bm = np.zeros((nY, nY), dtype=np.int64)
    for i in range(nY):
        for j in range(i + 1, nY):
            if B(Y[i], Y[j]) == 0: Bm[i, j] = Bm[j, i] = 1
    NOperp = Bm.copy()
    for i in range(nY):
        for j in range(i + 1, nY):
            if Bm[i, j] and Pof[Y[i]] != Pof[Y[j]]: A[i, j] = A[j, i] = 1
    for y in Y:                      # lines m_y = <y, P(y)>
        P = Pof[y]; i = vi[y]
        for t in range(1, q):
            z = norm(tuple(Ad[a][M[t][b]] for a, b in zip(y, P)))
            j = vi[z]; A[i, j] = A[j, i] = 1
        A[i, vi[P]] = A[vi[P], i] = 1
    for a in ell:
        for b in ell:
            if a != b: A[vi[a], vi[b]] = 1
    return A, NOperp, len(Y)

def wq3():
    F = GF(3); pts = points(F, 4); n = len(pts)
    A = np.zeros((n, n), dtype=np.int64)
    for i in range(n):
        for j in range(n):
            x, y = pts[i], pts[j]
            s = (x[0] * y[1] - x[1] * y[0] + x[2] * y[3] - x[3] * y[2]) % 3
            if i != j and s == 0: A[i, j] = 1
    return A

def q43():
    F = GF(3); pts = [p for p in points(F, 5) if (p[0] ** 2 + p[1] * p[2] + p[3] * p[4]) % 3 == 0]
    n = len(pts); A = np.zeros((n, n), dtype=np.int64)
    for i in range(n):
        for j in range(n):
            y, z = pts[i], pts[j]
            if i != j and (2 * y[0] * z[0] + y[1] * z[2] + y[2] * z[1] + y[3] * z[4] + y[4] * z[3]) % 3 == 0: A[i, j] = 1
    return A

def count_cliques(A, size):
    n = A.shape[0]; nb = [set(np.nonzero(A[i])[0].tolist()) for i in range(n)]; cnt = 0
    def rec(cl, cand):
        nonlocal cnt
        if len(cl) == size: cnt += 1; return
        for x in sorted(cand):
            rec(cl + [x], {y for y in cand if y > x} & nb[x])
    rec([], set(range(n)))
    return cnt

if __name__ == '__main__':
    OUT = '/work/out/family_2026_10_12/g6'; os.makedirs(OUT, exist_ok=True)
    for q in map(int, sys.argv[1:]):
        for typ in ('ns', 'sq'):
            t0 = time.time()
            A, NO, nY = build(q, typ)
            if A is None:
                print("q=%d type=%s |Y|=%d: some chosen point lies in l-perp, construction undefined" % (q, typ, nY), flush=True); continue
            p = srg_params(A); pNO = srg_params(NO)
            line = 'q=%d type=%s |Y|=%d NOperp=%s Delta(v=%d)=%s' % (q, typ, nY, pNO, A.shape[0], p)
            if p is None:
                deg = sorted(set(A.sum(1).tolist())); line += ' degrees=%s' % deg
            if p and A.shape[0] <= 400:
                g = to_g6(A); open('%s/delta_q%d_%s.g6' % (OUT, q, typ), 'w', newline='\n').write(g + '\n')
                line += ' canon=%s' % canon_hash(g)
                smin = int(round(float(min(np.linalg.eigvalsh(A.astype(float)))))); cs = 1 + p[1] // (-smin)
                line += ' #%d-cliques=%d' % (cs, count_cliques(A, cs))
            print(line + ' %.1fs' % (time.time() - t0), flush=True)
        if q == 3:
            for name, A in (('W(3)', wq3()), ('Q(4,3)', q43())):
                g = to_g6(A)
                print('q=3 reference %s %s canon=%s #4-cliques=%d' % (name, srg_params(A), canon_hash(g), count_cliques(A, 4)), flush=True)
