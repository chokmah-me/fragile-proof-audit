"""N = 40, 44: Kharaghani(H, round robin) minus rows and columns; exact srg check only (beyond Brouwer's table)."""
import sys, os, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *
for N in (40, 44):
    for hn, H in hadamards(N):
        t0 = time.time(); K = kharaghani(H, round_robin(N)); assert check_K(K)
        G0, B1, G2 = graphs_from_K(K)
        p = srg_params(G2)
        print('N=%d H=%s G2 %s expected LS_%d(%d)=%s %s %.0fs' % (N, hn, p, N // 2 - 1, N, ls_params(N, N // 2 - 1),
              'OK' if p == ls_params(N, N // 2 - 1) else 'FAIL', time.time() - t0), flush=True)
        break
