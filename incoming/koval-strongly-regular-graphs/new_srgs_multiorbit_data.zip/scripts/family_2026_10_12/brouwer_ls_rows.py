"""List Latin-square-type rows LS_t(n) (v=n^2, k=t(n-1), lam=n-2+(t-1)(t-2), mu=t(t-1)) in the
live Brouwer table pages saved under out/family_2026_10_12/brouwer_live/. Each table entry is a
pair of rows (graph, complement); status is on the first row.  Also prints the 306 row."""
import re, html, glob, math, sys
D = sys.argv[1] if len(sys.argv) > 1 else 'out/family_2026_10_12/brouwer_live'
def cells(tr):
    return [html.unescape(re.sub(r'<[^>]*>', '', c)).replace('–', '-').strip()
            for c in re.findall(r'<td[^>]*>(.*?)</td>', tr, flags=re.S | re.I)]
def ls_t(v, k, l, m):
    n = math.isqrt(v)
    if n * n != v or k % (n - 1): return None
    t = k // (n - 1)
    return t if (l == n - 2 + (t - 1) * (t - 2) and m == t * (t - 1)) else None
for f in sorted(glob.glob(D + '/t*.html'), key=lambda s: int(re.findall(r't(\d+)-', s)[0])):
    trs = re.findall(r'<tr.*?</tr>', open(f, encoding='utf-8', errors='replace').read(), flags=re.S | re.I)
    st = v = None
    for tr in trs:
        c = cells(tr)
        if len(c) < 5: continue
        try:
            if c[1]:
                st, v = c[0], int(c[1])
            k, l, m = int(c[2]), int(c[3]), int(c[4])
        except ValueError:
            continue
        cm = c[7] if len(c) > 7 else ''
        t = ls_t(v, k, l, m)
        if t is not None or (v, k) == (306, 55) or (v, k) == (306, 250):
            print('%-2s %5d %4d %4d %4d  %s  | %s' % (st, v, k, l, m,
                  ('LS_%d(%d)' % (t, math.isqrt(v))) if t is not None else '', cm[:150]))
