# Is "the spread contains the diagonal transversal" WLOG?  Claim: permuting the GRID ROWS a -> s(a) of K(H,L)
# (cells (a,b) -> (s(a),b)) gives exactly K(H, L^s) with L^s(s(a),s(c)) = L(a,c), another symmetric constant-diagonal
# Latin square.  Then any transversal {(a,pi(a))} can be moved to the diagonal by s = pi^{-1}, while L stays in the
# model's range.  Test the identity on random L and s.
import sys, random; sys.path.insert(0, 'scripts/family_2026_10_12'); from famlib import *
random.seed(1)
for N, hname in ((8, 'Syl8'), (12, 'PalI(11)')):
    H = normalize(dict(hadamards(N))[hname])
    L0 = latin_rr(N) if 'latin_rr' in dir() else None
    if L0 is None:
        from famlib import round_robin as latin_rr; L0 = latin_rr(N)
    for trial in range(3):
        perm = list(range(1, N)); random.shuffle(perm); relab = {0: 0}; relab.update({i + 1: perm[i] for i in range(N - 1)})
        L = np.vectorize(lambda x: relab[int(x)])(L0); assert ok_sym_latin(L)
        s = list(range(N)); random.shuffle(s)
        K = kharaghani(H, L)
        Ls = np.zeros_like(L)
        for a in range(N):
            for c in range(N): Ls[s[a], s[c]] = L[a, c]
        assert ok_sym_latin(Ls)
        idx = [s[a] * N + b for a in range(N) for b in range(N)]       # new position of old cell (a,b)
        P = np.zeros((N * N, N * N), dtype=np.int64)
        for old, new in enumerate(idx): P[new, old] = 1
        Kp = P @ K @ P.T
        print(N, hname, 'trial', trial, 'P K P^T == K(H, L^s):', np.array_equal(Kp, kharaghani(H, Ls)))
