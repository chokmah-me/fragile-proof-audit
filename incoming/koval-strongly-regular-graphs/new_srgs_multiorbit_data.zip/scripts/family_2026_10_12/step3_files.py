"""step3 on given G2 graph6 files (vertex (a,b) = a*N+b, rows and columns cocliques): restore
G0 = G2 + rows + cols, enumerate transversal N-cliques exhaustively, spreads, MOS; j-deletions verified."""
import sys, os, time, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *
from step3_spreads import transversal_cliques, all_spreads, max_mos, spread_matrix, OUT
for fn in sys.argv[1:]:
    t0 = time.time()
    G2 = from_g6(open(fn).readline()); N = math.isqrt(G2.shape[0])
    R, C = spread_rows(N), spread_cols(N)
    assert not (G2 * R).any() and not (G2 * C).any(), 'labelling is not (a,b)=a*N+b'
    G0 = G2 + R + C
    T, st = transversal_cliques(G0, N, 0)
    sp, sst = all_spreads(T, N) if st.startswith('COMPLETE') else ([], 'n/a')
    # pairwise intersection sizes of the transversal cliques
    inter = set()
    for i in range(len(T)):
        for j in range(i + 1, len(T)):
            inter.add(sum(1 for a in range(N) if T[i][a] == T[j][a]))
    mos = max_mos(sp, T) if sp and len(sp) <= 400 else []
    line = '%s N=%d transversal-cliques=%d [%s] pairwise-intersections=%s spreads=%d [%s] max-MOS=%d' % (
        os.path.basename(fn), N, len(T), st, sorted(inter), len(sp), sst, len(mos))
    A = G2.copy()
    for j, s in enumerate(mos, start=3):
        A = A - spread_matrix(sp[s], T, N); p = srg_params(A)
        line += ' | j=%d %s %s' % (j, p, 'OK' if p == ls_params(N, N // 2 + 1 - j) else 'FAIL')
    print(line + ' | %.1fs' % (time.time() - t0), flush=True)
