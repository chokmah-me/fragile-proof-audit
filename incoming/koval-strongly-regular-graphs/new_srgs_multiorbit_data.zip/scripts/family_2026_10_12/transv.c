/* Enumerate all transversal cliques {(a,pi(a)) : a in [N]} of a graph on [N]x[N].
 * Input (stdin, binary): int32 N, then for each vertex v=(a,b) (index a*N+b) and each row c,
 * a uint64 mask of the d with (a,b)~(c,d).  Output: one line per clique, pi(0) .. pi(N-1).
 * Forward checking: always branch on the row with fewest candidates.  Exhaustive unless the
 * optional node limit argv[1] (>0) is hit, in which case the last line is "INCOMPLETE".
 * Final line "COMPLETE count=<c> nodes=<n>" otherwise.  */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
static int N; static uint64_t *nb; static long long count = 0, nodes = 0, limit = 0;
static int pi[64]; static int incomplete = 0;
static void rec(uint64_t *cand, int done_mask_rows_left, uint64_t rowsleft_lo) {
    (void)done_mask_rows_left;
    if (incomplete) return;
    if (++nodes > limit && limit > 0) { incomplete = 1; return; }
    if (rowsleft_lo == 0) {
        for (int a = 0; a < N; a++) printf("%d%c", pi[a], a == N - 1 ? '\n' : ' ');
        count++; return;
    }
    int best = -1, bc = 99;
    for (int a = 0; a < N; a++) if (rowsleft_lo >> a & 1) {
        int c = __builtin_popcountll(cand[a]);
        if (c < bc) { bc = c; best = a; if (c == 0) return; }
    }
    uint64_t m = cand[best];
    uint64_t nc[64];
    while (m) {
        int b = __builtin_ctzll(m); m &= m - 1;
        pi[best] = b;
        const uint64_t *row = nb + ((size_t)(best * N + b)) * N;
        int dead = 0;
        for (int a = 0; a < N; a++) {
            if (rowsleft_lo >> a & 1 && a != best) {
                nc[a] = cand[a] & row[a] & ~(1ULL << b);
                if (!nc[a]) { dead = 1; break; }
            } else nc[a] = 0;
        }
        if (!dead) rec(nc, 0, rowsleft_lo & ~(1ULL << best));
        if (incomplete) return;
    }
}
int main(int argc, char **argv) {
    if (argc > 1) limit = atoll(argv[1]);
    int32_t n; if (fread(&n, 4, 1, stdin) != 1) return 1; N = n;
    nb = malloc(sizeof(uint64_t) * (size_t)N * N * N);
    if (fread(nb, sizeof(uint64_t), (size_t)N * N * N, stdin) != (size_t)N * N * N) return 2;
    uint64_t cand[64]; uint64_t full = (N == 64) ? ~0ULL : ((1ULL << N) - 1);
    for (int a = 0; a < N; a++) cand[a] = full;
    rec(cand, 0, full);
    if (incomplete) printf("INCOMPLETE count=%lld nodes=%lld\n", count, nodes);
    else printf("COMPLETE count=%lld nodes=%lld\n", count, nodes);
    return 0;
}
