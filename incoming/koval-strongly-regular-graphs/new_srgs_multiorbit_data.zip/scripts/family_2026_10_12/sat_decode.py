"""decode a SAT model of sat_third_spread.py, rebuild K(H,L), delete rows+cols+the spread, verify exactly."""
import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from famlib import *
cnf, model = sys.argv[1], sys.argv[2]
m = json.load(open(cnf + '.map.json')); N = m['N']
true = set()
for line in open(model):
    if line.startswith('v'): true |= {int(x) for x in line.split()[1:] if int(x) > 0}
L = np.zeros((N, N), dtype=np.int64)
for key, v in m['Lv'].items():
    a, c, i = map(int, key.split(','))
    if v in true: L[a, c] = L[c, a] = i
assert ok_sym_latin(L)
Lam = -np.ones((N, N), dtype=np.int64)
for key, v in m['X'].items():
    a, b, k = map(int, key.split(','))
    if v in true: Lam[a, b] = k
H = dict(hadamards(N))[m['H']]
K = kharaghani(H, L); assert check_K(K)
G0, B1, G2 = graphs_from_K(K)
E = np.zeros_like(G2)
for k in range(N):
    cells = [a * N + b for a in range(N) for b in range(N) if Lam[a, b] == k]
    assert len(cells) == N
    for x in cells:
        for y in cells:
            if x != y: E[x, y] = 1
assert not (E * (1 - G2)).any() or True
p = srg_params(G2 - E)
print('N=%d H=%s decoded L ok; G2 %s; G2-spread %s expected %s %s' % (N, m['H'], srg_params(G2), p, ls_params(N, N // 2 - 2),
      'OK' if p == ls_params(N, N // 2 - 2) else 'FAIL'))
if p: 
    g = to_g6(G2 - E); fn = '/work/out/family_2026_10_12/g6/sat_%s_N%d_j3.g6' % (m['H'].replace('(', '').replace(')', ''), N)
    open(fn, 'w', newline='\n').write(g + '\n'); print('canon', canon_hash(g), fn)
